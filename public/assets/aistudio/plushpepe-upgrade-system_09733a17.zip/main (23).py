#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
New NFT Gift Telegram Bot v12.1
- Поддержка: @mkrartem (https://t.me/mkrartem)
- Платная установка и смена фона профиля (1,500,000 ⭐ за установку, 500,000 ⭐ за смену).
- Кнопка «Улучшение» в профиле (в разработке).
- Список существующих NFT в разделе моделей маркета.
- Команды в чате «Передать» (звёзды от 1,000 ⭐ и подарки, доступно с 5-го уровня).
- Исправленная казна кланов (общая казна не уменьшается при депозите в баланс казны) и пожертвованные подарки клана.
- Режим техработ (отключение бота) в Админ-панели.
"""

import asyncio
import atexit
import base64
import datetime
import gzip
import hashlib
import html
import inspect
import io
import json
import logging
import math
import os
import random
import re
import secrets
import shutil
import signal
import sqlite3
import subprocess
import tempfile
import threading
import time
import unicodedata
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List, Tuple, Dict

from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageFilter, ImageChops, ImageEnhance
import requests

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Update,
    CallbackQuery,
    InputFile,
    InlineQueryResultArticle,
    InlineQueryResultCachedPhoto,
    InputTextMessageContent,
    InputMediaPhoto,
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    ConversationHandler,
    InlineQueryHandler,
    ChosenInlineResultHandler,
    filters,
)
from telegram.request import HTTPXRequest

# Попытка импорта Firebase Admin SDK
try:
    import firebase_admin
    from firebase_admin import (
        credentials as fb_credentials,
        firestore as fb_firestore,
        storage as fb_storage,
    )
    FIREBASE_ADMIN_AVAILABLE = True
except ImportError:
    firebase_admin = None
    fb_credentials = None
    fb_firestore = None
    fb_storage = None
    FIREBASE_ADMIN_AVAILABLE = False

# ---------------------------------------------------------------------------
# Настройки и глобальные пути
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
IMAGES_DIR = BASE_DIR / "images"
PLUSHPEPE_MODELS_DIR = IMAGES_DIR / "plushpepe_models"
BACKGROUNDS_DIR = IMAGES_DIR / "backgrounds"
CLAN_AVATARS_DIR = IMAGES_DIR / "clan_avatars"
CLAN_PRESETS_DIR = IMAGES_DIR / "clan_presets"
UI_ASSETS_DIR = IMAGES_DIR / "ui"
AVATARS_CACHE_DIR = IMAGES_DIR / "avatars"
FONTS_DIR = BASE_DIR / "fonts"
DB_PATH = BASE_DIR / "base.db"

FONTS_DIR.mkdir(parents=True, exist_ok=True)
IMAGES_DIR.mkdir(parents=True, exist_ok=True)
PLUSHPEPE_MODELS_DIR.mkdir(parents=True, exist_ok=True)
BACKGROUNDS_DIR.mkdir(parents=True, exist_ok=True)
CLAN_AVATARS_DIR.mkdir(parents=True, exist_ok=True)
CLAN_PRESETS_DIR.mkdir(parents=True, exist_ok=True)
UI_ASSETS_DIR.mkdir(parents=True, exist_ok=True)
AVATARS_CACHE_DIR.mkdir(parents=True, exist_ok=True)

CLAN_PRESET_AVATARS = [
    ("cyber_frog", "🐸 Кибер-Пепе", "cyber_frog.jpg"),
    ("royal_crest", "👑 Чёрное Золото", "royal_crest.jpg"),
    ("neon_phantom", "🐺 Кристальный Волк", "neon_phantom.jpg"),
    ("plush_midas", "🏆 Midas Pepe", "model:Midas Pepe"),
    ("plush_galaxy", "🌌 Cozy Galaxy", "model:Cozy Galaxy"),
    ("plush_emerald", "💎 Emerald Plush", "model:Emerald Plush"),
]

BOT_TOKEN = os.environ.get("BOT_TOKEN", "9036416244:AAGrJgI3jzMMU5bn6Q36r8cNBIJqGxniXmo")
SUPPORT_URL = os.environ.get("SUPPORT_URL", "https://t.me/mkrartem")
SUPPORT_HANDLE = "@mkrartem"
_BOT_USERNAME_CACHE: Optional[str] = None

COOLDOWN_SECONDS = 1 * 60 * 60          # 1 час между выбиванием NFT в группах
COOLDOWN_ENABLED = True
CHAT_DROP_CHANCE = 0.90                 # 90% шанс дропа при слове NFT
STAR_RUB_RATE = 1.5                     # 1 Star = 1.5 RUB
TON_RUB_RATE = 100.0                    # 1 TON = 100 RUB
ADMIN_IDS = {684535319, 7459502130}     # Telegram ID администраторов

BG_SET_COST = 1_500_000                 # Стоимость первой установки фона профиля
BG_CHANGE_COST = 500_000                # Стоимость смены уже установленного фона
TRANSFER_MIN_LEVEL = 5                  # Минимальный уровень для передачи звёзд и подарков
TRANSFER_MIN_STARS = 1_000              # Минимальная сумма передачи звёзд
CHECK_MIN_STARS = 1_000                 # Минимальная сумма чека

UPGRADE_COST_STARS = 150_000            # Стоимость улучшения Plush Pepe
MONO_PRICE_MULT = 6.0                   # Множитель ценности за Монохром-комбо (цвет модели = цвет фона)
MARKET_FEE_RATE = 0.15                  # Комиссия NFT маркета 15%
MARKET_MIN_PRICE = 1_000                # Минимальная цена лота на маркете
MARKET_MAX_PRICE = 100_000_000_000      # Максимальная цена лота на маркете (100 млрд)

# ---------------------------------------------------------------------------
# Firebase Cloud Database Storage (Интеграция с проектом proar-5a642)
# ---------------------------------------------------------------------------

FIREBASE_SERVICE_ACCOUNT_CONFIG = {
    "type": "service_account",
    "project_id": "proar-5a642",
    "private_key_id": "039601a8db0c82988fe7ea83c3a3463301d7cd8b",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDZpDGlnJ67Qoxu\nGlxikHVtThmN7PdrOXKvVd7Nko2XWs8UZboV/6KmHREN3pEjzwdQb3tXGnWwwR+s\nnUkH5ILGoUpQ88XSxrbgTtKOU8TJbaIye8MmSDTmXHmwxRiMum/BfBdaoPR02P8P\nfLoP4ihwnKe8l7PRFRaybDungKuG7wIzCEUiZy828+DZk24z1ymqyrOwo0JSMpUI\nFWtCQb7cNTt1u9LOfCTCXKP46GTg2ghjYIUqQpVgX3zR4koKLuYava4vrNVAJT9B\nXiL+/YNGnvct5ZKT1OiHh8V4x7o2jN0R2D5sQ03z/Us6CB2LC/9NNQIxsnXp/gzB\nLvqbv94ZAgMBAAECggEABRkespmZxvAsTZ30y7hE5T5pmdSoXQzM8299rG9s5/6Q\nED3BH1J20xD7knQZY+8tutl0WFoofJn22HpyDgBxJx77GIIFVcZ4MoaWJxBY8Tuj\nYNmw/Ly/RHrREkN5AOmTGZittrPuK1iJQlRydVHKZGI/CaC8wmk4jWMR/f6lG0rY\nlLDLNCE9a6c6lLfEL72K7JRmRfbW96DIEnx6ObcqkPzaYb+pz24ewsUkY5b2QVZe\nifrQN2gAqNGq34qVp1m4/ywVC5E40sie0Un2nmINPqEA0VzVllEwgcCd5bx2X8Ya\nI2OW3TnvnoHtxNdXXY04advOMohHpNTdPd2Z5awYQQKBgQD1euUTbnEt8qcXRZYU\nmKEL5P4FvPQ7Ly3vQ8vGd7oK7lLE0zY+nEE1TW5mAaNM1W6QzZSAQsfUq8k1QZLI\n4m70f//UcnvADi/Ke12ze1xxCtHYADYb04bQ4CjfjtLk5ZstjO31mVqkNQXiSUo2\nTXYTpsi93zxj9SHaa6HT5F0zkQKBgQDi9+MtUw6ChXoiVF6V3C5AU5mtJA1eRdQy\n8AZ9GTrPAGh5ewVG+Nl9VG3ePIbZkmquh2zEo2f0LgPczegVIqDz0VBIW4LIw4wT\nmNG7MSOtJg2/wpoZexw7y1BknkWi8aV26BkEgxDEIXvvjUC3tHD9V0m2BZ4lVlsr\ng6+ZLWUuCQKBgC7JhJ3GgAXc6OHznl5AlPlaZNwdHoOlQ2EGD/G84hWxRM9E3mLi\njz8kifUhPMmpKFCrDjHACKxNLaVb4Skuly08tDr+sv1w9sTl7H8H9R+Ki2Ja7/Uv\nxNNM1h198E42QPRWlwgneXIwtPVjOKTO8MFgGYSu5qi6kQA7YXWsYeMxAoGBAItB\ncH9UoGhwoNkDTu0/pJkPMhDLN/CJg4KlRjXnDvAG3hL66ef7suV0sdxS4qIHdbET\noiab46IrwW7uXuDo2DwARvO+QeYQJJe5gaUKp0sLOBBZw9aydEYznmW9vhgVj2H/\nUao1CEpuCO6XigesjE7ECZPGqptZ+qIeL9UZxySRAoGBAIkU8wfatRMbuPmzgtst\nhEZt62FEe+0MP1QfPY6ByddLnzqlO6JpWRNUXkx6zFjf3Vy7J/J+fClAo10E4uWh\nFe7HkfG/CCamiAB4ki1WiSrrQkB/FtJAaBI3y4Ka1jN6IzniVJ0pH1Nb9N8+x8eE\nMSgIEVIFGwIPv3vQofyxnnTr\n-----END PRIVATE KEY-----\n",
    "client_email": "firebase-adminsdk-fbsvc@proar-5a642.iam.gserviceaccount.com",
    "client_id": "103737744652283306114",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-fbsvc%40proar-5a642.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com"
}

class FirebaseCloudManager:
    """
    Безопасное облачное хранение базы данных SQLite (base.db) в Cloud Firestore.
    """
    def __init__(self):
        self.project_id: str = "proar-5a642"
        self.collection_name: str = "telegram_bot_data"
        self.doc_name: str = "sqlite_database"
        self.app = None
        self.firestore_client = None
        self.cached_token: Optional[str] = None
        self.token_expiry: float = 0.0
        self.initialized: bool = False
        self.active_key_id: str = "embedded"
        self.loaded_cred_dict: Optional[dict] = None
        self.last_sync_ts: float = 0.0
        self.last_sync_size: int = 0
        self.last_sync_status: str = "Ожидает первой синхронизации"
        self._lock = threading.Lock()
        self._sync_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._dirty: bool = False
        self._startup_download_error: bool = False
        self._cloud_doc_missing: bool = False

    @staticmethod
    def format_error(e: Exception) -> str:
        err_msg = str(e)
        if "Invalid JWT Signature" in err_msg or "invalid_grant" in err_msg:
            return "⚠️ Ошибка: Ключ сервисного аккаунта отозван в консоли Firebase (Invalid JWT Signature)."
        if "permission" in err_msg.lower() or "403" in err_msg:
            return "⚠️ Ошибка доступа: проверьте права сервисного аккаунта в Firebase Console."
        safe_msg = re.sub(r"<[^>]+>", "", err_msg)
        return f"Ошибка: {safe_msg[:200]}"

    def get_access_token(self) -> Optional[str]:
        now = time.time()
        if self.cached_token and self.token_expiry > now + 120:
            return self.cached_token

        key_dict = self.loaded_cred_dict or dict(FIREBASE_SERVICE_ACCOUNT_CONFIG)
        try:
            from google.oauth2 import service_account
            from google.auth.transport.requests import Request
            scopes = [
                "https://www.googleapis.com/auth/datastore",
                "https://www.googleapis.com/auth/cloud-platform"
            ]
            creds = service_account.Credentials.from_service_account_info(key_dict, scopes=scopes)
            creds.refresh(Request())
            self.cached_token = creds.token
            self.token_expiry = now + 3500
            return self.cached_token
        except Exception:
            pass

        try:
            header = {"alg": "RS256", "typ": "JWT"}
            iat = int(now)
            payload = {
                "iss": key_dict["client_email"],
                "scope": "https://www.googleapis.com/auth/datastore https://www.googleapis.com/auth/cloud-platform",
                "aud": "https://oauth2.googleapis.com/token",
                "exp": iat + 3600,
                "iat": iat
            }
            def b64url(b):
                return base64.urlsafe_b64encode(b).decode("utf-8").rstrip("=")

            eh = b64url(json.dumps(header).encode("utf-8"))
            ep = b64url(json.dumps(payload).encode("utf-8"))
            si = f"{eh}.{ep}".encode("utf-8")
            with tempfile.NamedTemporaryFile("w", delete=False) as kf, tempfile.NamedTemporaryFile("wb", delete=False) as df:
                kf.write(key_dict["private_key"])
                kf.flush()
                df.write(si)
                df.flush()
                sig = subprocess.check_output(["openssl", "dgst", "-sha256", "-sign", kf.name, df.name])
            assertion = f"{eh}.{ep}.{b64url(sig)}"
            data = urllib.parse.urlencode({
                "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                "assertion": assertion
            }).encode("utf-8")
            req = urllib.request.Request("https://oauth2.googleapis.com/token", data=data, method="POST")
            with urllib.request.urlopen(req, timeout=15) as resp:
                res = json.loads(resp.read().decode("utf-8"))
                self.cached_token = res["access_token"]
                self.token_expiry = now + int(res.get("expires_in", 3600)) - 60
                return self.cached_token
        except Exception as ex:
            log.warning(f"[Firebase Cloud] Не удалось получить OAuth2 токен через OpenSSL: {ex}")
            return None

    def init_app(self, force_reload: bool = False) -> bool:
        if self.initialized and not force_reload:
            return True

        candidate_files = [
            BASE_DIR / "firebase-service-account.json",
            BASE_DIR / "firebase_credentials.json",
        ]
        try:
            candidate_files += sorted(list(BASE_DIR.glob("*firebase*adminsdk*.json")), key=lambda p: p.stat().st_mtime, reverse=True)
            candidate_files += sorted(list(BASE_DIR.glob("*proar-5a642*.json")), key=lambda p: p.stat().st_mtime, reverse=True)
        except Exception:
            pass

        cred_dict = None
        loaded_source = "встроенного ключа"

        for candidate in candidate_files:
            if candidate.exists() and candidate.is_file() and candidate.stat().st_size > 50:
                try:
                    with open(candidate, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        if "private_key" in data and "client_email" in data:
                            data["private_key"] = data["private_key"].replace("\\n", "\n")
                            cred_dict = data
                            loaded_source = candidate.name
                            self.active_key_id = data.get("private_key_id", "external")
                            break
                except Exception as ex:
                    log.warning(f"[Firebase] Ошибка чтения {candidate}: {ex}")

        if not cred_dict:
            cred_dict = dict(FIREBASE_SERVICE_ACCOUNT_CONFIG)
            cred_dict["private_key"] = cred_dict["private_key"].replace("\\n", "\n")
            self.active_key_id = cred_dict.get("private_key_id", "embedded")

        self.loaded_cred_dict = cred_dict
        self.project_id = cred_dict.get("project_id", "proar-5a642")

        if FIREBASE_ADMIN_AVAILABLE and fb_firestore and fb_credentials:
            try:
                if force_reload and self.app:
                    try:
                        firebase_admin.delete_app(self.app)
                    except Exception:
                        pass
                    self.app = None

                cred = fb_credentials.Certificate(cred_dict)
                try:
                    self.app = firebase_admin.get_app()
                except ValueError:
                    self.app = firebase_admin.initialize_app(cred, {"projectId": self.project_id})
                self.firestore_client = fb_firestore.client(app=self.app)
                log.info(f"[Firebase] ✅ Cloud Firestore SDK инициализирован ({loaded_source})")
            except Exception as e:
                log.warning(f"[Firebase] Не удалось запустить Firestore SDK, будет использован REST API: {e}")
                self.firestore_client = None

        self.initialized = True
        return True

    @staticmethod
    def is_valid_sqlite(path: Path) -> bool:
        if not path.exists() or path.stat().st_size < 100:
            return False
        try:
            with open(path, "rb") as f:
                header = f.read(16)
                return header == b"SQLite format 3\x00"
        except Exception:
            return False

    @staticmethod
    def _count_local_users(path: Path) -> int:
        if not path.exists():
            return 0
        try:
            c = sqlite3.connect(path)
            cnt = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            c.close()
            return int(cnt)
        except Exception:
            return 0

    def download_db_on_startup(self) -> bool:
        if not self.init_app():
            self._startup_download_error = True
            return False

        try:
            b64_data = None
            doc_found = False

            if self.firestore_client:
                try:
                    doc_ref = self.firestore_client.collection(self.collection_name).document(self.doc_name)
                    doc = doc_ref.get()
                    if doc.exists:
                        doc_found = True
                        data = doc.to_dict() or {}
                        b64_data = data.get("data_gzip_b64")
                    else:
                        self._cloud_doc_missing = True
                except Exception as ex_sdk:
                    log.warning(f"[Firebase] SDK get doc: {ex_sdk}, пробуем REST...")

            if not b64_data and not doc_found:
                token = self.get_access_token()
                if token:
                    doc_url = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents/{self.collection_name}/{self.doc_name}"
                    req = urllib.request.Request(doc_url, headers={"Authorization": f"Bearer {token}"})
                    try:
                        with urllib.request.urlopen(req, timeout=15) as r:
                            doc_json = json.loads(r.read().decode("utf-8"))
                            doc_found = True
                            fields = doc_json.get("fields", {})
                            b64_data = fields.get("data_gzip_b64", {}).get("stringValue")
                    except urllib.error.HTTPError as he:
                        if he.code == 404:
                            log.info(f"[Firebase] ℹ️ Документ {self.collection_name}/{self.doc_name} в Firestore пока не существует.")
                            self.last_sync_status = "База еще не выгружалась в Firestore"
                            self._cloud_doc_missing = True
                            self._startup_download_error = False
                            return False
                        else:
                            raise he

            if not doc_found and self._cloud_doc_missing:
                self.last_sync_status = "База еще не выгружалась в Firestore"
                self._startup_download_error = False
                return False

            if not b64_data:
                if doc_found:
                    log.warning("[Firebase] ⚠️ Документ в Firestore существует, но data_gzip_b64 пусто. Облако защищено.")
                    self._startup_download_error = True
                else:
                    self.last_sync_status = "База еще не выгружалась в Firestore"
                    self._cloud_doc_missing = True
                return False

            raw_bytes = gzip.decompress(base64.b64decode(b64_data))
            if not raw_bytes.startswith(b"SQLite format 3\x00"):
                log.error("[Firebase] ❌ Данные из Firestore не являются SQLite базой!")
                self._startup_download_error = True
                return False

            tmp_path = BASE_DIR / "base.db.tmp_download"
            with open(tmp_path, "wb") as f:
                f.write(raw_bytes)

            if DB_PATH.exists():
                try:
                    shutil.copy2(DB_PATH, BASE_DIR / "base.db.backup_local")
                except Exception:
                    pass

            shutil.move(tmp_path, DB_PATH)
            self.last_sync_ts = time.time()
            self.last_sync_size = len(raw_bytes)
            self._startup_download_error = False
            self._cloud_doc_missing = False
            self.last_sync_status = f"Восстановлена из Firestore ({len(raw_bytes):,} байт)"
            log.info(f"[Firebase] ✅ База base.db ({len(raw_bytes):,} байт) успешно восстановлена из Firestore!")
            return True
        except Exception as e:
            log.error(f"[Firebase] Ошибка скачивания base.db из Firestore: {e}")
            self.last_sync_status = self.format_error(e)
            self._startup_download_error = True
            return False

    def upload_db_to_cloud(self, force: bool = False) -> bool:
        if not self.init_app():
            return False

        with self._lock:
            try:
                if self._startup_download_error:
                    log.warning("[Firebase] 🛑 Anti-Wipe: при старте была ошибка чтения Firestore, автовыгрузка заблокирована.")
                    return False

                if not DB_PATH.exists() or DB_PATH.stat().st_size < 100:
                    return False

                if not self.is_valid_sqlite(DB_PATH):
                    return False

                # Защита от затирания непустой облачной базы пустой локальной
                if self._count_local_users(DB_PATH) == 0 and not self._cloud_doc_missing:
                    if self.firestore_client:
                        try:
                            snap = self.firestore_client.collection(self.collection_name).document(self.doc_name).get()
                            if snap.exists:
                                log.warning("[Firebase] 🛑 Anti-Wipe: локальная база пуста (0 игроков), а в Firestore уже есть база. Отмена!")
                                return False
                        except Exception:
                            pass

                current_size = DB_PATH.stat().st_size
                if not force and self.last_sync_ts > 0 and (time.time() - self.last_sync_ts < 15):
                    return True

                snapshot_path = BASE_DIR / "base.db.upload_snapshot"
                try:
                    src_conn = sqlite3.connect(DB_PATH)
                    dst_conn = sqlite3.connect(snapshot_path)
                    src_conn.backup(dst_conn)
                    dst_conn.close()
                    src_conn.close()
                    target_file = snapshot_path
                except Exception:
                    target_file = DB_PATH

                with open(target_file, "rb") as f:
                    raw_db = f.read()

                if snapshot_path.exists():
                    try:
                        snapshot_path.unlink()
                    except Exception:
                        pass

                if not raw_db.startswith(b"SQLite format 3\x00"):
                    return False

                compressed = gzip.compress(raw_db, compresslevel=9)
                b64_data = base64.b64encode(compressed).decode("ascii")
                sha256_hash = hashlib.sha256(raw_db).hexdigest()
                now_utc = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
                now_ts = time.time()

                saved = False

                if self.firestore_client:
                    try:
                        doc_ref = self.firestore_client.collection(self.collection_name).document(self.doc_name)
                        doc_ref.set({
                            "database_file": "base.db",
                            "file_size": current_size,
                            "compressed_size": len(compressed),
                            "sha256": sha256_hash,
                            "updated_at": now_utc,
                            "updated_ts": now_ts,
                            "data_gzip_b64": b64_data
                        })
                        saved = True
                    except Exception as ex_sdk:
                        log.warning(f"[Firebase] Ошибка сохранения через SDK: {ex_sdk}, переключение на REST...")

                if not saved:
                    token = self.get_access_token()
                    if not token:
                        raise RuntimeError("Не удалось получить OAuth2 токен для Firestore")

                    doc_url = f"https://firestore.googleapis.com/v1/projects/{self.project_id}/databases/(default)/documents/{self.collection_name}/{self.doc_name}"
                    doc_body = json.dumps({
                        "fields": {
                            "database_file": {"stringValue": "base.db"},
                            "file_size": {"integerValue": str(current_size)},
                            "compressed_size": {"integerValue": str(len(compressed))},
                            "sha256": {"stringValue": sha256_hash},
                            "updated_at": {"stringValue": now_utc},
                            "updated_ts": {"doubleValue": now_ts},
                            "data_gzip_b64": {"stringValue": b64_data}
                        }
                    }).encode("utf-8")
                    req = urllib.request.Request(doc_url, data=doc_body, headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json"
                    }, method="PATCH")
                    with urllib.request.urlopen(req, timeout=20) as resp:
                        if resp.status in (200, 201):
                            saved = True

                if saved:
                    self.last_sync_ts = time.time()
                    self.last_sync_size = current_size
                    self.last_sync_status = f"Синхронизировано в {datetime.datetime.now().strftime('%H:%M:%S')} ({current_size:,} байт)"
                    self._dirty = False
                    log.info(f"[Firebase] ☁️ База base.db сохранена в Cloud Firestore ({current_size:,} -> {len(compressed):,} байт)")
                    return True
                else:
                    raise RuntimeError("Firestore не подтвердил сохранение документа")
            except Exception as e:
                log.error(f"[Firebase] Ошибка выгрузки в Firestore: {e}")
                self.last_sync_status = self.format_error(e)
                return False

    def schedule_sync(self):
        self._dirty = True

    def start_periodic_sync(self, interval_seconds: int = 60):
        if self._sync_thread and self._sync_thread.is_alive():
            return

        def _worker():
            while not self._stop_event.is_set():
                self._stop_event.wait(interval_seconds)
                if self._stop_event.is_set():
                    break
                try:
                    self.upload_db_to_cloud(force=False)
                except Exception as e:
                    log.error(f"[Firebase Worker] Ошибка: {e}")

        self._sync_thread = threading.Thread(target=_worker, daemon=True, name="FirebaseSyncWorker")
        self._sync_thread.start()

    def stop(self):
        self._stop_event.set()
        if self.initialized:
            self.upload_db_to_cloud(force=False)

FirebaseStorageManager = FirebaseCloudManager
firebase_manager = FirebaseCloudManager()

def _on_shutdown():
    try:
        firebase_manager.upload_db_to_cloud(force=False)
    except Exception:
        pass

atexit.register(_on_shutdown)

# FSM Состояния
(
    WAIT_CLAN_TAG,
    WAIT_CLAN_NAME,
    WAIT_CLAN_DESC,
    WAIT_CLAN_TYPE,
    WAIT_CLAN_FEE,
    WAIT_ADMIN_GIVE_STARS_USER,
    WAIT_ADMIN_GIVE_STARS_AMOUNT,
    WAIT_ADMIN_GIVE_NFT_USER,
    WAIT_PROFILE_BG,
    WAIT_ADMIN_BAN_USER,
    WAIT_ADMIN_BAN_HOURS,
    WAIT_ADMIN_BAN_REASON,
    WAIT_ADMIN_UNBAN_USER,
    WAIT_CLAN_AVATAR,
    WAIT_CLAN_DONATE_STARS,
    WAIT_ADMIN_FIREBASE_JSON,
    WAIT_GIFT_TRANSFER_USER,
    WAIT_MARKET_OFFER_PRICE,
) = range(18)

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("nft_bot")

# ---------------------------------------------------------------------------
# Загрузка шрифтов
# ---------------------------------------------------------------------------

FONT_REGULAR_PATH = FONTS_DIR / "NotoSans.ttf"
FONT_BOLD_PATH = FONTS_DIR / "NotoSans-Bold.ttf"

def ensure_fonts_exist():
    if not FONT_REGULAR_PATH.exists():
        url = "https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSans/NotoSans-Regular.ttf"
        try:
            r = requests.get(url, timeout=15)
            if r.status_code == 200:
                FONT_REGULAR_PATH.write_bytes(r.content)
        except Exception as e:
            log.warning("Не удалось скачать шрифт Regular: %s", e)

    if not FONT_BOLD_PATH.exists():
        url = "https://github.com/googlefonts/noto-fonts/raw/main/hinted/ttf/NotoSans/NotoSans-Bold.ttf"
        try:
            r = requests.get(url, timeout=15)
            if r.status_code == 200:
                FONT_BOLD_PATH.write_bytes(r.content)
        except Exception as e:
            log.warning("Не удалось скачать шрифт Bold: %s", e)

ensure_fonts_exist()

# ---------------------------------------------------------------------------
# Очистка строк, цветные кнопки и компактное форматирование
# ---------------------------------------------------------------------------

try:
    _BTN_HAS_STYLE = "style" in inspect.signature(InlineKeyboardButton.__init__).parameters
except Exception:
    _BTN_HAS_STYLE = False

def make_btn(text: str, style: Optional[str] = None, **kwargs) -> InlineKeyboardButton:
    """Создаёт InlineKeyboardButton с поддержкой Bot API 9.4 color styles ('primary', 'success', 'danger')."""
    if style in ("primary", "success", "danger"):
        if _BTN_HAS_STYLE:
            kwargs["style"] = style
        else:
            api_kw = dict(kwargs.pop("api_kwargs", {}) or {})
            api_kw["style"] = style
            kwargs["api_kwargs"] = api_kw
    return InlineKeyboardButton(text, **kwargs)

async def get_bot_username(bot) -> str:
    global _BOT_USERNAME_CACHE
    if _BOT_USERNAME_CACHE:
        return _BOT_USERNAME_CACHE
    try:
        uname = getattr(bot, "username", None)
        if not uname:
            me = await bot.get_me()
            uname = me.username
        if uname:
            _BOT_USERNAME_CACHE = uname
            return uname
    except Exception:
        pass
    return "bot"

def clean_html(text: Optional[str]) -> str:
    if not text:
        return ""
    return html.escape(str(text))

def strip_all_emojis_for_image(
    text: Optional[str],
    fallback_username: Optional[str] = None,
    fallback_id: Optional[int] = None,
) -> str:
    emoji_pattern = re.compile(
        "["
        "\U00010000-\U0010FFFF"
        "\u200d"
        "\ufe0f"
        "\ufe0e"
        "\u2600-\u27bf"
        "\u2300-\u23ff"
        "\u2b50"
        "\u2b06"
        "\u2190-\u21ff"
        "\u2934-\u2935"
        "\u3297"
        "\u3299"
        "\u3030"
        "\u00a9"
        "\u00ae"
        "]+",
        flags=re.UNICODE
    )

    def _clean(raw: str) -> str:
        cleaned = emoji_pattern.sub("", raw)
        res = []
        for char in unicodedata.normalize('NFKC', cleaned):
            cat = unicodedata.category(char)
            if cat in ('So', 'Cn', 'Co', 'Sk', 'Cs', 'Cf'):
                continue
            # Оставляем только символы, которые гарантированно отображаются шрифтом (латиница, кириллица, цифры, пунктуация)
            code = ord(char)
            if (
                0x0020 <= code <= 0x024F
                or 0x0400 <= code <= 0x04FF
                or char in ('_', '-', '.', '@', '#', ' ', '№')
            ):
                res.append(char)
        return re.sub(r"\s+", " ", "".join(res)).strip()

    _placeholders = {"unknown", "player", "none", "null"}

    if text:
        cleaned_main = _clean(str(text))
        if cleaned_main and cleaned_main.lower() not in _placeholders:
            return cleaned_main

    if fallback_username:
        uname_clean = _clean(str(fallback_username).lstrip("@"))
        if uname_clean:
            return f"@{uname_clean}"

    if fallback_id is not None:
        return f"ID {fallback_id}"

    return "User"

def normalize_telegram_name(
    name: Optional[str],
    username: Optional[str] = None,
    user_id: Optional[int] = None,
) -> str:
    _placeholders = {"unknown", "player", "none", "null"}
    raw_name = (name or "").strip()
    if raw_name and raw_name.lower() not in _placeholders:
        cleaned = re.sub(r"[\(\[\{].*?[\)\]\}]", "", raw_name).strip()
        if not cleaned:
            cleaned = raw_name
        # Проверяем, не состоит ли имя только из пробелов/невидимых символов
        if re.sub(r"[\s\u200b-\u200f\u2060\ufeff]+", "", cleaned) and cleaned.lower() not in _placeholders:
            return cleaned

    if username:
        uname = str(username).strip().lstrip("@")
        if uname and uname.lower() not in _placeholders:
            return f"@{uname}"

    if user_id is not None:
        return f"ID {user_id}"

    return "User"

def fmt_stars_compact(stars: int) -> str:
    """Форматирует звёзды: от 10,000,000 сокращает в млн / млрд / трлн."""
    val = int(stars or 0)
    abs_v = abs(val)
    if abs_v >= 1_000_000_000_000:
        num = val / 1_000_000_000_000
        unit = "трлн"
    elif abs_v >= 1_000_000_000:
        num = val / 1_000_000_000
        unit = "млрд"
    elif abs_v >= 10_000_000:
        num = val / 1_000_000
        unit = "млн"
    else:
        return f"{val:,}"
    num_str = f"{num:.2f}".rstrip("0").rstrip(".")
    return f"{num_str} {unit}"

def fmt_stars_rub(stars: int) -> str:
    rub_val = int(round(stars * STAR_RUB_RATE))
    if abs(stars) >= 10_000_000:
        return f"{fmt_stars_compact(stars)} ⭐ (~{fmt_stars_compact(rub_val)} ₽)"
    return f"{stars:,} ⭐ (~{rub_val:,} ₽)"

def fmt_ton(ton: float) -> str:
    return f"{ton:.2f} TON (~{ton * TON_RUB_RATE:,.0f} ₽)"

def seconds_to_hms(sec: int) -> str:
    sec = max(0, sec)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    if h: return f"{h} ч {m} мин"
    if m: return f"{m} мин {s} сек"
    return f"{s} сек"

# ---------------------------------------------------------------------------
# NFT Каталог
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class GiftDef:
    key: str
    name: str
    stars: int
    chance: float
    xp: int
    model_group: str
    model_name: str

    @property
    def ton(self) -> float:
        return round((self.stars * STAR_RUB_RATE) / TON_RUB_RATE, 3)

    @property
    def rub(self) -> float:
        return round(self.stars * STAR_RUB_RATE, 2)


GIFTS: list[GiftDef] = [
    GiftDef("pepe_heart", "Plush Pepe (Пепе с сердцем)", 480_000, 0.0005, 120_000, "animals", "Животные и маскоты"),
    GiftDef("durov_dog", "Resistance Dog (Пёс Дурова)", 30_000, 0.005, 18_000, "animals", "Животные и маскоты"),
    GiftDef("hockey_mask", "Scared Cat (Маска кота)", 26_000, 0.006, 15_000, "animals", "Животные и маскоты"),
    GiftDef("teddy_patrick", "Irish Bear (Мишка-лепрекон)", 65, 10.00, 50, "animals", "Животные и маскоты"),
    GiftDef("teddy_heart_white", "New Year's Bear (Белый мишка)", 65, 10.00, 50, "animals", "Животные и маскоты"),
    GiftDef("teddy_santa", "Santa Bear (Мишка-Санта)", 65, 10.00, 50, "animals", "Животные и маскоты"),
    GiftDef("teddy_football", "Football Bear (Мишка-футболист)", 65, 10.00, 50, "animals", "Животные и маскоты"),
    GiftDef("bunny_teddy", "Easter Bear (Мишка-кролик)", 65, 10.00, 50, "animals", "Животные и маскоты"),
    GiftDef("teddy_soldier", "Bear Soldier (Мишка-солдат)", 65, 10.00, 50, "animals", "Животные и маскоты"),
    GiftDef("teddy_builder", "Polar Bear (Мишка-строитель)", 65, 10.00, 50, "animals", "Животные и маскоты"),
    GiftDef("clown_teddy", "Clown Bear (Мишка-клоун)", 65, 10.00, 50, "animals", "Животные и маскоты"),
    GiftDef("teddy_flowers", "Pretty Posy (Мишка с букетом)", 420, 6.00, 220, "animals", "Животные и маскоты"),
    GiftDef("hero_figure", "Durov Figure (Фигурка Дурова)", 42_000, 0.003, 28_000, "figures", "Фигурки и трофеи"),
    GiftDef("trophy_cup", "Algorithm Cup (Кубок Чемпиона)", 85_000, 0.002, 42_000, "figures", "Фигурки и трофеи"),
    GiftDef("cap_tg", "Durov's Cap (Кепка Дурова)", 38_000, 0.004, 24_000, "figures", "Фигурки и трофеи"),
    GiftDef("sunglasses", "Durov's Glasses (Очки Дурова)", 9_500, 0.020, 6_500, "figures", "Фигурки и трофеи"),
    GiftDef("torch", "Liberty Figure (Факел Свободы)", 400, 6.20, 210, "figures", "Фигурки и трофеи"),
    GiftDef("heart_lock_key", "Heart Locket (Сердце-замок)", 22_000, 0.008, 12_000, "artifacts", "Артефакты и украшения"),
    GiftDef("gem_crystal", "Astral Shard (Кристалл Алмаз)", 12_000, 0.015, 7_500, "artifacts", "Артефакты и украшения"),
    GiftDef("ring_silver", "Signet Ring (Серебряное кольцо)", 3_500, 0.70, 2_200, "artifacts", "Артефакты и украшения"),
    GiftDef("rose_bell_jar", "Eternal Rose (Роза под колпаком)", 2_600, 0.90, 1_700, "artifacts", "Артефакты и украшения"),
    GiftDef("crystal_ball", "Crystal Ball (Магический шар)", 1_300, 1.50, 900, "artifacts", "Артефакты и украшения"),
    GiftDef("mosque_moon", "Moon Pendant (Полумесяц)", 580, 4.00, 320, "artifacts", "Артефакты и украшения"),
    GiftDef("clover_green", "Clover Pin (Значок Клевер)", 420, 7.00, 190, "artifacts", "Артефакты и украшения"),
    GiftDef("pacifier_gold", "Hypno Lollipop (Золотая соска)", 340, 8.00, 150, "artifacts", "Артефакты и украшения"),
    GiftDef("skull_ghost", "Electric Skull (Призрачный череп)", 2_200, 1.10, 1_400, "mystic", "Мистика и Хэллоуин"),
    GiftDef("teddy_pumpkin", "Mad Pumpkin (Тыква Хэллоуин)", 1_150, 2.00, 700, "mystic", "Мистика и Хэллоуин"),
    GiftDef("broom_witch", "Flying Broom (Ведьмина метла)", 980, 2.20, 560, "mystic", "Мистика и Хэллоуин"),
    GiftDef("coffin", "Gravestone (Гробница)", 850, 2.50, 480, "mystic", "Мистика и Хэллоуин"),
    GiftDef("eye_evil", "Evil Eye (Глаз-оберег)", 680, 3.20, 380, "mystic", "Мистика и Хэллоуин"),
    GiftDef("briefcase", "Loot Bag (Дипломат)", 6_800, 0.40, 4_200, "festive", "Праздничные сувениры"),
    GiftDef("chocolate_box", "Berry Box (Коробка конфет)", 780, 2.80, 430, "festive", "Праздничные сувениры"),
    GiftDef("cupcake_bunny", "Bunny Muffin (Кекс-зайчик)", 690, 3.00, 370, "festive", "Праздничные сувениры"),
    GiftDef("fountain_pen", "Fine Pen (Золотое перо)", 650, 3.50, 350, "festive", "Праздничные сувениры"),
    GiftDef("candle", "Eternal Candle (Свеча)", 520, 4.20, 290, "festive", "Праздничные сувениры"),
    GiftDef("bday_calendar", "Desk Calendar (Календарь)", 510, 4.50, 280, "festive", "Праздничные сувениры"),
    GiftDef("bowtie", "Bow Tie (Бабочка)", 460, 5.00, 260, "festive", "Праздничные сувениры"),
    GiftDef("tg_rashguard", "Swag Bag (Рашгард)", 450, 5.20, 250, "festive", "Праздничные сувениры"),
    GiftDef("heart_cookie", "Cookie Heart (Пряник-сердце)", 430, 5.50, 240, "festive", "Праздничные сувениры"),
    GiftDef("easter_cake", "Homemade Cake (Кулич)", 400, 6.50, 210, "festive", "Праздничные сувениры"),
    GiftDef("peace_dove_stamp", "Dove of Peace (Марка мира)", 390, 6.80, 200, "festive", "Праздничные сувениры"),
    GiftDef("happy_bday_sign", "Star Notepad (Блокнот B-day)", 375, 7.20, 180, "festive", "Праздничные сувениры"),
    GiftDef("sneakers_black", "Fresh Socks (Кроссовки)", 360, 7.50, 170, "festive", "Праздничные сувениры"),
    GiftDef("coconut_drink", "Holiday Drink (Коктейль)", 350, 7.80, 160, "festive", "Праздничные сувениры"),
    GiftDef("egg_butterfly", "Easter Egg (Пасхальное яйцо)", 320, 8.20, 140, "festive", "Праздничные сувениры"),
    GiftDef("new_year_2025", "Big Year (Цифры 2025)", 310, 8.50, 130, "festive", "Праздничные сувениры"),
    GiftDef("candy_cane", "Candy Cane (Леденец)", 290, 8.80, 120, "festive", "Праздничные сувениры"),
    GiftDef("i_love_u_heart", "I Love You (Сердце)", 65, 10.00, 50, "festive", "Праздничные сувениры"),
    GiftDef("xmas_tree", "Christmas Tree (Ёлочка)", 65, 10.00, 50, "festive", "Праздничные сувениры"),
]

GIFTS_BY_KEY = {g.key: g for g in GIFTS}

MODEL_GROUPS = {
    "animals": "Животные и маскоты",
    "figures": "Фигурки и трофеи",
    "artifacts": "Артефакты и украшения",
    "mystic": "Мистика и Хэллоуин",
    "festive": "Праздничные сувениры",
}

PRICE_TIERS = {
    "low": ("До 500 ⭐", 0, 500),
    "mid": ("500 — 2,000 ⭐", 501, 2000),
    "high": ("2,000 — 15,000 ⭐", 2001, 15000),
    "ultra": ("От 15,000 ⭐", 15001, 10000000),
}

def get_gifts_filtered(filter_type: str, filter_key: str) -> List[GiftDef]:
    if filter_type == "model":
        if filter_key in MODEL_GROUPS:
            return [g for g in GIFTS if g.model_group == filter_key]
    elif filter_type == "gift":
        if filter_key in GIFTS_BY_KEY:
            return [GIFTS_BY_KEY[filter_key]]
    elif filter_type == "price":
        if filter_key in PRICE_TIERS:
            _, min_p, max_p = PRICE_TIERS[filter_key]
            return [g for g in GIFTS if min_p <= g.stars <= max_p]
    return GIFTS

def roll_gift_from_pool(pool: List[GiftDef], bonus_pct: float = 0.0) -> GiftDef:
    total_w = 0.0
    weights = []
    bonus_multiplier = 1.0 + (bonus_pct / 100.0)

    for g in pool:
        if g.stars >= 1000:
            w = g.chance * bonus_multiplier
        else:
            w = g.chance
        weights.append(w)
        total_w += w

    r = random.uniform(0, total_w)
    upto = 0.0
    for idx, g in enumerate(pool):
        upto += weights[idx]
        if upto >= r:
            return g
    return pool[-1]

def gift_image_path(key: str) -> Optional[Path]:
    for ext in [".webp", ".png", ".jpg", ".jpeg"]:
        p = IMAGES_DIR / f"{key}{ext}"
        if p.exists():
            return p
    return None

# ---------------------------------------------------------------------------
# КАТАЛОГ УЛУЧШЕНИЙ PLUSH PEPE: 50 МОДЕЛЕЙ И 60 ФОНОВ (TELEGIFTER.RU)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class PlushModelDef:
    name: str
    filename: str
    chance_pct: float
    price_mult: float

@dataclass(frozen=True)
class BackdropDef:
    key: str
    name: str
    palette: str
    center_hex: str
    edge_hex: str
    chance_pct: float
    price_mult: float
    rarity_label: str

PLUSHPEPE_MODELS: list[PlushModelDef] = [
    PlushModelDef("Amalgam", "Amalgam.webp", 2.0, 1.18),
    PlushModelDef("Aqua Plush", "Aqua Plush.webp", 3.0, 1.06),
    PlushModelDef("Barcelona", "Barcelona.webp", 2.0, 1.15),
    PlushModelDef("Bavaria", "Bavaria.webp", 2.0, 1.15),
    PlushModelDef("Birmingham", "Birmingham.webp", 2.0, 1.14),
    PlushModelDef("Christmas", "Christmas.webp", 2.0, 1.15),
    PlushModelDef("Cold Heart", "Cold Heart.webp", 3.0, 1.08),
    PlushModelDef("Cozy Galaxy", "Cozy Galaxy.webp", 1.0, 1.28),
    PlushModelDef("Donatello", "Donatello.webp", 1.0, 1.25),
    PlushModelDef("Eggplant", "Eggplant.webp", 3.0, 1.05),
    PlushModelDef("Emerald Plush", "Emerald Plush.webp", 1.0, 1.26),
    PlushModelDef("Emo Boi", "Emo Boi.webp", 2.0, 1.16),
    PlushModelDef("Fifty Shades", "Fifty Shades.webp", 1.0, 1.30),
    PlushModelDef("Frozen", "Frozen.webp", 2.0, 1.16),
    PlushModelDef("Gucci Leap", "Gucci Leap.webp", 1.0, 1.28),
    PlushModelDef("Gummy Frog", "Gummy Frog.webp", 3.0, 1.05),
    PlushModelDef("Hothead", "Hothead.webp", 3.0, 1.07),
    PlushModelDef("Hue Jester", "Hue Jester.webp", 3.0, 1.07),
    PlushModelDef("Kung Fu Pepe", "Kung Fu Pepe.webp", 2.0, 1.16),
    PlushModelDef("Leonardo", "Leonardo.webp", 1.0, 1.25),
    PlushModelDef("Louis Vuittoad", "Louis Vuittoad.webp", 1.0, 1.30),
    PlushModelDef("Magnate", "Magnate.webp", 1.0, 1.27),
    PlushModelDef("Marble", "Marble.webp", 2.0, 1.16),
    PlushModelDef("Midas Pepe", "Midas Pepe.webp", 1.0, 1.32),
    PlushModelDef("Milano", "Milano.webp", 2.0, 1.14),
    PlushModelDef("Ninja Mike", "Ninja Mike.webp", 1.0, 1.25),
    PlushModelDef("Pepe La Rana", "Pepe La Rana.webp", 2.0, 1.12),
    PlushModelDef("Pepemint", "Pepemint.webp", 3.0, 1.06),
    PlushModelDef("Pink Galaxy", "Pink Galaxy.webp", 2.0, 1.18),
    PlushModelDef("Pink Latex", "Pink Latex.webp", 2.0, 1.15),
    PlushModelDef("Poison Dart", "Poison Dart.webp", 3.0, 1.08),
    PlushModelDef("Polka Dots", "Polka Dots.webp", 3.0, 1.05),
    PlushModelDef("Princess", "Princess.webp", 2.0, 1.14),
    PlushModelDef("Pumpkin", "Pumpkin.webp", 3.0, 1.06),
    PlushModelDef("Puppy Pug", "Puppy Pug.webp", 1.0, 1.24),
    PlushModelDef("Raphael", "Raphael.webp", 1.0, 1.25),
    PlushModelDef("Red Menace", "Red Menace.webp", 3.0, 1.08),
    PlushModelDef("Red Pepple", "Red Pepple.webp", 2.0, 1.13),
    PlushModelDef("Santa Pepe", "Santa Pepe.webp", 2.0, 1.14),
    PlushModelDef("Sketchy", "Sketchy.webp", 2.0, 1.17),
    PlushModelDef("Spectrum", "Spectrum.webp", 3.0, 1.08),
    PlushModelDef("Steel Frog", "Steel Frog.webp", 1.0, 1.28),
    PlushModelDef("Stripes", "Stripes.webp", 2.0, 1.12),
    PlushModelDef("Sunset", "Sunset.webp", 2.0, 1.13),
    PlushModelDef("Toading...", "Toading....webp", 1.0, 1.26),
    PlushModelDef("Tropical", "Tropical.webp", 3.0, 1.05),
    PlushModelDef("Two Face", "Two Face.webp", 2.0, 1.18),
    PlushModelDef("X-Ray", "X-Ray.webp", 2.0, 1.20),
    PlushModelDef("Yellow Hug", "Yellow Hug.webp", 3.0, 1.05),
    PlushModelDef("Yellow Purp", "Yellow Purp.webp", 2.0, 1.12),
]

PLUSHPEPE_MODELS_BY_NAME = {m.name: m for m in PLUSHPEPE_MODELS}

# 61 фон: Радужный (Мифический x100, реже Чёрного: 0.05%) + 60 официальных палитр (суммарно 100.00%).
PLUSHPEPE_BACKDROPS: list[BackdropDef] = [
    # Мифический радужный фон (0.05%, x100 к цене)
    BackdropDef("rainbow", "Rainbow", "Переливающийся радужный", "#FF4D8D", "#6366F1", 0.05, 100.0, "Мифический"),

    # Ультра-редкие чёрные и серые (0.15% - 0.50%)
    BackdropDef("black", "Black", "Глубокий чёрный", "#363738", "#0E0F0F", 0.15, 10.5, "Ультра-редкий"),
    BackdropDef("onyx_black", "Onyx Black", "Ониксовый чёрный", "#4D5254", "#313638", 0.20, 9.5, "Ультра-редкий"),
    BackdropDef("battleship_grey", "Battleship Grey", "Стальной серый", "#8C8C85", "#6C6C66", 0.25, 8.8, "Ультра-редкий"),
    BackdropDef("steel_grey", "Steel Grey", "Холодный серый", "#97A2AC", "#63727C", 0.30, 8.4, "Ультра-редкий"),
    BackdropDef("pure_gold", "Pure Gold", "Чистое золото", "#CCAB41", "#987B32", 0.35, 8.2, "Ультра-редкий"),
    BackdropDef("roman_silver", "Roman Silver", "Римское серебро", "#A3A8B5", "#7C808A", 0.40, 7.6, "Ультра-редкий"),
    BackdropDef("platinum", "Platinum", "Платиновый серый", "#B2AEA7", "#88847E", 0.45, 7.2, "Ультра-редкий"),
    BackdropDef("ivory_white", "Ivory White", "Слоновая кость", "#BAB6B1", "#A19D97", 0.50, 6.8, "Ультра-редкий"),

    # Редкие тёмные и благородные (0.60% - 1.15%)
    BackdropDef("satin_gold", "Satin Gold", "Сатиновое золото", "#BF9B47", "#8D7739", 0.60, 6.2, "Редкий"),
    BackdropDef("midnight_blue", "Midnight Blue", "Полуночный синий", "#5C6985", "#354057", 0.65, 5.8, "Редкий"),
    BackdropDef("indigo_dye", "Indigo Dye", "Глубокий индиго", "#537991", "#416479", 0.70, 5.5, "Редкий"),
    BackdropDef("burgundy", "Burgundy", "Благородный бордо", "#A35E66", "#6D414A", 0.75, 5.2, "Редкий"),
    BackdropDef("chocolate", "Chocolate", "Шоколадный", "#A46E58", "#74443B", 0.80, 5.0, "Редкий"),
    BackdropDef("chestnut", "Chestnut", "Каштановый", "#BE6F54", "#994838", 0.85, 4.8, "Редкий"),
    BackdropDef("rosewood", "Rosewood", "Палисандр", "#B77A77", "#814C52", 0.90, 4.6, "Редкий"),
    BackdropDef("cappuccino", "Cappuccino", "Капучино", "#B1907E", "#7C6356", 0.95, 4.4, "Редкий"),
    BackdropDef("silver_blue", "Silver Blue", "Серебристо-синий", "#80A4B8", "#607C91", 1.00, 4.3, "Редкий"),
    BackdropDef("moonstone", "Moonstone", "Лунный камень", "#7EB1B4", "#588390", 1.05, 4.2, "Редкий"),
    BackdropDef("desert_sand", "Desert Sand", "Песчаный", "#B39F82", "#7E735B", 1.10, 4.0, "Редкий"),
    BackdropDef("pine_green", "Pine Green", "Хвойный зелёный", "#6BA97C", "#3E7970", 1.15, 3.9, "Редкий"),

    # Необычные насыщенные (1.25% - 1.85%)
    BackdropDef("dark_lilac", "Dark Lilac", "Тёмно-сиреневый", "#B17DA5", "#8C577A", 1.25, 3.8, "Необычный"),
    BackdropDef("english_violet", "English Violet", "Английский фиолет", "#B186BB", "#875A91", 1.30, 3.7, "Необычный"),
    BackdropDef("purple", "Purple", "Пурпурный", "#AE6CAE", "#844784", 1.35, 3.6, "Необычный"),
    BackdropDef("copper", "Copper", "Медный", "#D08656", "#9D6531", 1.40, 3.5, "Необычный"),
    BackdropDef("hunter_green", "Hunter Green", "Лесной зелёный", "#8FAE78", "#4B825B", 1.45, 3.4, "Необычный"),
    BackdropDef("pistachio", "Pistachio", "Фисташковый", "#97B07C", "#5C814C", 1.50, 3.3, "Необычный"),
    BackdropDef("khaki_green", "Khaki Green", "Хаки", "#ADB070", "#6B7D54", 1.50, 3.3, "Необычный"),
    BackdropDef("light_olive", "Light Olive", "Светло-оливковый", "#C2AF64", "#887E45", 1.55, 3.2, "Необычный"),
    BackdropDef("french_blue", "French Blue", "Французский синий", "#5C9BC4", "#37739A", 1.60, 3.1, "Необычный"),
    BackdropDef("cobalt_blue", "Cobalt Blue", "Кобальтовый синий", "#6088CF", "#5162B8", 1.65, 3.1, "Необычный"),
    BackdropDef("sapphire", "Sapphire", "Сапфировый", "#58A3C8", "#5379C2", 1.70, 3.0, "Необычный"),
    BackdropDef("navy_blue", "Navy Blue", "Тёмно-морской", "#6C9EDD", "#5C6EC9", 1.70, 3.0, "Необычный"),
    BackdropDef("grape", "Grape", "Виноградный", "#9D74C1", "#794DA0", 1.75, 2.9, "Необычный"),
    BackdropDef("mystic_pearl", "Mystic Pearl", "Мистический жемчуг", "#D08B6D", "#B05770", 1.80, 2.9, "Необычный"),
    BackdropDef("pacific_cyan", "Pacific Cyan", "Тихоокеанский циан", "#5ABEA6", "#3D95BA", 1.80, 2.8, "Необычный"),
    BackdropDef("turquoise", "Turquoise", "Бирюзовый", "#5EC0B8", "#3D928E", 1.85, 2.8, "Необычный"),

    # Обычные яркие и неоновые (2.15% - 2.85%)
    BackdropDef("aquamarine", "Aquamarine", "Яркий аквамарин", "#60B195", "#46ABB4", 2.15, 2.7, "Обычный"),
    BackdropDef("jade_green", "Jade Green", "Яркий нефритовый", "#55C49C", "#3B9977", 2.20, 2.7, "Обычный"),
    BackdropDef("emerald", "Emerald", "Яркий изумрудный", "#78C585", "#42A171", 2.25, 2.6, "Обычный"),
    BackdropDef("pacific_green", "Pacific Green", "Тихоокеанский зелёный", "#6FC793", "#3B9C84", 2.30, 2.6, "Обычный"),
    BackdropDef("malachite", "Malachite", "Малахитовый", "#95B457", "#3D9755", 2.35, 2.5, "Обычный"),
    BackdropDef("shamrock_green", "Shamrock Green", "Изумрудный трилистник", "#8AB163", "#559345", 2.40, 2.5, "Обычный"),
    BackdropDef("mint_green", "Mint Green", "Яркая мята", "#7ECB82", "#459E5A", 2.45, 2.5, "Обычный"),
    BackdropDef("lemongrass", "Lemongrass", "Яркий лемонграсс", "#AEB85A", "#559345", 2.50, 2.4, "Обычный"),
    BackdropDef("azure_blue", "Azure Blue", "Яркий лазурный", "#5DB1CB", "#448BAB", 2.50, 2.4, "Обычный"),
    BackdropDef("sky_blue", "Sky Blue", "Небесно-голубой", "#58B4C8", "#538BC2", 2.55, 2.4, "Обычный"),
    BackdropDef("neon_blue", "Neon Blue", "Неоновый синий", "#7596F9", "#6862E4", 2.55, 2.4, "Обычный"),
    BackdropDef("cyberpunk", "Cyberpunk", "Неоновый киберпанк", "#858FF3", "#865FD3", 2.60, 2.3, "Обычный"),
    BackdropDef("electric_indigo", "Electric Indigo", "Электрический индиго", "#A980F3", "#5B62D8", 2.60, 2.3, "Обычный"),
    BackdropDef("lavender", "Lavender", "Яркий лавандовый", "#B789E4", "#8A5ABC", 2.65, 2.3, "Обычный"),
    BackdropDef("electric_purple", "Electric Purple", "Электрический фиолет", "#CA70C6", "#9662D4", 2.65, 2.3, "Обычный"),
    BackdropDef("fandango", "Fandango", "Яркий фанданго", "#E28AB6", "#A4588B", 2.70, 2.2, "Обычный"),
    BackdropDef("raspberry", "Raspberry", "Яркий малиновый", "#E07B85", "#B65980", 2.70, 2.2, "Обычный"),
    BackdropDef("strawberry", "Strawberry", "Клубничный", "#DD8E6F", "#B75A60", 2.75, 2.2, "Обычный"),
    BackdropDef("coral_red", "Coral Red", "Яркий коралловый", "#DA896B", "#C4654F", 2.75, 2.2, "Обычный"),
    BackdropDef("persimmon", "Persimmon", "Яркая хурма", "#E7A75A", "#C5675F", 2.80, 2.1, "Обычный"),
    BackdropDef("carrot_juice", "Carrot Juice", "Морковный фреш", "#DB9867", "#C76F4F", 2.80, 2.1, "Обычный"),
    BackdropDef("orange", "Orange", "Яркий апельсиновый", "#D19A3A", "#C06F47", 2.85, 2.1, "Обычный"),
    BackdropDef("caramel", "Caramel", "Карамельный", "#D09932", "#B77431", 2.85, 2.1, "Обычный"),
    BackdropDef("amber", "Amber", "Яркий янтарный", "#DAB345", "#B1802A", 2.80, 2.1, "Обычный"),
]

BACKDROPS_BY_KEY = {b.key: b for b in PLUSHPEPE_BACKDROPS}

# Цветовые семейства моделей и фонов для системы МОНОХРОМ
MODEL_COLOR_FAMILIES: dict[str, str] = {
    "Aqua Plush": "blue",
    "Cold Heart": "blue",
    "Frozen": "blue",
    "Leonardo": "blue",
    "Toading...": "blue",
    "Hothead": "red",
    "Red Menace": "red",
    "Red Pepple": "red",
    "Raphael": "red",
    "Santa Pepe": "red",
    "Christmas": "red",
    "Emerald Plush": "green",
    "Gummy Frog": "green",
    "Pepe La Rana": "green",
    "Pepemint": "green",
    "Poison Dart": "green",
    "Tropical": "green",
    "Kung Fu Pepe": "green",
    "Eggplant": "purple",
    "Donatello": "purple",
    "Cozy Galaxy": "purple",
    "Pink Galaxy": "pink",
    "Pink Latex": "pink",
    "Princess": "pink",
    "Midas Pepe": "gold",
    "Yellow Hug": "gold",
    "Puppy Pug": "gold",
    "Pumpkin": "orange",
    "Sunset": "orange",
    "Ninja Mike": "orange",
    "Emo Boi": "dark",
    "Fifty Shades": "dark",
    "Steel Frog": "dark",
    "X-Ray": "dark",
    "Sketchy": "white",
    "Marble": "white",
}

BACKDROP_COLOR_FAMILIES: dict[str, str] = {
    "black": "dark",
    "onyx_black": "dark",
    "battleship_grey": "dark",
    "steel_grey": "dark",
    "roman_silver": "dark",
    "platinum": "dark",
    "ivory_white": "white",
    "pure_gold": "gold",
    "satin_gold": "gold",
    "desert_sand": "gold",
    "amber": "gold",
    "caramel": "gold",
    "copper": "orange",
    "persimmon": "orange",
    "carrot_juice": "orange",
    "orange": "orange",
    "midnight_blue": "blue",
    "indigo_dye": "blue",
    "silver_blue": "blue",
    "moonstone": "blue",
    "french_blue": "blue",
    "cobalt_blue": "blue",
    "sapphire": "blue",
    "navy_blue": "blue",
    "pacific_cyan": "blue",
    "turquoise": "blue",
    "aquamarine": "blue",
    "azure_blue": "blue",
    "sky_blue": "blue",
    "neon_blue": "blue",
    "pine_green": "green",
    "hunter_green": "green",
    "pistachio": "green",
    "khaki_green": "green",
    "light_olive": "green",
    "jade_green": "green",
    "emerald": "green",
    "pacific_green": "green",
    "malachite": "green",
    "shamrock_green": "green",
    "mint_green": "green",
    "lemongrass": "green",
    "burgundy": "red",
    "strawberry": "red",
    "coral_red": "red",
    "dark_lilac": "purple",
    "english_violet": "purple",
    "purple": "purple",
    "grape": "purple",
    "cyberpunk": "purple",
    "electric_indigo": "purple",
    "lavender": "purple",
    "electric_purple": "purple",
    "fandango": "pink",
    "raspberry": "pink",
    "mystic_pearl": "pink",
    "rosewood": "pink",
}

COLOR_FAMILY_RU: dict[str, str] = {
    "blue": "Синий",
    "red": "Красный",
    "green": "Зелёный",
    "purple": "Фиолетовый",
    "pink": "Розовый",
    "gold": "Золотой",
    "orange": "Оранжевый",
    "dark": "Тёмный",
    "white": "Светлый",
}

def is_monochrome_combo(model_name: Optional[str], backdrop_key: Optional[str]) -> bool:
    if not model_name or not backdrop_key or backdrop_key == "rainbow":
        return False
    m_fam = MODEL_COLOR_FAMILIES.get(model_name)
    b_fam = BACKDROP_COLOR_FAMILIES.get(backdrop_key)
    return bool(m_fam and b_fam and m_fam == b_fam)

def get_monochrome_combo_info(model_name: Optional[str], backdrop_key: Optional[str]) -> Tuple[bool, str]:
    if not model_name or not backdrop_key or backdrop_key == "rainbow":
        return False, ""
    m_fam = MODEL_COLOR_FAMILIES.get(model_name) or ""
    b_fam = BACKDROP_COLOR_FAMILIES.get(backdrop_key) or ""
    if m_fam and b_fam and m_fam == b_fam:
        return True, m_fam
    return False, ""

MARKET_PRICE_TIERS = {
    "m1": ("1,000 — 500,000 ⭐", 1_000, 500_000),
    "m2": ("500,001 — 2,000,000 ⭐", 500_001, 2_000_000),
    "m3": ("2,000,001 — 10,000,000 ⭐", 2_000_001, 10_000_000),
    "m4": ("От 10,000,001 ⭐", 10_000_001, MARKET_MAX_PRICE),
}

def plush_model_image_path(filename: str) -> Optional[Path]:
    if not filename:
        return None
    p = PLUSHPEPE_MODELS_DIR / filename
    if p.exists():
        return p
    return None

def roll_plush_model() -> PlushModelDef:
    available = [m for m in PLUSHPEPE_MODELS if plush_model_image_path(m.filename) is not None]
    pool = available if available else PLUSHPEPE_MODELS
    weights = [m.chance_pct for m in pool]
    return random.choices(pool, weights=weights, k=1)[0]

def roll_backdrop() -> BackdropDef:
    weights = [b.chance_pct for b in PLUSHPEPE_BACKDROPS]
    return random.choices(PLUSHPEPE_BACKDROPS, weights=weights, k=1)[0]

def calculate_upgraded_stars(base_stars: int, model: PlushModelDef, backdrop: BackdropDef) -> int:
    mono_mult = MONO_PRICE_MULT if is_monochrome_combo(model.name, backdrop.key) else 1.0
    raw = base_stars * backdrop.price_mult * model.price_mult * mono_mult
    return max(500_000, int(round(raw / 10_000) * 10_000))

def parse_hex_rgb(hex_str: str, fallback: Tuple[int, int, int] = (40, 48, 64)) -> Tuple[int, int, int]:
    try:
        s = (hex_str or "").strip().lstrip("#")
        if len(s) == 6:
            return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))
    except Exception:
        pass
    return fallback

def calculate_xp_level_info(total_xp: int) -> Tuple[int, int, int, float]:
    level = 0
    current_xp = total_xp
    req_xp = 1000

    while current_xp >= req_xp:
        current_xp -= req_xp
        level += 1
        req_xp = int(req_xp + 1500 + (level * 500))

    ratio = min(1.0, max(0.0, current_xp / req_xp))
    return level, current_xp, req_xp, ratio

def calculate_clan_level_info(total_xp: int) -> Tuple[int, int, int, float, float]:
    level = 0
    current_xp = max(0, total_xp)
    req_xp = 10000

    while current_xp >= req_xp and level < 100:
        current_xp -= req_xp
        level += 1
        req_xp = int(10000 + (level * 1800) + (level ** 1.85 * 60))

    if level >= 100:
        level = 100
        ratio = 1.0
        req_xp = current_xp
    else:
        ratio = min(1.0, max(0.0, current_xp / req_xp)) if req_xp > 0 else 1.0

    bonus_pct = round(1.0 + (level / 100.0) * 44.0, 1)
    return level, current_xp, req_xp, ratio, bonus_pct

# ---------------------------------------------------------------------------
# База данных SQLite
# ---------------------------------------------------------------------------

def db_connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    firebase_manager.schedule_sync()
    return conn

def db_init() -> None:
    conn = db_connect()
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS global_id_seq (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_type TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS bot_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS users (
                id_num INTEGER UNIQUE NOT NULL,
                user_id INTEGER UNIQUE NOT NULL,
                username TEXT,
                first_name TEXT,
                balance_stars INTEGER NOT NULL DEFAULT 0,
                xp INTEGER NOT NULL DEFAULT 0,
                hide_top INTEGER NOT NULL DEFAULT 0,
                hide_collection INTEGER NOT NULL DEFAULT 0,
                auto_sell INTEGER NOT NULL DEFAULT 0,
                max_inventory INTEGER NOT NULL DEFAULT 25,
                last_drop_ts INTEGER NOT NULL DEFAULT 0,
                last_daily_bonus_ts INTEGER NOT NULL DEFAULT 0,
                total_drops INTEGER NOT NULL DEFAULT 0,
                total_sold INTEGER NOT NULL DEFAULT 0,
                clan_id INTEGER DEFAULT NULL,
                bg_image_path TEXT DEFAULT NULL,
                is_banned INTEGER NOT NULL DEFAULT 0,
                ban_until_ts INTEGER NOT NULL DEFAULT 0,
                ban_reason TEXT NOT NULL DEFAULT '',
                ban_hours INTEGER NOT NULL DEFAULT 0,
                privacy_accepted INTEGER NOT NULL DEFAULT 0,
                privacy_accepted_ts INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS collection (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                gift_key TEXT NOT NULL,
                obtained_ts INTEGER NOT NULL,
                is_favorite INTEGER NOT NULL DEFAULT 0,
                is_upgraded INTEGER NOT NULL DEFAULT 0,
                model_name TEXT DEFAULT NULL,
                backdrop_key TEXT DEFAULT NULL,
                upgraded_stars INTEGER NOT NULL DEFAULT 0,
                upgrade_num INTEGER NOT NULL DEFAULT 0,
                is_listed INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            );

            CREATE TABLE IF NOT EXISTS market_listings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                collection_id INTEGER NOT NULL,
                seller_id INTEGER NOT NULL,
                gift_key TEXT NOT NULL,
                model_name TEXT NOT NULL,
                backdrop_key TEXT NOT NULL,
                upgraded_stars INTEGER NOT NULL DEFAULT 0,
                upgrade_num INTEGER NOT NULL DEFAULT 0,
                price_stars INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'active',
                buyer_id INTEGER DEFAULT NULL,
                created_ts INTEGER NOT NULL,
                sold_ts INTEGER DEFAULT NULL
            );

            CREATE TABLE IF NOT EXISTS market_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                listing_id INTEGER NOT NULL,
                seller_id INTEGER NOT NULL,
                buyer_id INTEGER NOT NULL,
                gift_key TEXT NOT NULL,
                model_name TEXT NOT NULL,
                backdrop_key TEXT NOT NULL,
                price_stars INTEGER NOT NULL,
                fee_stars INTEGER NOT NULL,
                seller_received_stars INTEGER NOT NULL,
                sold_ts INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS pending_drops (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                chat_id INTEGER NOT NULL,
                gift_key TEXT NOT NULL,
                created_ts INTEGER NOT NULL,
                resolved INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS clans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_num INTEGER UNIQUE,
                owner_id INTEGER NOT NULL,
                tag TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                description TEXT DEFAULT '',
                type TEXT NOT NULL DEFAULT 'public',
                entry_fee INTEGER NOT NULL DEFAULT 0,
                max_members INTEGER NOT NULL DEFAULT 15,
                xp INTEGER NOT NULL DEFAULT 0,
                donated_stars INTEGER NOT NULL DEFAULT 0,
                spent_stars INTEGER NOT NULL DEFAULT 0,
                avatar_path TEXT DEFAULT NULL,
                favorite_keys TEXT DEFAULT '',
                last_daily_xp_ts INTEGER NOT NULL DEFAULT 0,
                created_ts INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS clan_gifts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                clan_id INTEGER NOT NULL,
                donor_user_id INTEGER NOT NULL,
                gift_key TEXT NOT NULL,
                donated_ts INTEGER NOT NULL,
                is_favorite INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY (clan_id) REFERENCES clans(id)
            );

            CREATE TABLE IF NOT EXISTS clan_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                clan_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                created_ts INTEGER NOT NULL,
                UNIQUE(clan_id, user_id)
            );

            CREATE TABLE IF NOT EXISTS star_checks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                creator_id INTEGER NOT NULL,
                amount_stars INTEGER NOT NULL,
                target_username TEXT NOT NULL DEFAULT '',
                target_user_id INTEGER DEFAULT NULL,
                status TEXT NOT NULL DEFAULT 'draft',
                claimed_by INTEGER DEFAULT NULL,
                rendered INTEGER NOT NULL DEFAULT 0,
                created_ts INTEGER NOT NULL,
                claimed_ts INTEGER DEFAULT NULL
            );
            """
        )

        coll_cols = [row["name"] for row in conn.execute("PRAGMA table_info(collection)").fetchall()]
        if "is_upgraded" not in coll_cols:
            conn.execute("ALTER TABLE collection ADD COLUMN is_upgraded INTEGER NOT NULL DEFAULT 0;")
        if "model_name" not in coll_cols:
            conn.execute("ALTER TABLE collection ADD COLUMN model_name TEXT DEFAULT NULL;")
        if "backdrop_key" not in coll_cols:
            conn.execute("ALTER TABLE collection ADD COLUMN backdrop_key TEXT DEFAULT NULL;")
        if "upgraded_stars" not in coll_cols:
            conn.execute("ALTER TABLE collection ADD COLUMN upgraded_stars INTEGER NOT NULL DEFAULT 0;")
        if "upgrade_num" not in coll_cols:
            conn.execute("ALTER TABLE collection ADD COLUMN upgrade_num INTEGER NOT NULL DEFAULT 0;")
        if "is_listed" not in coll_cols:
            conn.execute("ALTER TABLE collection ADD COLUMN is_listed INTEGER NOT NULL DEFAULT 0;")

        clan_cols = [row["name"] for row in conn.execute("PRAGMA table_info(clans)").fetchall()]
        if "id_num" not in clan_cols:
            conn.execute("ALTER TABLE clans ADD COLUMN id_num INTEGER DEFAULT NULL;")
        if "xp" not in clan_cols:
            conn.execute("ALTER TABLE clans ADD COLUMN xp INTEGER NOT NULL DEFAULT 0;")
        if "donated_stars" not in clan_cols:
            conn.execute("ALTER TABLE clans ADD COLUMN donated_stars INTEGER NOT NULL DEFAULT 0;")
        if "spent_stars" not in clan_cols:
            conn.execute("ALTER TABLE clans ADD COLUMN spent_stars INTEGER NOT NULL DEFAULT 0;")
        if "avatar_path" not in clan_cols:
            conn.execute("ALTER TABLE clans ADD COLUMN avatar_path TEXT DEFAULT NULL;")
        if "favorite_keys" not in clan_cols:
            conn.execute("ALTER TABLE clans ADD COLUMN favorite_keys TEXT DEFAULT '';")
        if "last_daily_xp_ts" not in clan_cols:
            conn.execute("ALTER TABLE clans ADD COLUMN last_daily_xp_ts INTEGER NOT NULL DEFAULT 0;")

        user_cols = [row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()]
        if "id_num" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN id_num INTEGER DEFAULT NULL;")
        if "clan_id" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN clan_id INTEGER DEFAULT NULL;")
        if "bg_image_path" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN bg_image_path TEXT DEFAULT NULL;")
        if "is_banned" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN is_banned INTEGER NOT NULL DEFAULT 0;")
        if "ban_until_ts" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN ban_until_ts INTEGER NOT NULL DEFAULT 0;")
        if "ban_reason" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN ban_reason TEXT NOT NULL DEFAULT '';")
        if "ban_hours" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN ban_hours INTEGER NOT NULL DEFAULT 0;")
        if "privacy_accepted" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN privacy_accepted INTEGER NOT NULL DEFAULT 0;")
        if "privacy_accepted_ts" not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN privacy_accepted_ts INTEGER NOT NULL DEFAULT 0;")

        unlinked_clans = conn.execute("SELECT id FROM clans WHERE id_num IS NULL").fetchall()
        for c in unlinked_clans:
            cur = conn.execute("INSERT INTO global_id_seq (entity_type) VALUES ('clan')")
            conn.execute("UPDATE clans SET id_num=? WHERE id=?", (cur.lastrowid, c["id"]))
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_clans_id_num ON clans(id_num);")

        unlinked_users = conn.execute("SELECT user_id FROM users WHERE id_num IS NULL").fetchall()
        for u in unlinked_users:
            cur = conn.execute("INSERT INTO global_id_seq (entity_type) VALUES ('user')")
            conn.execute("UPDATE users SET id_num=? WHERE user_id=?", (cur.lastrowid, u["user_id"]))
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_id_num ON users(id_num);")

        conn.execute("INSERT OR IGNORE INTO bot_settings (key, value) VALUES ('maintenance_mode', '0')")
        conn.commit()
    finally:
        conn.close()

def get_bot_setting(key: str, default: str = "") -> str:
    conn = db_connect()
    try:
        row = conn.execute("SELECT value FROM bot_settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default
    except Exception:
        return default
    finally:
        conn.close()

def set_bot_setting(key: str, value: str) -> None:
    conn = db_connect()
    try:
        conn.execute(
            "INSERT INTO bot_settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        conn.commit()
    finally:
        conn.close()

def is_maintenance_mode() -> bool:
    return get_bot_setting("maintenance_mode", "0") == "1"

def set_maintenance_mode(enabled: bool) -> None:
    set_bot_setting("maintenance_mode", "1" if enabled else "0")

def create_star_check_draft(creator_id: int, amount_stars: int, target_username: str = "") -> str:
    code = secrets.token_hex(6)
    norm_target = (target_username or "").strip().lstrip("@").lower()
    conn = db_connect()
    try:
        conn.execute(
            "INSERT INTO star_checks (code, creator_id, amount_stars, target_username, status, created_ts) "
            "VALUES (?, ?, ?, ?, 'draft', ?)",
            (code, creator_id, int(amount_stars), norm_target, int(time.time())),
        )
        conn.commit()
        return code
    finally:
        conn.close()

def get_star_check(code: str) -> Optional[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute("SELECT * FROM star_checks WHERE code=?", (code,)).fetchone()
    finally:
        conn.close()

def mark_star_check_rendered(code: str) -> None:
    conn = db_connect()
    try:
        conn.execute("UPDATE star_checks SET rendered=1 WHERE code=?", (code,))
        conn.commit()
    finally:
        conn.close()

def activate_star_check_draft(code: str, creator_id: int) -> Tuple[bool, str, Optional[sqlite3.Row]]:
    """Резервирует (списывает) звёзды создателя в момент отправки инлайн-чека."""
    conn = db_connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        chk = conn.execute("SELECT * FROM star_checks WHERE code=?", (code,)).fetchone()
        if not chk:
            conn.rollback()
            return False, "Чек не найден.", None
        if chk["creator_id"] != creator_id:
            conn.rollback()
            return False, "Нет доступа.", chk
        if chk["status"] == "active":
            conn.commit()
            return True, "OK", chk
        if chk["status"] != "draft":
            conn.commit()
            return False, "Чек уже использован или отменён.", chk

        cur = conn.execute(
            "UPDATE users SET balance_stars=balance_stars-? WHERE user_id=? AND balance_stars>=?",
            (chk["amount_stars"], creator_id, chk["amount_stars"]),
        )
        if cur.rowcount != 1:
            conn.execute("UPDATE star_checks SET status='cancelled' WHERE id=?", (chk["id"],))
            conn.commit()
            return False, "Недостаточно Stars на балансе отправителя.", chk

        conn.execute("UPDATE star_checks SET status='active' WHERE id=?", (chk["id"],))
        updated = conn.execute("SELECT * FROM star_checks WHERE id=?", (chk["id"],)).fetchone()
        conn.commit()
        return True, "OK", updated
    except Exception as e:
        try: conn.rollback()
        except Exception: pass
        return False, f"Ошибка активации: {e}", None
    finally:
        conn.close()

def claim_star_check_db(code: str, claimer_id: int, claimer_username: str) -> Tuple[bool, str, Optional[sqlite3.Row]]:
    """Атомарно активирует чек 1 раз и зачисляет звёзды получателю."""
    conn = db_connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        chk = conn.execute("SELECT * FROM star_checks WHERE code=?", (code,)).fetchone()
        if not chk:
            conn.rollback()
            return False, "Чек не найден.", None

        status = chk["status"]
        if status == "claimed":
            conn.rollback()
            return False, "Этот чек уже был активирован!", chk
        if status == "cancelled":
            conn.rollback()
            return False, "Этот чек отменён или просрочен.", chk

        target_uname = (chk["target_username"] or "").strip().lstrip("@").lower()
        cur_uname = (claimer_username or "").strip().lstrip("@").lower()
        if target_uname:
            is_target = bool(cur_uname and cur_uname == target_uname)
            is_creator = (claimer_id == chk["creator_id"])
            if not is_target and not is_creator:
                conn.rollback()
                return False, f"Этот чек предназначен только для @{target_uname}!", chk

        if status == "draft":
            # Если Inline Feedback отключён — списываем у создателя атомарно в момент получения
            ded = conn.execute(
                "UPDATE users SET balance_stars=balance_stars-? WHERE user_id=? AND balance_stars>=?",
                (chk["amount_stars"], chk["creator_id"], chk["amount_stars"]),
            )
            if ded.rowcount != 1:
                conn.execute("UPDATE star_checks SET status='cancelled' WHERE id=?", (chk["id"],))
                conn.commit()
                return False, "У отправителя недостаточно Stars для оплаты этого чека.", chk
        elif status != "active":
            conn.rollback()
            return False, "Чек недоступен.", chk

        upd = conn.execute(
            "UPDATE star_checks SET status='claimed', claimed_by=?, claimed_ts=? "
            "WHERE id=? AND status IN ('draft', 'active')",
            (claimer_id, int(time.time()), chk["id"]),
        )
        if upd.rowcount != 1:
            conn.rollback()
            return False, "Этот чек уже активирован другим игроком!", chk

        conn.execute(
            "UPDATE users SET balance_stars=balance_stars+? WHERE user_id=?",
            (chk["amount_stars"], claimer_id),
        )
        updated = conn.execute("SELECT * FROM star_checks WHERE id=?", (chk["id"],)).fetchone()
        conn.commit()
        return True, "OK", updated
    except Exception as e:
        try: conn.rollback()
        except Exception: pass
        return False, f"Ошибка активации чека: {e}", None
    finally:
        conn.close()

MAINTENANCE_MESSAGE = (
    "🛠 <b>Бот сейчас на техработах.</b>\n\n"
    "Подождите немного и попробуйте позже."
)

def get_next_global_id(entity_type: str = "entity") -> int:
    conn = db_connect()
    try:
        cur = conn.execute("INSERT INTO global_id_seq (entity_type) VALUES (?)", (entity_type,))
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

def get_or_create_user(user_id: int, username: str, first_name: str) -> sqlite3.Row:
    conn = db_connect()
    try:
        row = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        if row is None:
            sys_id = get_next_global_id("user")
            conn.execute(
                "INSERT INTO users (id_num, user_id, username, first_name, xp, max_inventory) VALUES (?, ?, ?, ?, 0, 25)",
                (sys_id, user_id, username or "", first_name or ""),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        else:
            if username or first_name:
                conn.execute(
                    "UPDATE users SET username=?, first_name=? WHERE user_id=?",
                    (username or row["username"] or "", first_name or row["first_name"] or "", user_id),
                )
                conn.commit()
                row = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        return row
    finally:
        conn.close()

def has_accepted_privacy(user_id: int) -> bool:
    conn = db_connect()
    try:
        row = conn.execute("SELECT privacy_accepted FROM users WHERE user_id=?", (user_id,)).fetchone()
        return bool(row and row["privacy_accepted"])
    except Exception:
        return False
    finally:
        conn.close()

def accept_privacy_policy_db(user_id: int) -> None:
    conn = db_connect()
    try:
        conn.execute(
            "UPDATE users SET privacy_accepted=1, privacy_accepted_ts=? WHERE user_id=?",
            (int(time.time()), user_id),
        )
        conn.commit()
    finally:
        conn.close()

# ---------------------------------------------------------------------------
# СИСТЕМА БАНОВ
# ---------------------------------------------------------------------------

def is_user_banned(user_id: int) -> Tuple[bool, int, str, int]:
    conn = db_connect()
    try:
        row = conn.execute("SELECT is_banned, ban_until_ts, ban_reason, ban_hours FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not row or not row["is_banned"]:
            return False, 0, "", 0

        now = int(time.time())
        until_ts = row["ban_until_ts"]
        if until_ts > 0 and now >= until_ts:
            conn.execute("UPDATE users SET is_banned=0, ban_until_ts=0, ban_reason='', ban_hours=0 WHERE user_id=?", (user_id,))
            conn.commit()
            return False, 0, "", 0

        return True, row["ban_until_ts"], row["ban_reason"], row["ban_hours"]
    finally:
        conn.close()

def ban_user(user_id: int, hours: int, reason: str) -> bool:
    now = int(time.time())
    until_ts = now + (hours * 3600) if hours > 0 else 0
    conn = db_connect()
    try:
        conn.execute(
            "UPDATE users SET is_banned=1, ban_until_ts=?, ban_reason=?, ban_hours=? WHERE user_id=?",
            (until_ts, reason, hours, user_id)
        )
        conn.commit()
        return True
    except Exception as e:
        log.error("Ошибка при бане пользователя: %s", e)
        return False
    finally:
        conn.close()

def unban_user(user_id: int) -> bool:
    conn = db_connect()
    try:
        conn.execute("UPDATE users SET is_banned=0, ban_until_ts=0, ban_reason='', ban_hours=0 WHERE user_id=?", (user_id,))
        conn.commit()
        return True
    except Exception as e:
        log.error("Ошибка при разбане пользователя: %s", e)
        return False
    finally:
        conn.close()

def format_ban_message(ban_until_ts: int, ban_reason: str, ban_hours: int) -> Tuple[str, InlineKeyboardMarkup]:
    if ban_until_ts > 0:
        dt_str = datetime.datetime.fromtimestamp(ban_until_ts, tz=datetime.timezone.utc).strftime("%d.%m.%Y %H:%M UTC")
        time_text = f"• Время блокировки: <b>{ban_hours} ч.</b>\n• Заблокирован до: <b>{dt_str}</b>"
    else:
        time_text = "• Время блокировки: <b>Навсегда</b>"

    text = (
        "⛔️ <b>Доступ заблокирован!</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Вы получили бан в системе бота и не можете использовать команды.\n\n"
        f"{time_text}\n"
        f"• Причина: <b>{clean_html(ban_reason or 'Нарушение правил')}</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"Если вы считаете блокировку ошибочной, обратитесь в поддержку: {SUPPORT_HANDLE}"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("💬 Поддержка", url=SUPPORT_URL)]
    ])
    return text, kb

# ---------------------------------------------------------------------------
# ОПЕРАЦИИ С БАЗОЙ ДАННЫХ ПОЛЬЗОВАТЕЛЕЙ
# ---------------------------------------------------------------------------

def set_last_drop(user_id: int, ts: int) -> None:
    conn = db_connect()
    try:
        conn.execute(
            "UPDATE users SET last_drop_ts=?, total_drops=total_drops+1 WHERE user_id=?",
            (ts, user_id),
        )
        conn.commit()
    finally:
        conn.close()

def set_user_background(user_id: int, bg_path: Optional[str]) -> None:
    conn = db_connect()
    try:
        conn.execute("UPDATE users SET bg_image_path=? WHERE user_id=?", (bg_path, user_id))
        conn.commit()
    finally:
        conn.close()

def add_to_collection(user_id: int, gift_key: str) -> bool:
    g = GIFTS_BY_KEY.get(gift_key)
    add_xp = g.xp if g else 100
    conn = db_connect()
    try:
        user = conn.execute("SELECT max_inventory FROM users WHERE user_id=?", (user_id,)).fetchone()
        count = conn.execute("SELECT COUNT(*) as cnt FROM collection WHERE user_id=?", (user_id,)).fetchone()["cnt"]

        max_inv = user["max_inventory"] if user else 25
        if count >= max_inv:
            return False

        conn.execute(
            "INSERT INTO collection (user_id, gift_key, obtained_ts, is_favorite) VALUES (?, ?, ?, 0)",
            (user_id, gift_key, int(time.time())),
        )
        conn.execute("UPDATE users SET xp = xp + ? WHERE user_id = ?", (add_xp, user_id))
        conn.commit()
        return True
    finally:
        conn.close()

def get_item_display_value(item: sqlite3.Row) -> int:
    if item["is_upgraded"] and item["upgraded_stars"] > 0:
        return int(item["upgraded_stars"])
    g = GIFTS_BY_KEY.get(item["gift_key"])
    return g.stars if g else 0

def upgrade_collection_item(
    user_id: int,
    item_id: int,
    model_name: str,
    backdrop_key: str,
    upgraded_stars: int,
    cost: int = UPGRADE_COST_STARS,
) -> Tuple[bool, str, int]:
    """Списывает 150,000 ⭐ и улучшает Plush Pepe, присваивая модель, фон и номер."""
    conn = db_connect()
    try:
        user = conn.execute("SELECT balance_stars FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not user or user["balance_stars"] < cost:
            return False, f"Недостаточно Stars! Требуется {cost:,} ⭐.", 0

        item = conn.execute("SELECT * FROM collection WHERE id=? AND user_id=?", (item_id, user_id)).fetchone()
        if not item:
            return False, "Подарок не найден в вашей коллекции.", 0
        if item["gift_key"] != "pepe_heart":
            return False, "Улучшение сейчас доступно только для Plush Pepe!", 0
        if item["is_upgraded"]:
            return False, "Этот подарок уже улучшен!", 0
        if item["is_listed"]:
            return False, "Сначала снимите подарок с маркета.", 0

        max_num_row = conn.execute("SELECT COALESCE(MAX(upgrade_num), 0) AS mx FROM collection").fetchone()
        next_num = int(max_num_row["mx"] or 0) + 1

        conn.execute("UPDATE users SET balance_stars=balance_stars-?, xp=xp+5000 WHERE user_id=?", (cost, user_id))
        conn.execute(
            "UPDATE collection SET is_upgraded=1, model_name=?, backdrop_key=?, upgraded_stars=?, upgrade_num=? WHERE id=?",
            (model_name, backdrop_key, upgraded_stars, next_num, item_id),
        )
        conn.commit()
        return True, "OK", next_num
    finally:
        conn.close()

def transfer_gift_between_users(sender_id: int, receiver_id: int, item_id: int) -> Tuple[bool, str]:
    """Безопасная передача подарка (обычного или улучшенного) от одного игрока другому."""
    conn = db_connect()
    try:
        item = conn.execute("SELECT * FROM collection WHERE id=? AND user_id=?", (item_id, sender_id)).fetchone()
        if not item:
            return False, "Предмет не найден в вашей коллекции."
        if item["is_listed"]:
            return False, "Подарок выставлен на маркете! Сначала снимите лот с продажи."

        recv = conn.execute("SELECT max_inventory FROM users WHERE user_id=?", (receiver_id,)).fetchone()
        if not recv:
            return False, "Получатель не найден."

        recv_count = conn.execute("SELECT COUNT(*) as cnt FROM collection WHERE user_id=?", (receiver_id,)).fetchone()["cnt"]
        if recv_count >= recv["max_inventory"]:
            return False, "У получателя переполнен инвентарь."

        conn.execute(
            "UPDATE collection SET user_id=?, is_favorite=0, obtained_ts=? WHERE id=?",
            (receiver_id, int(time.time()), item_id),
        )
        conn.commit()
        return True, item["gift_key"]
    finally:
        conn.close()

def sell_from_pending(user_id: int, gift_key: str, stars: int) -> None:
    g = GIFTS_BY_KEY.get(gift_key)
    add_xp = (g.xp // 2) if g else 50
    conn = db_connect()
    try:
        conn.execute(
            "UPDATE users SET balance_stars=balance_stars+?, total_sold=total_sold+1, xp=xp+? WHERE user_id=?",
            (stars, add_xp, user_id),
        )
        conn.commit()
    finally:
        conn.close()

def get_user_collection(user_id: int) -> list[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute(
            "SELECT * FROM collection WHERE user_id=? ORDER BY is_upgraded DESC, is_favorite DESC, id DESC",
            (user_id,),
        ).fetchall()
    finally:
        conn.close()

def sell_all_non_favorites(user_id: int) -> Tuple[int, int]:
    conn = db_connect()
    try:
        items = conn.execute(
            "SELECT id, gift_key FROM collection WHERE user_id=? AND is_favorite=0 AND is_upgraded=0 AND is_listed=0",
            (user_id,),
        ).fetchall()
        if not items:
            return 0, 0

        total_stars = 0
        ids_to_del = []
        for item in items:
            g = GIFTS_BY_KEY.get(item["gift_key"])
            if g:
                total_stars += g.stars
            ids_to_del.append(item["id"])

        conn.executemany("DELETE FROM collection WHERE id=?", [(i,) for i in ids_to_del])
        conn.execute("UPDATE users SET balance_stars=balance_stars+?, total_sold=total_sold+? WHERE user_id=?",
                     (total_stars, len(ids_to_del), user_id))
        conn.commit()
        return len(ids_to_del), total_stars
    finally:
        conn.close()

def toggle_user_setting(user_id: int, field: str) -> bool:
    if field not in ("hide_top", "hide_collection", "auto_sell"):
        return False
    conn = db_connect()
    try:
        row = conn.execute(f"SELECT {field} FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not row:
            return False
        new_val = 1 if row[field] == 0 else 0
        conn.execute(f"UPDATE users SET {field}=? WHERE user_id=?", (new_val, user_id))
        conn.commit()
        return True
    finally:
        conn.close()

def upgrade_inventory_capacity(user_id: int, cost: int, add_slots: int) -> bool:
    conn = db_connect()
    try:
        row = conn.execute("SELECT balance_stars, max_inventory FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not row or row["balance_stars"] < cost:
            return False
        conn.execute("UPDATE users SET balance_stars=balance_stars-?, max_inventory=max_inventory+? WHERE user_id=?",
                     (cost, add_slots, user_id))
        conn.commit()
        return True
    finally:
        conn.close()

def get_collection_item(item_id: int) -> Optional[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute("SELECT * FROM collection WHERE id=?", (item_id,)).fetchone()
    finally:
        conn.close()

def toggle_favorite(item_id: int, user_id: int) -> bool:
    conn = db_connect()
    try:
        item = conn.execute("SELECT * FROM collection WHERE id=? AND user_id=?", (item_id, user_id)).fetchone()
        if not item:
            return False

        if not item["is_favorite"]:
            fav_count = conn.execute(
                "SELECT COUNT(*) as cnt FROM collection WHERE user_id=? AND is_favorite=1",
                (user_id,)
            ).fetchone()["cnt"]
            if fav_count >= 7:
                return False
            conn.execute("UPDATE collection SET is_favorite=1 WHERE id=?", (item_id,))
        else:
            conn.execute("UPDATE collection SET is_favorite=0 WHERE id=?", (item_id,))

        conn.commit()
        return True
    finally:
        conn.close()

def remove_from_collection(item_id: int, user_id: int) -> None:
    conn = db_connect()
    try:
        conn.execute("DELETE FROM collection WHERE id=? AND user_id=? AND is_listed=0", (item_id, user_id))
        conn.commit()
    finally:
        conn.close()

def add_user_stars(user_id: int, stars: int) -> None:
    conn = db_connect()
    try:
        conn.execute("UPDATE users SET balance_stars=balance_stars+? WHERE user_id=?", (stars, user_id))
        conn.commit()
    finally:
        conn.close()

def deduct_user_stars(user_id: int, stars: int) -> bool:
    conn = db_connect()
    try:
        row = conn.execute("SELECT balance_stars FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not row or row["balance_stars"] < stars:
            return False
        conn.execute("UPDATE users SET balance_stars=balance_stars-? WHERE user_id=?", (stars, user_id))
        conn.commit()
        return True
    finally:
        conn.close()

def claim_daily_bonus(user_id: int) -> Optional[int]:
    conn = db_connect()
    try:
        row = conn.execute("SELECT last_daily_bonus_ts FROM users WHERE user_id=?", (user_id,)).fetchone()
        now = int(time.time())
        day_sec = 24 * 3600
        if row and (now - row["last_daily_bonus_ts"] < day_sec):
            return day_sec - (now - row["last_daily_bonus_ts"])

        conn.execute(
            "UPDATE users SET balance_stars=balance_stars+50, xp=xp+250, last_daily_bonus_ts=? WHERE user_id=?",
            (now, user_id),
        )
        conn.commit()
        return None
    finally:
        conn.close()

def get_favorites(user_id: int) -> list[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute(
            "SELECT * FROM collection WHERE user_id=? AND is_favorite=1 LIMIT 7",
            (user_id,),
        ).fetchall()
    finally:
        conn.close()

# ---------------------------------------------------------------------------
# P2P NFT МАРКЕТ — БАЗА ДАННЫХ (ТОЛЬКО УЛУЧШЕННЫЕ ПОДАРКИ, КОМИССИЯ 15%)
# ---------------------------------------------------------------------------

def create_market_listing(seller_id: int, item_id: int, price_stars: int) -> Tuple[bool, str, Optional[int]]:
    if price_stars < MARKET_MIN_PRICE or price_stars > MARKET_MAX_PRICE:
        return False, f"Цена должна быть от {MARKET_MIN_PRICE:,} ⭐ до {MARKET_MAX_PRICE:,} ⭐.", None

    conn = db_connect()
    try:
        item = conn.execute("SELECT * FROM collection WHERE id=? AND user_id=?", (item_id, seller_id)).fetchone()
        if not item:
            return False, "Подарок не найден в вашей коллекции.", None
        if not item["is_upgraded"]:
            return False, "На маркет можно выставлять только улучшенные подарки!", None
        if item["is_listed"]:
            return False, "Этот подарок уже выставлен на маркете.", None

        now = int(time.time())
        conn.execute("UPDATE collection SET is_listed=1, is_favorite=0 WHERE id=?", (item_id,))
        cur = conn.execute(
            "INSERT INTO market_listings "
            "(collection_id, seller_id, gift_key, model_name, backdrop_key, upgraded_stars, upgrade_num, price_stars, status, created_ts) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)",
            (
                item_id,
                seller_id,
                item["gift_key"],
                item["model_name"] or "Plush Pepe",
                item["backdrop_key"] or "black",
                item["upgraded_stars"] or 0,
                item["upgrade_num"] or 0,
                price_stars,
                now,
            ),
        )
        conn.commit()
        return True, "OK", cur.lastrowid
    finally:
        conn.close()

def cancel_market_listing(seller_id: int, listing_id: int) -> Tuple[bool, str]:
    conn = db_connect()
    try:
        lot = conn.execute(
            "SELECT * FROM market_listings WHERE id=? AND seller_id=? AND status='active'",
            (listing_id, seller_id),
        ).fetchone()
        if not lot:
            return False, "Активный лот не найден."

        conn.execute("UPDATE market_listings SET status='cancelled' WHERE id=?", (listing_id,))
        conn.execute("UPDATE collection SET is_listed=0 WHERE id=?", (lot["collection_id"],))
        conn.commit()
        return True, "Лот снят с продажи и возвращён в вашу коллекцию."
    finally:
        conn.close()

def get_market_listings(
    filter_type: str = "all",
    filter_key: str = "all",
    page: int = 1,
    page_size: int = 8,
) -> Tuple[list[sqlite3.Row], int, int]:
    conn = db_connect()
    try:
        where_clauses = ["ml.status='active'"]
        params: list = []

        if filter_type == "price" and filter_key in MARKET_PRICE_TIERS:
            _, min_p, max_p = MARKET_PRICE_TIERS[filter_key]
            where_clauses.append("ml.price_stars BETWEEN ? AND ?")
            params.extend([min_p, max_p])
        elif filter_type == "model" and filter_key != "all":
            where_clauses.append("ml.model_name=?")
            params.append(filter_key)
        elif filter_type == "rarity" and filter_key != "all":
            matching_bgs = [b.key for b in PLUSHPEPE_BACKDROPS if b.rarity_label == filter_key]
            if matching_bgs:
                placeholders = ",".join("?" for _ in matching_bgs)
                where_clauses.append(f"ml.backdrop_key IN ({placeholders})")
                params.extend(matching_bgs)
            else:
                where_clauses.append("1=0")

        where_sql = " AND ".join(where_clauses)
        total = conn.execute(
            f"SELECT COUNT(*) as cnt FROM market_listings ml WHERE {where_sql}",
            tuple(params),
        ).fetchone()["cnt"]
        total_pages = max(1, math.ceil(total / page_size))
        page = max(1, min(page, total_pages))
        offset = (page - 1) * page_size

        rows = conn.execute(
            f"SELECT ml.*, u.first_name as seller_name, u.username as seller_username "
            f"FROM market_listings ml LEFT JOIN users u ON ml.seller_id = u.user_id "
            f"WHERE {where_sql} ORDER BY ml.id DESC LIMIT ? OFFSET ?",
            tuple(params) + (page_size, offset),
        ).fetchall()
        return rows, total_pages, total
    finally:
        conn.close()

def get_market_listing_by_id(listing_id: int) -> Optional[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute(
            "SELECT ml.*, u.first_name as seller_name, u.username as seller_username "
            "FROM market_listings ml LEFT JOIN users u ON ml.seller_id = u.user_id "
            "WHERE ml.id=?",
            (listing_id,),
        ).fetchone()
    finally:
        conn.close()

def get_active_listing_by_collection_id(collection_id: int) -> Optional[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute(
            "SELECT * FROM market_listings WHERE collection_id=? AND status='active' ORDER BY id DESC LIMIT 1",
            (collection_id,),
        ).fetchone()
    finally:
        conn.close()

def get_user_market_listings(user_id: int) -> list[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute(
            "SELECT * FROM market_listings WHERE seller_id=? AND status='active' ORDER BY id DESC",
            (user_id,),
        ).fetchall()
    finally:
        conn.close()

def buy_market_listing(buyer_id: int, listing_id: int) -> Tuple[bool, str, Optional[dict]]:
    conn = db_connect()
    try:
        lot = conn.execute("SELECT * FROM market_listings WHERE id=?", (listing_id,)).fetchone()
        if not lot or lot["status"] != "active":
            return False, "Лот уже продан или снят с продажи.", None
        if lot["seller_id"] == buyer_id:
            return False, "Нельзя купить собственный лот!", None

        buyer = conn.execute("SELECT balance_stars, max_inventory FROM users WHERE user_id=?", (buyer_id,)).fetchone()
        if not buyer:
            return False, "Профиль покупателя не найден.", None

        price = int(lot["price_stars"])
        if buyer["balance_stars"] < price:
            return False, f"Недостаточно Stars! Нужно {price:,} ⭐.", None

        buyer_cnt = conn.execute("SELECT COUNT(*) as cnt FROM collection WHERE user_id=?", (buyer_id,)).fetchone()["cnt"]
        if buyer_cnt >= buyer["max_inventory"]:
            return False, "Ваш инвентарь переполнен! Освободите место или расширьте слоты.", None

        fee_stars = int(price * MARKET_FEE_RATE)
        seller_gets = price - fee_stars
        now = int(time.time())

        conn.execute("UPDATE users SET balance_stars=balance_stars-? WHERE user_id=?", (price, buyer_id))
        conn.execute(
            "UPDATE users SET balance_stars=balance_stars+?, total_sold=total_sold+1 WHERE user_id=?",
            (seller_gets, lot["seller_id"]),
        )
        conn.execute(
            "UPDATE collection SET user_id=?, is_listed=0, is_favorite=0, obtained_ts=? WHERE id=?",
            (buyer_id, now, lot["collection_id"]),
        )
        conn.execute(
            "UPDATE market_listings SET status='sold', buyer_id=?, sold_ts=? WHERE id=?",
            (buyer_id, now, listing_id),
        )
        conn.execute(
            "INSERT INTO market_history "
            "(listing_id, seller_id, buyer_id, gift_key, model_name, backdrop_key, price_stars, fee_stars, seller_received_stars, sold_ts) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                listing_id,
                lot["seller_id"],
                buyer_id,
                lot["gift_key"],
                lot["model_name"],
                lot["backdrop_key"],
                price,
                fee_stars,
                seller_gets,
                now,
            ),
        )
        conn.commit()
        return True, "OK", {
            "listing_id": listing_id,
            "collection_id": lot["collection_id"],
            "seller_id": lot["seller_id"],
            "price_stars": price,
            "fee_stars": fee_stars,
            "seller_gets": seller_gets,
            "model_name": lot["model_name"],
            "backdrop_key": lot["backdrop_key"],
            "upgrade_num": lot["upgrade_num"],
            "upgraded_stars": lot["upgraded_stars"],
        }
    finally:
        conn.close()

def get_market_history(user_id: Optional[int] = None, limit: int = 12) -> list[sqlite3.Row]:
    conn = db_connect()
    try:
        if user_id is not None:
            return conn.execute(
                "SELECT * FROM market_history WHERE seller_id=? OR buyer_id=? ORDER BY id DESC LIMIT ?",
                (user_id, user_id, limit),
            ).fetchall()
        return conn.execute("SELECT * FROM market_history ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    finally:
        conn.close()

def get_user_rank(user_id: int) -> int:
    conn = db_connect()
    try:
        rows = conn.execute("SELECT user_id FROM users ORDER BY balance_stars DESC, xp DESC").fetchall()
        for idx, r in enumerate(rows, start=1):
            if r["user_id"] == user_id:
                return idx
        return 1
    finally:
        conn.close()

def get_user_by_target(target: str) -> Optional[sqlite3.Row]:
    conn = db_connect()
    try:
        target = target.strip()
        if target.startswith("@"):
            uname = target.lstrip("@").lower()
            return conn.execute("SELECT * FROM users WHERE LOWER(username)=?", (uname,)).fetchone()
        elif target.isdigit():
            val = int(target)
            row = conn.execute("SELECT * FROM users WHERE user_id=?", (val,)).fetchone()
            if not row:
                row = conn.execute("SELECT * FROM users WHERE id_num=?", (val,)).fetchone()
            return row
        else:
            # Также поддерживаем поиск по username без @
            uname = target.lower()
            return conn.execute("SELECT * FROM users WHERE LOWER(username)=?", (uname,)).fetchone()
    finally:
        conn.close()

def get_top_users_page(page: int = 1, page_size: int = 10) -> Tuple[list[sqlite3.Row], int]:
    conn = db_connect()
    try:
        total = conn.execute("SELECT COUNT(*) as cnt FROM users WHERE hide_top=0").fetchone()["cnt"]
        total_pages = max(1, math.ceil(total / page_size))
        page = max(1, min(page, total_pages))
        offset = (page - 1) * page_size
        rows = conn.execute(
            "SELECT * FROM users WHERE hide_top=0 ORDER BY balance_stars DESC, xp DESC LIMIT ? OFFSET ?",
            (page_size, offset)
        ).fetchall()
        return rows, total_pages
    finally:
        conn.close()

def create_pending_drop(user_id: int, chat_id: int, gift_key: str) -> int:
    conn = db_connect()
    try:
        cur = conn.execute(
            "INSERT INTO pending_drops (user_id, chat_id, gift_key, created_ts) VALUES (?, ?, ?, ?)",
            (user_id, chat_id, gift_key, int(time.time())),
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

def get_pending_drop(drop_id: int) -> Optional[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute("SELECT * FROM pending_drops WHERE id=?", (drop_id,)).fetchone()
    finally:
        conn.close()

def resolve_pending_drop(drop_id: int) -> None:
    conn = db_connect()
    try:
        conn.execute("UPDATE pending_drops SET resolved=1 WHERE id=?", (drop_id,))
        conn.commit()
    finally:
        conn.close()

# ---------------------------------------------------------------------------
# КЛАНЫ — БАЗА ДАННЫХ, КАЗНА И ПОДАРКИ КЛАНА
# ---------------------------------------------------------------------------

def get_user_clan(user_id: int) -> Optional[sqlite3.Row]:
    conn = db_connect()
    try:
        user = conn.execute("SELECT clan_id FROM users WHERE user_id=?", (user_id,)).fetchone()
        if user and user["clan_id"]:
            return conn.execute("SELECT * FROM clans WHERE id=?", (user["clan_id"],)).fetchone()
        return None
    finally:
        conn.close()

def get_clan_by_id(clan_id: int) -> Optional[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute("SELECT * FROM clans WHERE id=?", (clan_id,)).fetchone()
    finally:
        conn.close()

def get_clan_treasury_and_members(clan_id: int) -> Tuple[int, int, list[sqlite3.Row]]:
    """
    Возвращает:
    - total_treasury: Общая казна (сумма балансов участников + баланс казны + потраченное из казны).
      При депозите участником в баланс казны общая казна НЕ уменьшается!
      При входе нового участника общая казна пополняется на его баланс!
    - donated_bank: Баланс казны (звёзды, доступные для клановых покупок).
    - members: отсортированный список участников с балансами.
    """
    conn = db_connect()
    try:
        members = conn.execute(
            "SELECT user_id, first_name, username, balance_stars FROM users WHERE clan_id=? ORDER BY balance_stars DESC",
            (clan_id,)
        ).fetchall()
        members_sum = sum(m["balance_stars"] for m in members)
        clan = conn.execute("SELECT donated_stars, spent_stars FROM clans WHERE id=?", (clan_id,)).fetchone()
        donated_bank = clan["donated_stars"] if clan else 0
        spent_bank = clan["spent_stars"] if (clan and "spent_stars" in clan.keys()) else 0
        total_treasury = members_sum + donated_bank + spent_bank
        return total_treasury, donated_bank, members
    finally:
        conn.close()

def check_and_award_clan_daily_xp(clan_id: int) -> Optional[int]:
    conn = db_connect()
    try:
        clan = conn.execute("SELECT last_daily_xp_ts, xp, donated_stars, spent_stars FROM clans WHERE id=?", (clan_id,)).fetchone()
        if not clan:
            return None
        now = int(time.time())
        last_ts = clan["last_daily_xp_ts"] or 0
        if now - last_ts < 24 * 3600:
            return None

        members = conn.execute("SELECT balance_stars FROM users WHERE clan_id=?", (clan_id,)).fetchall()
        spent_bank = clan["spent_stars"] if "spent_stars" in clan.keys() else 0
        treasury = sum(m["balance_stars"] for m in members) + (clan["donated_stars"] or 0) + (spent_bank or 0)

        if treasury < 5_000_000:
            conn.execute("UPDATE clans SET last_daily_xp_ts=? WHERE id=?", (now, clan_id))
            conn.commit()
            return None

        millions = treasury / 1_000_000
        awarded_xp = int(500 + 450 * math.log2(millions / 5 + 1))
        conn.execute("UPDATE clans SET xp=xp+?, last_daily_xp_ts=? WHERE id=?", (awarded_xp, now, clan_id))
        conn.commit()
        return awarded_xp
    finally:
        conn.close()

def donate_stars_to_clan(user_id: int, clan_id: int, stars: int) -> Tuple[bool, int]:
    """
    Пополнение баланса казны звездами:
    - Списывает звёзды с баланса игрока и переводит в Баланс казны (donated_stars)
    - Общая казна клана остаётся неизменной (баланс игрока перешёл в баланс казны)
    - Начисляет клану XP (800 XP за 1,000,000 ⭐)
    """
    if not deduct_user_stars(user_id, stars):
        return False, 0
    xp_earned = max(1, int(stars * 0.0008))
    conn = db_connect()
    try:
        conn.execute("UPDATE clans SET donated_stars=donated_stars+?, xp=xp+? WHERE id=?", (stars, xp_earned, clan_id))
        conn.commit()
        return True, xp_earned
    finally:
        conn.close()

def set_clan_avatar(clan_id: int, avatar_path: Optional[str]) -> None:
    conn = db_connect()
    try:
        conn.execute("UPDATE clans SET avatar_path=? WHERE id=?", (avatar_path, clan_id))
        conn.commit()
    finally:
        conn.close()

def get_clan_gifts(clan_id: int) -> list[sqlite3.Row]:
    """Возвращает реальные подарки, подаренные игроками в клан."""
    conn = db_connect()
    try:
        return conn.execute(
            "SELECT cg.*, u.first_name, u.username FROM clan_gifts cg "
            "LEFT JOIN users u ON cg.donor_user_id = u.user_id "
            "WHERE cg.clan_id=? ORDER BY cg.is_favorite DESC, cg.id DESC",
            (clan_id,),
        ).fetchall()
    finally:
        conn.close()

def get_clan_gift_by_id(clan_gift_id: int) -> Optional[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute("SELECT * FROM clan_gifts WHERE id=?", (clan_gift_id,)).fetchone()
    finally:
        conn.close()

def get_clan_favorites(clan: sqlite3.Row) -> List[GiftDef]:
    """Избранные подарки клана берутся ТОЛЬКО из реально подаренных игроками подарков в clan_gifts."""
    conn = db_connect()
    try:
        rows = conn.execute(
            "SELECT gift_key FROM clan_gifts WHERE clan_id=? AND is_favorite=1 ORDER BY id DESC LIMIT 7",
            (clan["id"],),
        ).fetchall()
        return [GIFTS_BY_KEY[r["gift_key"]] for r in rows if r["gift_key"] in GIFTS_BY_KEY]
    finally:
        conn.close()

def toggle_clan_gift_favorite(clan_id: int, clan_gift_id: int) -> Tuple[bool, str]:
    conn = db_connect()
    try:
        row = conn.execute("SELECT * FROM clan_gifts WHERE id=? AND clan_id=?", (clan_gift_id, clan_id)).fetchone()
        if not row:
            return False, "Подарок не найден в клане."

        if not row["is_favorite"]:
            fav_cnt = conn.execute(
                "SELECT COUNT(*) as cnt FROM clan_gifts WHERE clan_id=? AND is_favorite=1",
                (clan_id,),
            ).fetchone()["cnt"]
            if fav_cnt >= 7:
                return False, "Максимум 7 избранных подарков у клана!"
            conn.execute("UPDATE clan_gifts SET is_favorite=1 WHERE id=?", (clan_gift_id,))
            msg = "⭐ Подарок добавлен в избранное клана!"
        else:
            conn.execute("UPDATE clan_gifts SET is_favorite=0 WHERE id=?", (clan_gift_id,))
            msg = "Подарок убран из избранного клана."

        conn.commit()
        return True, msg
    finally:
        conn.close()

def donate_gift_to_clan_db(user_id: int, clan_id: int, item_id: int) -> Tuple[bool, str, int]:
    """Переносит подарок из коллекции игрока в clan_gifts и начисляет клану XP."""
    conn = db_connect()
    try:
        item = conn.execute("SELECT * FROM collection WHERE id=? AND user_id=?", (item_id, user_id)).fetchone()
        if not item:
            return False, "Предмет не найден в вашей коллекции.", 0
        if item["is_listed"]:
            return False, "Подарок выставлен на маркете! Сначала снимите лот.", 0
        g = GIFTS_BY_KEY.get(item["gift_key"])
        if not g:
            return False, "Неизвестный подарок.", 0

        val_stars = get_item_display_value(item)
        xp_earned = max(1, int(val_stars * 0.0008))
        disp_name = f"Plush Pepe ({item['model_name']})" if item["is_upgraded"] and item["model_name"] else g.name
        conn.execute("DELETE FROM collection WHERE id=? AND user_id=?", (item_id, user_id))
        conn.execute(
            "INSERT INTO clan_gifts (clan_id, donor_user_id, gift_key, donated_ts, is_favorite) VALUES (?, ?, ?, ?, 0)",
            (clan_id, user_id, item["gift_key"], int(time.time())),
        )
        conn.execute("UPDATE clans SET xp=xp+? WHERE id=?", (xp_earned, clan_id))
        conn.commit()
        return True, disp_name, xp_earned
    finally:
        conn.close()

def get_all_clans(page: int = 1, page_size: int = 5) -> Tuple[list[sqlite3.Row], int]:
    conn = db_connect()
    try:
        total = conn.execute("SELECT COUNT(*) as cnt FROM clans").fetchone()["cnt"]
        total_pages = max(1, math.ceil(total / page_size))
        page = max(1, min(page, total_pages))
        offset = (page - 1) * page_size
        rows = conn.execute("SELECT * FROM clans ORDER BY xp DESC, id DESC LIMIT ? OFFSET ?", (page_size, offset)).fetchall()
        return rows, total_pages
    finally:
        conn.close()

def create_clan(owner_id: int, tag: str, name: str, desc: str, ctype: str, fee: int) -> Optional[int]:
    clan_sys_id = get_next_global_id("clan")
    conn = db_connect()
    try:
        cur = conn.execute(
            "INSERT INTO clans (id_num, owner_id, tag, name, description, type, entry_fee, max_members, xp, donated_stars, spent_stars, last_daily_xp_ts, created_ts) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, 15, 0, 0, 0, ?, ?)",
            (clan_sys_id, owner_id, tag, name, desc, ctype, fee, int(time.time()), int(time.time()))
        )
        clan_id = cur.lastrowid
        conn.execute("UPDATE users SET clan_id=? WHERE user_id=?", (clan_id, owner_id))
        conn.commit()
        return clan_id
    except Exception as e:
        log.error("Ошибка создания клана: %s", e)
        return None
    finally:
        conn.close()

def add_user_to_clan(user_id: int, clan_id: int) -> bool:
    conn = db_connect()
    try:
        clan = conn.execute("SELECT max_members FROM clans WHERE id=?", (clan_id,)).fetchone()
        cnt = conn.execute("SELECT COUNT(*) as cnt FROM users WHERE clan_id=?", (clan_id,)).fetchone()["cnt"]
        if not clan or cnt >= clan["max_members"]:
            return False
        conn.execute("UPDATE users SET clan_id=? WHERE user_id=?", (clan_id, user_id))
        conn.execute("DELETE FROM clan_requests WHERE user_id=?", (user_id,))
        conn.commit()
        return True
    finally:
        conn.close()

def remove_user_from_clan(user_id: int) -> None:
    conn = db_connect()
    try:
        conn.execute("UPDATE users SET clan_id=NULL WHERE user_id=?", (user_id,))
        conn.commit()
    finally:
        conn.close()

def delete_clan(clan_id: int) -> None:
    conn = db_connect()
    try:
        conn.execute("UPDATE users SET clan_id=NULL WHERE clan_id=?", (clan_id,))
        conn.execute("DELETE FROM clan_requests WHERE clan_id=?", (clan_id,))
        conn.execute("DELETE FROM clan_gifts WHERE clan_id=?", (clan_id,))
        conn.execute("DELETE FROM clans WHERE id=?", (clan_id,))
        conn.commit()
    finally:
        conn.close()

def get_clan_upgrade_cost(current_max: int) -> int:
    if current_max < 30: return 100_000
    if current_max < 45: return 500_000
    if current_max < 60: return 2_000_000
    return 5_000_000

def upgrade_clan_slots(clan_id: int, cost: int) -> Tuple[bool, str]:
    """Списывает стоимость улучшения мест сначала из Баланса казны (donated_stars), либо с баланса владельца."""
    conn = db_connect()
    try:
        clan = conn.execute("SELECT owner_id, max_members, donated_stars FROM clans WHERE id=?", (clan_id,)).fetchone()
        if not clan:
            return False, "Клан не найден."
        if (clan["donated_stars"] or 0) >= cost:
            conn.execute(
                "UPDATE clans SET donated_stars=donated_stars-?, spent_stars=spent_stars+?, max_members=max_members+15 WHERE id=?",
                (cost, cost, clan_id),
            )
            conn.commit()
            return True, "из баланса казны"

        owner = conn.execute("SELECT balance_stars FROM users WHERE user_id=?", (clan["owner_id"],)).fetchone()
        if not owner or owner["balance_stars"] < cost:
            return False, f"Недостаточно Stars! В балансе казны ({clan['donated_stars']:,} ⭐) и у владельца меньше {cost:,} ⭐."

        conn.execute("UPDATE users SET balance_stars=balance_stars-? WHERE user_id=?", (cost, clan["owner_id"]))
        conn.execute("UPDATE clans SET spent_stars=spent_stars+?, max_members=max_members+15 WHERE id=?", (cost, clan_id))
        conn.commit()
        return True, "с баланса владельца"
    finally:
        conn.close()

def add_clan_request(clan_id: int, user_id: int) -> bool:
    conn = db_connect()
    try:
        conn.execute("INSERT OR IGNORE INTO clan_requests (clan_id, user_id, created_ts) VALUES (?, ?, ?)",
                     (clan_id, user_id, int(time.time())))
        conn.commit()
        return True
    except Exception:
        return False
    finally:
        conn.close()

def get_clan_requests(clan_id: int) -> list[sqlite3.Row]:
    conn = db_connect()
    try:
        return conn.execute(
            "SELECT r.*, u.first_name, u.username FROM clan_requests r JOIN users u ON r.user_id = u.user_id WHERE r.clan_id=?",
            (clan_id,)
        ).fetchall()
    finally:
        conn.close()

def remove_clan_request(clan_id: int, user_id: int) -> None:
    conn = db_connect()
    try:
        conn.execute("DELETE FROM clan_requests WHERE clan_id=? AND user_id=?", (clan_id, user_id))
        conn.commit()
    finally:
        conn.close()

# ---------------------------------------------------------------------------
# РЕНДЕР КАРТОЧЕК И БАННЕРОВ (БЕЗ СМАЙЛИКОВ И КВАДРАТОВ)
# ---------------------------------------------------------------------------

def draw_rounded_rect(draw, coords, radius, fill=None, outline=None, width=1):
    draw.rounded_rectangle(coords, radius=radius, fill=fill, outline=outline, width=width)

def make_smooth_rounded_mask(width: int, height: int, radius: int) -> Image.Image:
    """Создаёт сглаженную маску скруглённого прямоугольника без пиксельных лесенок (2x SSAA)."""
    scale = 2
    big = Image.new("L", (width * scale, height * scale), 0)
    bdraw = ImageDraw.Draw(big)
    bdraw.rounded_rectangle(
        [0, 0, width * scale - 1, height * scale - 1],
        radius=radius * scale,
        fill=255,
    )
    return big.resize((width, height), Image.Resampling.LANCZOS)

def apply_liquid_glass_panel(
    base_img: Image.Image,
    box: Tuple[int, int, int, int],
    radius: int = 24,
    blur_radius: int = 18,
    dark_tint: int = 62,
    top_light: int = 38,
    bottom_light: int = 10,
) -> Image.Image:
    """Накладывает эффект жидкого стекла (frosted liquid glass) строго БЕЗ обводки."""
    x1, y1, x2, y2 = box
    w, h = x2 - x1, y2 - y1
    if w <= 2 or h <= 2:
        return base_img

    region = base_img.crop((x1, y1, x2, y2)).convert("RGBA")
    blurred = region.filter(ImageFilter.GaussianBlur(blur_radius))

    # Мягкая тонировка для читаемости белого текста + лёгкий градиент верхнего блика без обводки
    dark_layer = Image.new("RGBA", (w, h), (10, 15, 26, dark_tint))
    glass = Image.alpha_composite(blurred, dark_layer)

    sheen = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    sdraw = ImageDraw.Draw(sheen)
    for row_y in range(h):
        t = row_y / float(max(1, h - 1))
        # Плавное затухание блика сверху вниз
        alpha = int(top_light * ((1.0 - t) ** 1.7) + bottom_light * t)
        sdraw.line([(0, row_y), (w, row_y)], fill=(255, 255, 255, alpha))
    glass = Image.alpha_composite(glass, sheen)

    mask = make_smooth_rounded_mask(w, h, radius)
    out = base_img.copy()
    out.paste(glass, (x1, y1), mask)
    return out

def load_font(size: int, bold: bool = False):
    p = FONT_BOLD_PATH if bold else FONT_REGULAR_PATH
    if p.exists():
        try:
            return ImageFont.truetype(str(p), size)
        except Exception:
            pass
    return ImageFont.load_default()

def make_default_avatar(size: int = 200, text: str = "User") -> Image.Image:
    img = Image.new("RGBA", (size, size), (34, 42, 68, 255))
    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow)
    gdraw.ellipse([0, 0, int(size * 0.8), int(size * 0.8)], fill=(59, 130, 246, 120))
    gdraw.ellipse([int(size * 0.3), int(size * 0.3), size, size], fill=(139, 92, 246, 110))
    glow = glow.filter(ImageFilter.GaussianBlur(size // 6))
    img = Image.alpha_composite(img, glow)

    draw = ImageDraw.Draw(img)
    clean_txt = strip_all_emojis_for_image(text).strip()
    initials = clean_txt[:2].upper() if clean_txt else "U"
    font = load_font(int(size * 0.34), bold=True)
    draw.text((size // 2, size // 2), initials, font=font, fill=(255, 255, 255, 240), anchor="mm")
    return img

def _apply_volumetric_lighting(
    base_img: Image.Image,
    spots: List[Tuple[Tuple[int, int, int, int], Tuple[int, int, int, int]]],
    blur_radius: int = 75,
    screen_strength: float = 0.55,
) -> Image.Image:
    """Накладывает мягкое объёмное студийное освещение (glow + screen bloom)."""
    w, h = base_img.size
    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow)
    for rect, color in spots:
        gdraw.ellipse(rect, fill=color)
    glow = glow.filter(ImageFilter.GaussianBlur(blur_radius))

    out = Image.alpha_composite(base_img.convert("RGBA"), glow)
    if screen_strength > 0:
        glow_rgb = glow.convert("RGB")
        if screen_strength < 1.0:
            glow_rgb = ImageEnhance.Brightness(glow_rgb).enhance(screen_strength)
        screened = ImageChops.screen(out.convert("RGB"), glow_rgb).convert("RGBA")
        out = screened
    return out


def _collect_plushpepe_and_nft_paths() -> Tuple[List[Path], List[Path]]:
    """Собирает пути к картинкам моделей Plush Pepe и обычных NFT-подарков."""
    pepe_paths: List[Path] = []
    if PLUSHPEPE_MODELS_DIR.exists():
        pepe_paths = sorted(
            p for p in PLUSHPEPE_MODELS_DIR.iterdir()
            if p.is_file() and p.suffix.lower() in {".webp", ".png", ".jpg", ".jpeg"}
        )
    nft_paths: List[Path] = []
    if IMAGES_DIR.exists():
        nft_paths = sorted(
            p for p in IMAGES_DIR.iterdir()
            if p.is_file() and p.suffix.lower() in {".webp", ".png", ".jpg", ".jpeg"}
        )
    return pepe_paths, nft_paths


def _build_nft_showcase_backdrop(
    width: int,
    height: int,
    seed_val: int = 0,
    favorite_gifts: Optional[List] = None,
    theme: str = "clan",
) -> Image.Image:
    """Создаёт объёмный фон с плюшевыми Пеппами, рандомными NFT и студийным освещением."""
    rng = random.Random(seed_val) if seed_val else random.Random()
    base = Image.new("RGBA", (width, height), (13, 18, 33, 255))

    if theme == "market":
        spots = [
            ((-80, -90, int(width * 0.48), int(height * 0.92)), (16, 185, 129, 130)),
            ((int(width * 0.48), -110, width + 90, int(height * 0.85)), (59, 130, 246, 115)),
            ((int(width * 0.22), int(height * 0.35), int(width * 0.82), height + 120), (139, 92, 246, 95)),
        ]
    else:
        spots = [
            ((-90, -100, int(width * 0.48), int(height * 0.85)), (56, 189, 248, 120)),
            ((int(width * 0.46), -90, width + 110, int(height * 0.88)), (168, 85, 247, 125)),
            ((int(width * 0.22), int(height * 0.38), int(width * 0.80), height + 130), (250, 204, 21, 88)),
        ]
    base = _apply_volumetric_lighting(base, spots, blur_radius=78, screen_strength=0.62)

    pepe_paths, nft_paths = _collect_plushpepe_and_nft_paths()
    chosen_paths: List[Path] = []

    if favorite_gifts:
        for fav in favorite_gifts[:4]:
            try:
                if isinstance(fav, sqlite3.Row):
                    if fav["is_upgraded"] and fav["model_name"]:
                        mp = PLUSHPEPE_MODELS_DIR / f"{fav['model_name']}.webp"
                        if mp.exists():
                            chosen_paths.append(mp)
                            continue
                    gp = gift_image_path(fav["gift_key"])
                else:
                    gp = gift_image_path(fav.key)
                if gp and gp.exists():
                    chosen_paths.append(gp)
            except Exception:
                pass

    pepe_pool = [p for p in pepe_paths if p not in chosen_paths]
    nft_pool = [p for p in nft_paths if p not in chosen_paths]
    rng.shuffle(pepe_pool)
    rng.shuffle(nft_pool)

    # Обязательно включаем плюшевых Пепп и рандомные NFT в композицию заднего фона
    mixed = chosen_paths + pepe_pool[:4] + nft_pool[:4]
    if not mixed:
        return base

    # Позиции (x_center_ratio, y_center_ratio, size, angle, blur, alpha, glow_rgb)
    layout = [
        (0.82, 0.48, int(height * 0.56), -7, 1.8, 225, (168, 85, 247)),   # Крупный герой справа
        (0.16, 0.30, int(height * 0.38), 11, 2.4, 195, (56, 189, 248)),   # Верх-лево
        (0.50, 0.52, int(height * 0.42), -4, 3.2, 165, (250, 204, 21)),   # Центр за стеклом
        (0.12, 0.82, int(height * 0.34), -12, 2.8, 190, (16, 185, 129)),  # Низ-лево
        (0.88, 0.84, int(height * 0.32), 14, 2.8, 185, (236, 72, 153)),   # Низ-право
        (0.35, 0.14, int(height * 0.28), 8, 3.6, 155, (99, 102, 241)),    # Верх-центр-лево
    ]

    glow_layer = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow_layer)
    items_layer = Image.new("RGBA", (width, height), (0, 0, 0, 0))

    for idx, (rx, ry, target_sz, angle, blur_r, opacity, glow_rgb) in enumerate(layout):
        asset_path = mixed[idx % len(mixed)]
        try:
            art = Image.open(asset_path).convert("RGBA")
            art.thumbnail((target_sz, target_sz), Image.Resampling.LANCZOS)
            if angle:
                art = art.rotate(angle, resample=Image.Resampling.BICUBIC, expand=True)
            if blur_r > 0:
                art = art.filter(ImageFilter.GaussianBlur(blur_r))
            if opacity < 255:
                r_ch, g_ch, b_ch, a_ch = art.split()
                a_ch = a_ch.point(lambda v: int(v * opacity / 255.0))
                art = Image.merge("RGBA", (r_ch, g_ch, b_ch, a_ch))

            cx = int(width * rx)
            cy = int(height * ry)
            halo_r = int(max(art.width, art.height) * 0.58)
            gdraw.ellipse(
                [cx - halo_r, cy - halo_r, cx + halo_r, cy + halo_r],
                fill=(glow_rgb[0], glow_rgb[1], glow_rgb[2], 78),
            )
            items_layer.alpha_composite(art, (cx - art.width // 2, cy - art.height // 2))
        except Exception:
            continue

    glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(38))
    base = Image.alpha_composite(base, glow_layer)
    base = Image.alpha_composite(base, items_layer)

    # Лёгкая атмосферная вуаль сверху для контраста жидкого стекла
    veil = Image.new("RGBA", (width, height), (8, 12, 24, 58))
    return Image.alpha_composite(base, veil)


def render_clan_preset_avatar(preset_key: str, size: int = 512) -> Optional[Image.Image]:
    """Рендерит готовую качественную аватарку клана по ключу пресета."""
    entry = next((item for item in CLAN_PRESET_AVATARS if item[0] == preset_key), None)
    if not entry:
        return None
    _, _, source = entry

    if source.startswith("model:"):
        model_name = source.split(":", 1)[1]
        model_path = PLUSHPEPE_MODELS_DIR / f"{model_name}.webp"
        bg = Image.new("RGBA", (size, size), (16, 22, 40, 255))
        palette_map = {
            "Midas Pepe": [
                ((-int(size * 0.15), -int(size * 0.15), int(size * 0.8), int(size * 0.8)), (250, 204, 21, 150)),
                ((int(size * 0.25), int(size * 0.25), int(size * 1.1), int(size * 1.1)), (245, 158, 11, 130)),
            ],
            "Cozy Galaxy": [
                ((-int(size * 0.15), -int(size * 0.15), int(size * 0.8), int(size * 0.8)), (139, 92, 246, 155)),
                ((int(size * 0.25), int(size * 0.25), int(size * 1.1), int(size * 1.1)), (56, 189, 248, 135)),
            ],
            "Emerald Plush": [
                ((-int(size * 0.15), -int(size * 0.15), int(size * 0.8), int(size * 0.8)), (16, 185, 129, 155)),
                ((int(size * 0.25), int(size * 0.25), int(size * 1.1), int(size * 1.1)), (34, 211, 238, 135)),
            ],
        }
        bg = _apply_volumetric_lighting(
            bg,
            palette_map.get(model_name, [((0, 0, size, size), (99, 102, 241, 140))]),
            blur_radius=max(18, size // 6),
            screen_strength=0.75,
        )
        if model_path.exists():
            try:
                pepe = Image.open(model_path).convert("RGBA")
                pepe.thumbnail((int(size * 0.78), int(size * 0.78)), Image.Resampling.LANCZOS)
                halo = Image.new("RGBA", (size, size), (0, 0, 0, 0))
                hdraw = ImageDraw.Draw(halo)
                pad = int(size * 0.16)
                hdraw.ellipse([pad, pad, size - pad, size - pad], fill=(255, 255, 255, 70))
                halo = halo.filter(ImageFilter.GaussianBlur(max(12, size // 10)))
                bg = Image.alpha_composite(bg, halo)
                px = (size - pepe.width) // 2
                py = (size - pepe.height) // 2
                bg.alpha_composite(pepe, (px, py))
            except Exception:
                pass
        return bg

    img_path = CLAN_PRESETS_DIR / source
    if img_path.exists():
        try:
            loaded = Image.open(img_path).convert("RGBA")
            return ImageOps.fit(loaded, (size, size), method=Image.Resampling.LANCZOS)
        except Exception:
            pass
    return None


def make_default_clan_avatar(size: int = 190, tag: str = "CLAN", name: str = "Clan", clan_id: int = 0) -> Image.Image:
    """Возвращает стильную фото-аватарку клана (без скучных букв и обводок)."""
    idx_seed = clan_id if clan_id else sum(ord(ch) for ch in (tag or name or "CLAN"))
    if CLAN_PRESET_AVATARS:
        preset_key = CLAN_PRESET_AVATARS[idx_seed % len(CLAN_PRESET_AVATARS)][0]
        rendered = render_clan_preset_avatar(preset_key, size=size)
        if rendered is not None:
            return rendered

    img = Image.new("RGBA", (size, size), (24, 32, 54, 255))
    img = _apply_volumetric_lighting(
        img,
        [
            ((-10, -10, int(size * 0.85), int(size * 0.85)), (59, 130, 246, 135)),
            ((int(size * 0.25), int(size * 0.25), size + 10, size + 10), (234, 179, 8, 115)),
        ],
        blur_radius=max(14, size // 6),
        screen_strength=0.65,
    )
    return img


async def generate_main_menu_banner() -> io.BytesIO:
    """Генерирует чистую, качественную и притягательную главную фотографию без лишнего текста и обводок."""
    WIDTH, HEIGHT = 1000, 560
    hero_path = UI_ASSETS_DIR / "menu_hero.jpg"

    if hero_path.exists():
        try:
            raw_hero = Image.open(hero_path).convert("RGBA")
            img = ImageOps.fit(raw_hero, (WIDTH, HEIGHT), method=Image.Resampling.LANCZOS)
            rgb = ImageEnhance.Contrast(img.convert("RGB")).enhance(1.06)
            rgb = ImageEnhance.Color(rgb).enhance(1.08)
            img = rgb.convert("RGBA")
            # Деликатный тёплый золотой и сапфировый студийный свет без текста и рамок
            img = _apply_volumetric_lighting(
                img,
                [
                    ((int(WIDTH * 0.18), int(HEIGHT * 0.08), int(WIDTH * 0.64), int(HEIGHT * 0.88)), (250, 204, 21, 32)),
                    ((int(WIDTH * 0.56), -40, WIDTH + 60, int(HEIGHT * 0.72)), (59, 130, 246, 40)),
                ],
                blur_radius=75,
                screen_strength=0.45,
            )
            bio = io.BytesIO()
            img.save(bio, "PNG")
            bio.name = "menu.png"
            bio.seek(0)
            return bio
        except Exception as e:
            log.warning("Не удалось загрузить menu_hero.jpg: %s", e)

    # Резервный чистый визуал без текста и обводок (на базе моделей Plush Pepe)
    img = _build_nft_showcase_backdrop(WIDTH, HEIGHT, seed_val=777, theme="clan")
    bio = io.BytesIO()
    img.save(bio, "PNG")
    bio.name = "menu.png"
    bio.seek(0)
    return bio


async def generate_market_banner() -> io.BytesIO:
    """Генерирует объёмный баннер NFT Маркета с улучшенным освещением и жидким стеклом без обводки."""
    WIDTH, HEIGHT = 1000, 440
    market_hero = UI_ASSETS_DIR / "market_hero.jpg"

    if market_hero.exists():
        try:
            raw = Image.open(market_hero).convert("RGBA")
            img = ImageOps.fit(raw, (WIDTH, HEIGHT), method=Image.Resampling.LANCZOS)
            img = _apply_volumetric_lighting(
                img,
                [
                    ((-40, -60, 460, 380), (16, 185, 129, 75)),
                    ((520, -60, 1040, 400), (59, 130, 246, 70)),
                ],
                blur_radius=70,
                screen_strength=0.50,
            )
        except Exception:
            img = _build_nft_showcase_backdrop(WIDTH, HEIGHT, seed_val=2025, theme="market")
    else:
        img = _build_nft_showcase_backdrop(WIDTH, HEIGHT, seed_val=2025, theme="market")

    # Мягко добавляем 2 светящихся Plush Pepe по краям для связи с коллекцией
    for idx, (m_name, cx, cy) in enumerate([("Emerald Plush", 145, 220), ("Midas Pepe", WIDTH - 145, 220)]):
        mp = PLUSHPEPE_MODELS_DIR / f"{m_name}.webp"
        if mp.exists():
            try:
                pepe = Image.open(mp).convert("RGBA")
                pepe.thumbnail((170, 170), Image.Resampling.LANCZOS)
                pepe = pepe.rotate(10 if idx == 0 else -10, resample=Image.Resampling.BICUBIC, expand=True)
                pepe = pepe.filter(ImageFilter.GaussianBlur(1.4))
                r_ch, g_ch, b_ch, a_ch = pepe.split()
                a_ch = a_ch.point(lambda v: int(v * 0.72))
                pepe = Image.merge("RGBA", (r_ch, g_ch, b_ch, a_ch))
                img.alpha_composite(pepe, (cx - pepe.width // 2, cy - pepe.height // 2))
            except Exception:
                pass

    # Главная панель жидкого стекла (строго без обводки)
    img = apply_liquid_glass_panel(
        img,
        box=(56, 56, WIDTH - 56, HEIGHT - 56),
        radius=30,
        blur_radius=22,
        dark_tint=64,
        top_light=48,
        bottom_light=10,
    )

    draw = ImageDraw.Draw(img)
    f_badge = load_font(16, bold=True)
    f_title = load_font(54, bold=True)
    f_sub = load_font(23, bold=True)
    f_meta = load_font(18, bold=True)

    draw.text((WIDTH // 2, 118), "P2P TRADE EXCHANGE", font=f_badge, fill=(52, 211, 153), anchor="mm")
    draw.text((WIDTH // 2, 194), "NFT MARKETPLACE", font=f_title, fill=(255, 255, 255), anchor="mm")
    draw.text((WIDTH // 2, 268), "Покупка и продажа улучшенных Plush Pepe", font=f_sub, fill=(226, 232, 240), anchor="mm")
    draw.text((WIDTH // 2, 322), "Комиссия 15%  •  От 1,000 до 100 млрд Stars", font=f_meta, fill=(250, 204, 21), anchor="mm")

    bio = io.BytesIO()
    img.save(bio, "PNG")
    bio.name = "market.png"
    bio.seek(0)
    return bio


async def generate_clans_hub_banner() -> io.BytesIO:
    """Генерирует баннер раздела Кланы с плюшевыми Пеппами, рандомными NFT на фоне, освещением и жидким стеклом."""
    WIDTH, HEIGHT = 1000, 440
    img = _build_nft_showcase_backdrop(WIDTH, HEIGHT, seed_val=0, theme="clan")

    img = apply_liquid_glass_panel(
        img,
        box=(56, 56, WIDTH - 56, HEIGHT - 56),
        radius=30,
        blur_radius=22,
        dark_tint=66,
        top_light=48,
        bottom_light=10,
    )

    draw = ImageDraw.Draw(img)
    f_badge = load_font(16, bold=True)
    f_title = load_font(52, bold=True)
    f_sub = load_font(23, bold=True)
    f_meta = load_font(18, bold=True)

    draw.text((WIDTH // 2, 118), "CLAN SYNDICATES  •  NEW NFT", font=f_badge, fill=(250, 204, 21), anchor="mm")
    draw.text((WIDTH // 2, 194), "КЛАНЫ И АЛЬЯНСЫ", font=f_title, fill=(255, 255, 255), anchor="mm")
    draw.text((WIDTH // 2, 268), "Общая казна, уникальные гербы и клановый рейтинг", font=f_sub, fill=(226, 232, 240), anchor="mm")
    draw.text((WIDTH // 2, 322), "Бонус к шансу выигрыша подарков от +1% до +45%", font=f_meta, fill=(52, 211, 153), anchor="mm")

    bio = io.BytesIO()
    img.save(bio, "PNG")
    bio.name = "clans_hub.png"
    bio.seek(0)
    return bio

def make_rainbow_gradient_bg(size: int) -> Image.Image:
    """Создаёт яркий мифический радужный градиент."""
    stops = [
        (0.00, (255, 59, 107)),   # Pink-Red
        (0.18, (255, 138, 36)),   # Orange
        (0.36, (250, 214, 48)),   # Gold-Yellow
        (0.54, (45, 224, 138)),   # Emerald
        (0.72, (34, 211, 238)),   # Cyan
        (0.86, (79, 124, 255)),   # Blue
        (1.00, (168, 85, 247)),   # Violet
    ]
    def _sample(t: float) -> Tuple[int, int, int]:
        t = max(0.0, min(1.0, t))
        for idx in range(len(stops) - 1):
            t0, c0 = stops[idx]
            t1, c1 = stops[idx + 1]
            if t <= t1:
                lt = (t - t0) / max(1e-6, (t1 - t0))
                return (
                    int(c0[0] + (c1[0] - c0[0]) * lt),
                    int(c0[1] + (c1[1] - c0[1]) * lt),
                    int(c0[2] + (c1[2] - c0[2]) * lt),
                )
        return stops[-1][1]

    # Диагональный градиент на полосе шириной size*2 + поворот 45 deg для идеальной скорости и гладкости
    strip_w = max(64, size)
    strip = Image.new("RGBA", (strip_w, 1))
    sdraw = ImageDraw.Draw(strip)
    for x in range(strip_w):
        col = _sample(x / float(max(1, strip_w - 1)))
        sdraw.point((x, 0), fill=col + (255,))
    base = strip.resize((size * 2, size * 2), Image.Resampling.BILINEAR).rotate(-35)
    left = (base.width - size) // 2
    top = (base.height - size) // 2
    img = base.crop((left, top, left + size, top + size))

    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow)
    c = size // 2
    r = int(size * 0.38)
    gdraw.ellipse([c - r, c - r, c + r, c + r], fill=(255, 255, 255, 90))
    glow = glow.filter(ImageFilter.GaussianBlur(max(4, size // 7)))
    return Image.alpha_composite(img, glow)

def make_radial_gradient_bg(size: int, center_hex: str, edge_hex: str, backdrop_key: str = "") -> Image.Image:
    """Создаёт плавный радиальный (или радужный) градиент как на карточках коллекционных подарков Telegram."""
    if backdrop_key == "rainbow":
        return make_rainbow_gradient_bg(size)
    c_rgb = parse_hex_rgb(center_hex, (70, 90, 120))
    e_rgb = parse_hex_rgb(edge_hex, (20, 26, 38))
    base = Image.new("RGBA", (size, size), e_rgb + (255,))
    draw = ImageDraw.Draw(base)
    steps = 72
    cx, cy = size / 2.0, size / 2.0
    max_r = size * 0.72
    for i in range(steps):
        t = i / float(steps - 1)
        r = max_r * (1.0 - t)
        blend = t ** 1.35
        col = (
            int(e_rgb[0] + (c_rgb[0] - e_rgb[0]) * blend),
            int(e_rgb[1] + (c_rgb[1] - e_rgb[1]) * blend),
            int(e_rgb[2] + (c_rgb[2] - e_rgb[2]) * blend),
            255,
        )
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=col)
    return base

def _render_upgraded_slot_thumbnail(slot_w: int, slot_h: int, model_name: str, backdrop_key: str) -> Image.Image:
    bdef = BACKDROPS_BY_KEY.get(backdrop_key) or PLUSHPEPE_BACKDROPS[0]
    mdef = PLUSHPEPE_MODELS_BY_NAME.get(model_name) or PLUSHPEPE_MODELS[0]
    grad = make_radial_gradient_bg(slot_w, bdef.center_hex, bdef.edge_hex, backdrop_key=bdef.key)

    m_path = plush_model_image_path(mdef.filename)
    if m_path and m_path.exists():
        try:
            m_img = Image.open(m_path).convert("RGBA")
            m_img.thumbnail((int(slot_w * 0.78), int(slot_h * 0.78)), Image.Resampling.LANCZOS)
            mx = (slot_w - m_img.width) // 2
            my = (slot_h - m_img.height) // 2
            grad.paste(m_img, (mx, my), m_img)
        except Exception:
            pass

    mask = make_smooth_rounded_mask(slot_w, slot_h, 18)
    out = Image.new("RGBA", (slot_w, slot_h), (0, 0, 0, 0))
    out.paste(grad, (0, 0), mask)
    return out

async def generate_gift_card_image(gift: GiftDef) -> Optional[io.BytesIO]:
    """Генерирует минималистичную карточку обычного NFT-подарка в стиле жидкого стекла."""
    img_p = gift_image_path(gift.key)
    if not img_p or not img_p.exists():
        return None

    SIZE = 720
    img = Image.new("RGBA", (SIZE, SIZE), (16, 22, 36, 255))

    if gift.stars >= 80_000:
        c1, c2 = (234, 179, 8, 115), (168, 85, 247, 95)
    elif gift.stars >= 15_000:
        c1, c2 = (139, 92, 246, 115), (59, 130, 246, 95)
    elif gift.stars >= 2_000:
        c1, c2 = (59, 130, 246, 110), (14, 165, 233, 90)
    else:
        c1, c2 = (16, 185, 129, 95), (59, 130, 246, 85)

    glow = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow)
    gdraw.ellipse([-40, -40, 440, 440], fill=c1)
    gdraw.ellipse([260, 180, 760, 700], fill=c2)
    glow = glow.filter(ImageFilter.GaussianBlur(70))
    img = Image.alpha_composite(img, glow)

    # Центральная стеклянная витрина (строго без обводки)
    img = apply_liquid_glass_panel(
        img,
        box=(34, 34, SIZE - 34, 496),
        radius=28,
        blur_radius=20,
        dark_tint=48,
        top_light=38,
        bottom_light=8,
    )
    # Верхние стеклянные бейджи
    img = apply_liquid_glass_panel(img, (54, 54, 214, 96), radius=13, blur_radius=12, dark_tint=56, top_light=34, bottom_light=8)
    img = apply_liquid_glass_panel(img, (SIZE - 214, 54, SIZE - 54, 96), radius=13, blur_radius=12, dark_tint=56, top_light=34, bottom_light=8)

    try:
        g_img = Image.open(img_p).convert("RGBA")
        g_img.thumbnail((340, 340), Image.Resampling.LANCZOS)
        gx = (SIZE - g_img.width) // 2
        gy = 104 + (365 - g_img.height) // 2
        img.paste(g_img, (gx, gy), g_img)
    except Exception:
        return None

    # Нижняя карточка характеристик в стиле жидкого стекла (без обводки)
    img = apply_liquid_glass_panel(
        img,
        box=(34, 514, SIZE - 34, SIZE - 34),
        radius=26,
        blur_radius=20,
        dark_tint=72,
        top_light=42,
        bottom_light=10,
    )

    draw = ImageDraw.Draw(img)
    f_badge = load_font(16, bold=True)
    f_title = load_font(30, bold=True)
    f_sub = load_font(19, bold=True)
    f_val = load_font(26, bold=True)

    draw.text((134, 75), "NFT GIFT", font=f_badge, fill=(226, 232, 240), anchor="mm")
    draw.text((SIZE - 134, 75), f"+{gift.xp:,} XP", font=f_badge, fill=(96, 165, 250), anchor="mm")

    clean_title = strip_all_emojis_for_image(gift.name)
    if len(clean_title) > 28:
        clean_title = clean_title[:26] + ".."
    clean_model = strip_all_emojis_for_image(gift.model_name)

    draw.text((62, 540), clean_title, font=f_title, fill=(255, 255, 255))
    draw.text((62, 582), f"Model: {clean_model}", font=f_sub, fill=(203, 213, 225))

    draw.rounded_rectangle([62, 624, 66, 660], radius=2, fill=(250, 204, 21, 235))
    draw.text((78, 628), f"{fmt_stars_compact(gift.stars)} STARS", font=f_val, fill=(250, 204, 21))

    bio = io.BytesIO()
    img.save(bio, "PNG")
    bio.name = f"gift_{gift.key}.png"
    bio.seek(0)
    return bio

async def generate_upgraded_gift_image(
    model: PlushModelDef,
    backdrop: BackdropDef,
    upgrade_num: int,
    upgraded_stars: int,
    list_price: Optional[int] = None,
) -> io.BytesIO:
    SIZE = 720
    img = make_radial_gradient_bg(SIZE, backdrop.center_hex, backdrop.edge_hex, backdrop_key=backdrop.key)
    is_mono = is_monochrome_combo(model.name, backdrop.key)

    overlay = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    odraw = ImageDraw.Draw(overlay)
    for px, py, pr, alpha in [
        (115, 145, 4, 140), (610, 170, 5, 150), (145, 470, 3, 120),
        (585, 440, 4, 130), (210, 95, 3, 115), (520, 110, 3, 115),
    ]:
        odraw.ellipse([px - pr, py - pr, px + pr, py + pr], fill=(255, 255, 255, alpha))
    img = Image.alpha_composite(img, overlay)

    f_badge = load_font(20, bold=True)
    f_title = load_font(30, bold=True)
    f_sub = load_font(20, bold=False)
    f_val = load_font(26, bold=True)

    # Бейджи в стиле жидкого стекла (строго без обводки)
    img = apply_liquid_glass_panel(img, (34, 34, 286, 82), radius=16, blur_radius=16, dark_tint=72, top_light=42, bottom_light=10)
    draw = ImageDraw.Draw(img)
    draw.text((160, 58), f"PLUSH PEPE #{upgrade_num}", font=f_badge, fill=(255, 255, 255), anchor="mm")

    rarity_color = (
        (244, 114, 182) if backdrop.rarity_label == "Мифический"
        else (250, 204, 21) if backdrop.rarity_label == "Ультра-редкий"
        else (96, 165, 250) if backdrop.rarity_label == "Редкий"
        else (192, 132, 252) if backdrop.rarity_label == "Необычный"
        else (52, 211, 153)
    )
    img = apply_liquid_glass_panel(img, (SIZE - 260, 34, SIZE - 34, 82), radius=16, blur_radius=16, dark_tint=72, top_light=42, bottom_light=10)
    draw = ImageDraw.Draw(img)
    draw.text((SIZE - 147, 58), backdrop.rarity_label.upper(), font=load_font(17, bold=True), fill=rarity_color, anchor="mm")

    if is_mono:
        img = apply_liquid_glass_panel(img, (SIZE - 260, 92, SIZE - 34, 130), radius=14, blur_radius=14, dark_tint=78, top_light=38, bottom_light=10)
        draw = ImageDraw.Draw(img)
        draw.text((SIZE - 147, 111), "MONOCHROME x6", font=load_font(15, bold=True), fill=(125, 211, 252), anchor="mm")

    # Модель Plush Pepe в центре
    m_path = plush_model_image_path(model.filename)
    if m_path and m_path.exists():
        try:
            m_img = Image.open(m_path).convert("RGBA")
            m_img.thumbnail((390, 390), Image.Resampling.LANCZOS)
            mx = (SIZE - m_img.width) // 2
            my = 110 + (390 - m_img.height) // 2
            img.paste(m_img, (mx, my), m_img)
        except Exception as e:
            log.warning("Ошибка загрузки модели %s: %s", model.filename, e)

    # Нижняя стеклянная карточка характеристик (жидкое стекло без обводки)
    img = apply_liquid_glass_panel(img, (34, 514, SIZE - 34, SIZE - 30), radius=26, blur_radius=20, dark_tint=84, top_light=44, bottom_light=10)
    draw = ImageDraw.Draw(img)

    draw.text((62, 538), f"Model: {model.name} ({model.chance_pct}%)", font=f_title, fill=(255, 255, 255))
    mono_note = " • MONOCHROME" if is_mono else ""
    draw.text((62, 582), f"Backdrop: {backdrop.name} ({backdrop.chance_pct}%){mono_note}", font=f_sub, fill=(226, 232, 240))

    if list_price is not None:
        draw.rounded_rectangle([62, 624, 66, 658], radius=2, fill=(52, 211, 153, 235))
        draw.text((78, 626), f"MARKET: {fmt_stars_compact(list_price)} STARS", font=f_val, fill=(52, 211, 153))
        draw.text((SIZE - 62, 632), f"Est: {fmt_stars_compact(upgraded_stars)}", font=load_font(18, bold=True), fill=(250, 204, 21), anchor="ra")
    else:
        draw.rounded_rectangle([62, 624, 66, 658], radius=2, fill=(250, 204, 21, 235))
        draw.text((78, 626), f"EST. VALUE: ~{fmt_stars_compact(upgraded_stars)} STARS", font=f_val, fill=(250, 204, 21))

    bio = io.BytesIO()
    img.save(bio, "PNG")
    bio.name = f"plushpepe_{upgrade_num}.png"
    bio.seek(0)
    return bio

async def generate_check_card_image(
    amount_stars: Optional[int],
    creator_name: str,
    target_label: str = "Для всех в чате",
    claimed_by: Optional[str] = None,
) -> io.BytesIO:
    """Генерирует карточку подарочного чека на звёзды в стиле жидкого стекла (строго без обводки)."""
    WIDTH, HEIGHT = 920, 440
    base = Image.new("RGBA", (WIDTH, HEIGHT), (16, 22, 36, 255))
    glow = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow)
    gdraw.ellipse([-50, -70, 460, 360], fill=(37, 99, 235, 115))
    gdraw.ellipse([480, -40, 990, 380], fill=(139, 92, 246, 90))
    gdraw.ellipse([240, 150, 700, 470], fill=(16, 185, 129, 75) if claimed_by else (234, 179, 8, 70))
    glow = glow.filter(ImageFilter.GaussianBlur(65))
    base = Image.alpha_composite(base, glow)

    # Верхняя панель жидкого стекла (без обводки)
    img = apply_liquid_glass_panel(
        base,
        box=(36, 32, WIDTH - 36, 298),
        radius=28,
        blur_radius=20,
        dark_tint=68,
        top_light=42,
        bottom_light=10,
    )
    # Верхние стеклянные бейджи
    img = apply_liquid_glass_panel(img, (60, 56, 286, 92), radius=13, blur_radius=12, dark_tint=42, top_light=34, bottom_light=8)
    img = apply_liquid_glass_panel(img, (WIDTH - 246, 56, WIDTH - 60, 92), radius=13, blur_radius=12, dark_tint=42, top_light=34, bottom_light=8)

    # Нижняя панель жидкого стекла (без обводки)
    img = apply_liquid_glass_panel(
        img,
        box=(36, 314, WIDTH - 36, HEIGHT - 32),
        radius=24,
        blur_radius=20,
        dark_tint=64,
        top_light=34,
        bottom_light=8,
    )

    draw = ImageDraw.Draw(img)

    c_clean = strip_all_emojis_for_image(creator_name, fallback_id=None)
    t_clean = strip_all_emojis_for_image(target_label)

    draw.text((173, 74), "NFT STARS VOUCHER", font=load_font(15, bold=True), fill=(203, 213, 225), anchor="mm")
    status_lbl = "CLAIMED" if claimed_by else "ACTIVE CHECK"
    status_col = (52, 211, 153) if claimed_by else (250, 204, 21)
    draw.text((WIDTH - 153, 74), status_lbl, font=load_font(15, bold=True), fill=status_col, anchor="mm")

    if amount_stars is not None:
        amount_str = f"{fmt_stars_compact(amount_stars)} STARS"
        rub_str = f"~{fmt_stars_compact(int(round(amount_stars * STAR_RUB_RATE)))} RUB"
    else:
        amount_str = "STARS VOUCHER"
        rub_str = "TELEGRAM STARS CHECK"

    draw.text((WIDTH // 2, 178), amount_str, font=load_font(64, bold=True), fill=(255, 255, 255), anchor="mm")
    draw.text((WIDTH // 2, 240), rub_str, font=load_font(21, bold=True), fill=(250, 204, 21), anchor="mm")

    if claimed_by:
        cl_clean = strip_all_emojis_for_image(claimed_by)
        footer_left = f"От: {c_clean[:20]}"
        footer_right = f"Активировал: {cl_clean[:22]}"
        accent_col = (52, 211, 153, 235)
    else:
        footer_left = f"От: {c_clean[:22]}"
        footer_right = f"Получатель: {t_clean[:24]}"
        accent_col = (250, 204, 21, 235)

    draw.rounded_rectangle([60, 344, 64, 378], radius=2, fill=accent_col)
    draw.text((78, 361), footer_left, font=load_font(20, bold=True), fill=(255, 255, 255), anchor="lm")
    draw.text((WIDTH - 60, 361), footer_right, font=load_font(20, bold=True), fill=(203, 213, 225), anchor="rm")

    bio = io.BytesIO()
    img.save(bio, "PNG")
    bio.name = "star_check.png"
    bio.seek(0)
    return bio

async def generate_profile_card_image(
    user_name: str,
    user_sys_id: int,
    stars_balance: int,
    user_xp: int,
    rank: int,
    favorite_gifts: List,
    avatar_bytes: Optional[bytes] = None,
    clan_tag: Optional[str] = None,
    custom_bg_path: Optional[str] = None,
    fallback_username: Optional[str] = None,
    telegram_user_id: Optional[int] = None,
) -> io.BytesIO:
    WIDTH, HEIGHT = 1000, 560
    clean_name = strip_all_emojis_for_image(
        user_name,
        fallback_username=fallback_username,
        fallback_id=telegram_user_id or user_sys_id,
    )

    has_custom_bg = False
    if custom_bg_path and Path(custom_bg_path).exists():
        try:
            custom_img = Image.open(custom_bg_path).convert("RGBA")
            base_bg = ImageOps.fit(custom_img, (WIDTH, HEIGHT), method=Image.Resampling.LANCZOS)
            # Лёгкая мягкость и деликатное затемнение, чтобы кастомный фон был чётко виден
            base_bg = base_bg.filter(ImageFilter.GaussianBlur(2))
            darken_overlay = Image.new("RGBA", (WIDTH, HEIGHT), (10, 14, 24, 72))
            base_bg = Image.alpha_composite(base_bg, darken_overlay)
            has_custom_bg = True
        except Exception as e:
            log.warning("Не удалось обработать кастомный фон пользователя: %s", e)

    if not has_custom_bg:
        base_bg = Image.new("RGBA", (WIDTH, HEIGHT), (16, 22, 36, 255))
        glow = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
        glow_draw = ImageDraw.Draw(glow)
        glow_draw.ellipse([-40, -60, 420, 380], fill=(37, 99, 235, 105))
        glow_draw.ellipse([540, -80, 1020, 320], fill=(139, 92, 246, 85))
        glow_draw.ellipse([260, 260, 780, 620], fill=(14, 165, 233, 65))
        glow = glow.filter(ImageFilter.GaussianBlur(65))
        base_bg = Image.alpha_composite(base_bg, glow)

    # Верхняя панель жидкого стекла (строго без обводки)
    base_bg = apply_liquid_glass_panel(
        base_bg,
        box=(36, 36, 964, 282),
        radius=28,
        blur_radius=20,
        dark_tint=68,
        top_light=42,
        bottom_light=10,
    )
    # Нижняя панель для избранного (жидкое стекло без обводки)
    base_bg = apply_liquid_glass_panel(
        base_bg,
        box=(36, 300, 964, 514),
        radius=28,
        blur_radius=20,
        dark_tint=64,
        top_light=34,
        bottom_light=8,
    )

    draw = ImageDraw.Draw(base_bg)

    font_title = load_font(38, bold=True)
    font_sub = load_font(21, bold=True)
    font_small = load_font(18, bold=True)
    font_stat_val = load_font(33, bold=True)
    font_stat_lbl = load_font(15, bold=True)

    av_size = 190
    if avatar_bytes:
        try:
            loaded_av = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
            av_img = ImageOps.fit(loaded_av, (av_size, av_size), method=Image.Resampling.LANCZOS)
        except Exception:
            av_img = make_default_avatar(av_size, clean_name)
    else:
        av_img = make_default_avatar(av_size, clean_name)

    av_mask = make_smooth_rounded_mask(av_size, av_size, 26)
    av_x, av_y = 62, 64
    base_bg.paste(av_img, (av_x, av_y), av_mask)

    text_x = 282
    curr_x = text_x
    if clan_tag:
        tag_str = f"[{clan_tag.upper()}] "
        draw.text((curr_x, 68), tag_str, font=font_title, fill=(250, 204, 21))
        bbox = draw.textbbox((curr_x, 68), tag_str, font=font_title)
        curr_x = bbox[2]

    disp_name = clean_name if len(clean_name) <= 17 else (clean_name[:15] + "..")
    draw.text((curr_x, 68), disp_name, font=font_title, fill=(255, 255, 255))

    lvl, cur_xp, req_xp, ratio = calculate_xp_level_info(user_xp)
    draw.text((text_x, 122), f"LEVEL {lvl}  •  {cur_xp:,} / {req_xp:,} XP", font=font_sub, fill=(226, 232, 240))

    bar_x, bar_y, bar_w, bar_h = text_x, 158, 410, 11
    draw_rounded_rect(draw, [bar_x, bar_y, bar_x + bar_w, bar_y + bar_h], radius=5, fill=(255, 255, 255, 42))
    fill_w = max(12, int(bar_w * ratio))
    draw_rounded_rect(draw, [bar_x, bar_y, bar_x + fill_w, bar_y + bar_h], radius=5, fill=(250, 204, 21, 240))

    draw.text((936, 74), f"ID #{user_sys_id}", font=font_small, fill=(203, 213, 225), anchor="ra")

    stats_y = 198
    draw.rounded_rectangle([text_x, stats_y + 2, text_x + 4, stats_y + 48], radius=2, fill=(250, 204, 21, 235))
    draw.text((text_x + 15, stats_y), "STARS BALANCE", font=font_stat_lbl, fill=(203, 213, 225))
    draw.text((text_x + 15, stats_y + 18), f"{fmt_stars_compact(stars_balance)} STARS", font=font_stat_val, fill=(255, 255, 255))

    rank_x = text_x + 310
    draw.rounded_rectangle([rank_x, stats_y + 2, rank_x + 4, stats_y + 48], radius=2, fill=(96, 165, 250, 235))
    draw.text((rank_x + 15, stats_y), "GLOBAL RANK", font=font_stat_lbl, fill=(203, 213, 225))
    draw.text((rank_x + 15, stats_y + 18), f"#{rank}", font=font_stat_val, fill=(255, 255, 255))

    draw.text((62, 318), "FAVORITES", font=font_stat_lbl, fill=(203, 213, 225))

    slot_y = 352
    slot_w, slot_h = 113, 113
    spacing = 15
    start_x = 62

    for i in range(7):
        cur_x = start_x + i * (slot_w + spacing)
        base_bg = apply_liquid_glass_panel(
            base_bg,
            box=(cur_x, slot_y, cur_x + slot_w, slot_y + slot_h),
            radius=18,
            blur_radius=12,
            dark_tint=42,
            top_light=32,
            bottom_light=10,
        )
        draw = ImageDraw.Draw(base_bg)

        if i < len(favorite_gifts):
            fav_item = favorite_gifts[i]
            if isinstance(fav_item, sqlite3.Row):
                is_upg = bool(fav_item["is_upgraded"])
                g = GIFTS_BY_KEY.get(fav_item["gift_key"])
                if is_upg:
                    slot_thumb = _render_upgraded_slot_thumbnail(
                        slot_w,
                        slot_h,
                        fav_item["model_name"] or "Amalgam",
                        fav_item["backdrop_key"] or "black",
                    )
                    base_bg.paste(slot_thumb, (cur_x, slot_y), slot_thumb)
                    continue
            else:
                g = fav_item

            if g:
                img_p = gift_image_path(g.key)
                if img_p and img_p.exists():
                    try:
                        g_img = Image.open(img_p).convert("RGBA")
                        g_img.thumbnail((78, 78), Image.Resampling.LANCZOS)
                        gx = cur_x + (slot_w - g_img.width) // 2
                        gy = slot_y + (slot_h - g_img.height) // 2
                        base_bg.paste(g_img, (gx, gy), g_img)
                    except Exception:
                        pass
                else:
                    clean_g_name = g.name.split('(')[0].strip()[:9]
                    draw.text((cur_x + slot_w // 2, slot_y + slot_h // 2 - 8), clean_g_name, font=load_font(13, bold=True), fill=(255, 255, 255), anchor="mm")
                    draw.text((cur_x + slot_w // 2, slot_y + slot_h - 22), f"{fmt_stars_compact(g.stars)}", font=load_font(11, bold=True), fill=(250, 204, 21), anchor="mm")
        else:
            cx, cy = cur_x + slot_w // 2, slot_y + slot_h // 2
            arm = 11
            thick = 2
            draw.line([(cx - arm, cy - arm), (cx + arm, cy + arm)], fill=(255, 255, 255, 65), width=thick)
            draw.line([(cx + arm, cy - arm), (cx - arm, cy + arm)], fill=(255, 255, 255, 65), width=thick)

    if has_custom_bg:
        base_bg = apply_liquid_glass_panel(base_bg, (36, HEIGHT - 40, 224, HEIGHT - 12), radius=10, blur_radius=12, dark_tint=60, top_light=28, bottom_light=8)
        draw = ImageDraw.Draw(base_bg)
        draw.text((130, HEIGHT - 26), "CUSTOM BACKGROUND", font=load_font(12, bold=True), fill=(241, 245, 249), anchor="mm")

    bio = io.BytesIO()
    base_bg.save(bio, "PNG")
    bio.name = "profile.png"
    bio.seek(0)
    return bio

async def generate_clan_card_image(
    clan_name: str,
    clan_tag: str,
    clan_sys_id: int,
    clan_xp: int,
    treasury_stars: int,
    members_count: int,
    max_members: int,
    favorite_gifts: List[GiftDef],
    avatar_path: Optional[str] = None
) -> io.BytesIO:
    WIDTH, HEIGHT = 1000, 560
    clean_name = strip_all_emojis_for_image(clan_name, fallback_id=clan_sys_id)
    clean_tag = strip_all_emojis_for_image(clan_tag, fallback_id=clan_sys_id).upper()

    # Объёмный задний фон с плюшевыми Пеппами, рандомными NFT и улучшенным студийным светом
    base_bg = _build_nft_showcase_backdrop(
        WIDTH,
        HEIGHT,
        seed_val=clan_sys_id or 1,
        favorite_gifts=favorite_gifts,
        theme="clan",
    )

    # Верхняя панель жидкого стекла (строго без обводки, как в профиле)
    base_bg = apply_liquid_glass_panel(
        base_bg,
        box=(36, 36, 964, 282),
        radius=28,
        blur_radius=20,
        dark_tint=64,
        top_light=48,
        bottom_light=10,
    )
    # Нижняя панель для избранного клана (жидкое стекло без обводки)
    base_bg = apply_liquid_glass_panel(
        base_bg,
        box=(36, 300, 964, 514),
        radius=28,
        blur_radius=20,
        dark_tint=60,
        top_light=38,
        bottom_light=8,
    )

    draw = ImageDraw.Draw(base_bg)

    font_title = load_font(38, bold=True)
    font_sub = load_font(21, bold=True)
    font_small = load_font(18, bold=True)
    font_stat_val = load_font(30, bold=True)
    font_stat_lbl = load_font(15, bold=True)

    av_size = 190
    if avatar_path and Path(avatar_path).exists():
        try:
            loaded_av = Image.open(avatar_path).convert("RGBA")
            av_img = ImageOps.fit(loaded_av, (av_size, av_size), method=Image.Resampling.LANCZOS)
        except Exception:
            av_img = make_default_clan_avatar(av_size, clean_tag, clean_name, clan_id=clan_sys_id)
    else:
        av_img = make_default_clan_avatar(av_size, clean_tag, clean_name, clan_id=clan_sys_id)

    av_mask = make_smooth_rounded_mask(av_size, av_size, 26)
    av_x, av_y = 62, 64
    base_bg.paste(av_img, (av_x, av_y), av_mask)

    text_x = 282
    tag_str = f"[{clean_tag}] "
    draw.text((text_x, 68), tag_str, font=font_title, fill=(250, 204, 21))
    bbox = draw.textbbox((text_x, 68), tag_str, font=font_title)
    disp_name = clean_name if len(clean_name) <= 15 else (clean_name[:13] + "..")
    draw.text((bbox[2], 68), disp_name, font=font_title, fill=(255, 255, 255))

    lvl, cur_xp, req_xp, ratio, drop_bonus = calculate_clan_level_info(clan_xp)
    draw.text((text_x, 122), f"CLAN LEVEL {lvl}  •  {cur_xp:,} / {req_xp:,} XP", font=font_sub, fill=(226, 232, 240))

    bar_x, bar_y, bar_w, bar_h = text_x, 158, 410, 11
    draw_rounded_rect(draw, [bar_x, bar_y, bar_x + bar_w, bar_y + bar_h], radius=5, fill=(255, 255, 255, 42))
    fill_w = max(12, int(bar_w * ratio))
    draw_rounded_rect(draw, [bar_x, bar_y, bar_x + fill_w, bar_y + bar_h], radius=5, fill=(250, 204, 21, 240))

    draw.text((936, 74), f"CLAN ID #{clan_sys_id}", font=font_small, fill=(203, 213, 225), anchor="ra")

    stats_y = 198
    draw.rounded_rectangle([text_x, stats_y + 2, text_x + 4, stats_y + 48], radius=2, fill=(250, 204, 21, 235))
    draw.text((text_x + 15, stats_y), "TOTAL TREASURY", font=font_stat_lbl, fill=(203, 213, 225))
    draw.text((text_x + 15, stats_y + 18), f"{fmt_stars_compact(treasury_stars)} STARS", font=font_stat_val, fill=(255, 255, 255))

    col2_x = text_x + 260
    draw.rounded_rectangle([col2_x, stats_y + 2, col2_x + 4, stats_y + 48], radius=2, fill=(96, 165, 250, 235))
    draw.text((col2_x + 15, stats_y), "MEMBERS", font=font_stat_lbl, fill=(203, 213, 225))
    draw.text((col2_x + 15, stats_y + 18), f"{members_count}/{max_members}", font=font_stat_val, fill=(255, 255, 255))

    col3_x = col2_x + 185
    draw.rounded_rectangle([col3_x, stats_y + 2, col3_x + 4, stats_y + 48], radius=2, fill=(52, 211, 153, 235))
    draw.text((col3_x + 15, stats_y), "WIN BONUS", font=font_stat_lbl, fill=(203, 213, 225))
    draw.text((col3_x + 15, stats_y + 18), f"+{drop_bonus}%", font=font_stat_val, fill=(52, 211, 153))

    draw.text((62, 318), "CLAN FAVORITES", font=font_stat_lbl, fill=(203, 213, 225))

    slot_y = 352
    slot_w, slot_h = 113, 113
    spacing = 15
    start_x = 62

    for i in range(7):
        cur_x = start_x + i * (slot_w + spacing)
        base_bg = apply_liquid_glass_panel(
            base_bg,
            box=(cur_x, slot_y, cur_x + slot_w, slot_y + slot_h),
            radius=18,
            blur_radius=12,
            dark_tint=42,
            top_light=32,
            bottom_light=10,
        )
        draw = ImageDraw.Draw(base_bg)

        if i < len(favorite_gifts):
            g = favorite_gifts[i]
            img_p = gift_image_path(g.key)
            if img_p and img_p.exists():
                try:
                    g_img = Image.open(img_p).convert("RGBA")
                    g_img.thumbnail((78, 78), Image.Resampling.LANCZOS)
                    gx = cur_x + (slot_w - g_img.width) // 2
                    gy = slot_y + (slot_h - g_img.height) // 2
                    base_bg.paste(g_img, (gx, gy), g_img)
                except Exception:
                    pass
            else:
                clean_g_name = g.name.split('(')[0].strip()[:9]
                draw.text((cur_x + slot_w // 2, slot_y + slot_h // 2 - 8), clean_g_name, font=load_font(13, bold=True), fill=(255, 255, 255), anchor="mm")
                draw.text((cur_x + slot_w // 2, slot_y + slot_h - 22), f"{fmt_stars_compact(g.stars)}", font=load_font(11, bold=True), fill=(250, 204, 21), anchor="mm")
        else:
            cx, cy = cur_x + slot_w // 2, slot_y + slot_h // 2
            arm = 11
            thick = 2
            draw.line([(cx - arm, cy - arm), (cx + arm, cy + arm)], fill=(255, 255, 255, 65), width=thick)
            draw.line([(cx + arm, cy - arm), (cx - arm, cy + arm)], fill=(255, 255, 255, 65), width=thick)

    bio = io.BytesIO()
    base_bg.save(bio, "PNG")
    bio.name = "clan.png"
    bio.seek(0)
    return bio

# ---------------------------------------------------------------------------
# КЛАВИАТУРЫ И КЕЙСЫ
# ---------------------------------------------------------------------------

def main_menu_keyboard(user_id: int = 0) -> InlineKeyboardMarkup:
    buttons = [
        [
            InlineKeyboardButton("👤 Профиль", callback_data="nav_profile"),
            InlineKeyboardButton("🗂 Коллекция", callback_data="nav_collection_page:1"),
        ],
        [
            InlineKeyboardButton("🛒 NFT Маркет", callback_data="nav_market"),
            InlineKeyboardButton("🎰 Mystery Cases", callback_data="nav_cases_hub"),
        ],
        [
            InlineKeyboardButton("🛡 Кланы", callback_data="nav_clans_hub"),
            InlineKeyboardButton("🏆 ТОП 100", callback_data="nav_top_page:1"),
        ],
        [
            InlineKeyboardButton("🛍 Улучшения", callback_data="nav_shop"),
            InlineKeyboardButton("🎁 Бонус 24ч", callback_data="nav_bonus"),
        ],
        [
            InlineKeyboardButton("⚙️ Настройки", callback_data="nav_settings"),
            InlineKeyboardButton("ℹ️ Инфо", callback_data="nav_info"),
        ]
    ]
    if user_id in ADMIN_IDS:
        buttons.append([make_btn("👑 Админ-Панель", style="primary", callback_data="admin_panel")])
    return InlineKeyboardMarkup(buttons)

def quick_nav_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👤 Профиль", callback_data="nav_profile"),
            InlineKeyboardButton("🗂 Коллекция", callback_data="nav_collection_page:1"),
        ],
        [
            InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
        ]
    ])

def back_to_main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅️ Главное меню", callback_data="nav_main")]
    ])

CASE_TIERS = {
    "tier1": {
        "name": "📦 Кейс 1",
        "price": 100,
        "pool": [g for g in GIFTS if g.stars <= 8000]
    },
    "tier2": {
        "name": "🔷 Кейс 2",
        "price": 500,
        "pool": [g for g in GIFTS if 200 <= g.stars <= 20000]
    },
    "tier3": {
        "name": "🟣 Кейс 3",
        "price": 2500,
        "pool": [g for g in GIFTS if g.stars >= 500]
    },
    "tier4": {
        "name": "👑 Кейс 4",
        "price": 10000,
        "pool": GIFTS
    }
}

# ---------------------------------------------------------------------------
# ПРОВЕРКА ДОСТУПА (ТЕХРАБОТЫ И БАН)
# ---------------------------------------------------------------------------

async def check_access_allowed(update: Update) -> bool:
    """
    Проверяет:
    1. Включён ли режим техработ (админы обходят блокировку).
    2. Забанен ли пользователь.
    Возвращает True, если доступ разрешён.
    """
    user = update.effective_user
    if not user:
        return True

    if is_maintenance_mode() and user.id not in ADMIN_IDS:
        if update.callback_query:
            await update.callback_query.answer(
                "🛠 Бот сейчас на техработах, подождите немного и попробуйте позже.",
                show_alert=True,
            )
        elif update.effective_message:
            await update.effective_message.reply_text(MAINTENANCE_MESSAGE, parse_mode=ParseMode.HTML)
        return False

    is_banned, until_ts, reason, hours = is_user_banned(user.id)
    if is_banned and user.id not in ADMIN_IDS:
        ban_text, ban_kb = format_ban_message(until_ts, reason, hours)
        if update.callback_query:
            await update.callback_query.answer("⛔️ Ваш аккаунт заблокирован!", show_alert=True)
            if update.callback_query.message:
                await update.callback_query.message.reply_text(ban_text, parse_mode=ParseMode.HTML, reply_markup=ban_kb)
        elif update.effective_message:
            await update.effective_message.reply_text(ban_text, parse_mode=ParseMode.HTML, reply_markup=ban_kb)
        return False

    return True

def build_privacy_terms_text() -> str:
    return (
        "📜 <b>ПОЛИТИКА КОНФИДЕНЦИАЛЬНОСТИ И УСЛОВИЯ ПОЛЬЗОВАНИЯ</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "<b>⚠️ ВАЖНОЕ ПРЕДУПРЕЖДЕНИЕ (ПРОЧТИТЕ ОБЯЗАТЕЛЬНО):</b>\n"
        "<b>ВСЕ ЗВЁЗДЫ (⭐) И NFT-ПОДАРКИ В ЭТОМ БОТЕ — НЕНАСТОЯЩИЕ (ВИРТУАЛЬНЫЕ ИГРОВЫЕ ПРЕДМЕТЫ)!</b>\n"
        "<b>ЭТО ПОЛНОСТЬЮ БЕСПЛАТНАЯ ИГРА БЕЗ ДОНАТОВ, БЕЗ ПОПОЛНЕНИЙ, БЕЗ ВЛОЖЕНИЙ И БЕЗ ВЫВОДА РЕАЛЬНЫХ ДЕНЕГ ИЛИ TELEGRAM STARS!</b>\n"
        "<b>БОТ НИКОГДА НЕ ПРОСИТ ОПЛАТУ, РЕАЛЬНЫЕ ЗВЁЗДЫ, ПАРОЛИ ИЛИ ДОСТУП К ВАШЕМУ АККАУНТУ.</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        "<b>1. Игровой статус валюты и подарков</b>\n"
        "• Внутриигровые звёзды (⭐), рубли/TON на карточках, кейсы и NFT-подарки являются исключительно виртуальной игровой статистикой для развлечения.\n"
        "• Указанная ценность в ₽ и TON носит справочно-игровой характер и не подлежит обмену, покупке или выводу в реальные активы.\n\n"
        "<b>2. Правила игры и честная игра</b>\n"
        "• Выбивайте подарки в группах по слову <code>NFT</code> (раз в час), открывайте <b>Mystery Cases</b>, улучшайте <b>Plush Pepe</b>, объединяйтесь в кланы и торгуйте на P2P Маркете (комиссия площадки 15%).\n"
        "• Переводы звёзд (<code>Передать</code>, <code>/pay</code>, инлайн-чеки <code>@бот сумма</code>) и передача обычных подарков доступны с <b>5-го уровня</b>.\n"
        "• Запрещены мультиаккаунты, накрутка, использование скриптов/ботов, эксплуатация багов и обман других игроков (фейковые сделки, выдача себя за администрацию). Нарушение ведёт к блокировке аккаунта.\n\n"
        "<b>3. Политика конфиденциальности (обработка данных)</b>\n"
        "• Бот сохраняет только публичные данные Telegram (ваш <b>User ID</b>, <code>@username</code>, отображаемое имя) и внутриигровой прогресс (баланс, XP, коллекция, клан, лоты маркета).\n"
        "• Бот не запрашивает и не хранит номера телефонов, личные переписки, пароли 2FA или платёжные реквизиты.\n"
        "• В разделе <b>«⚙️ Настройки»</b> вы можете в любой момент скрыть свой профиль из ТОП-100 и закрыть просмотр коллекции.\n\n"
        "<b>4. Поддержка</b>\n"
        f"• По всем вопросам, багам и апелляциям обращайтесь в поддержку: {SUPPORT_HANDLE}\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Нажимая кнопку ниже, вы подтверждаете, что ознакомились с правилами, понимаете, что <b>звёзды и подарки ненастоящие (игра без донатов)</b>, и принимаете Политику конфиденциальности и Условия пользования."
    )

async def send_privacy_consent_prompt(update_or_query, user_id: int, pending_arg: str = "") -> None:
    cb_data = "accept_privacy"
    if pending_arg and len(pending_arg) <= 44 and re.fullmatch(r"[A-Za-z0-9_]+", pending_arg):
        cb_data = f"accept_privacy:{pending_arg}"

    kb = InlineKeyboardMarkup([
        [make_btn("✅ Принять политику и условия пользования", style="success", callback_data=cb_data)],
    ])
    text = build_privacy_terms_text()

    if isinstance(update_or_query, CallbackQuery):
        if update_or_query.message and update_or_query.message.photo:
            try:
                await update_or_query.message.delete()
            except Exception:
                pass
            await update_or_query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        elif update_or_query.message:
            await update_or_query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        target_msg = update_or_query.effective_message if hasattr(update_or_query, "effective_message") else update_or_query
        if target_msg:
            await target_msg.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def ensure_privacy_accepted_private(update: Update, context: ContextTypes.DEFAULT_TYPE, pending_arg: str = "") -> bool:
    user = update.effective_user
    chat = update.effective_chat
    if not user or not chat or chat.type != "private":
        return True
    get_or_create_user(user.id, user.username or "", user.first_name or "")
    if has_accepted_privacy(user.id):
        return True
    if pending_arg:
        context.user_data["pending_start_arg"] = pending_arg
    if update.callback_query:
        await update.callback_query.answer("📜 Сначала примите Политику конфиденциальности и Условия пользования!", show_alert=False)
        await send_privacy_consent_prompt(update.callback_query, user.id, pending_arg)
    else:
        await send_privacy_consent_prompt(update, user.id, pending_arg)
    return False

# ---------------------------------------------------------------------------
# ПРОФИЛЬ ИГРОКА И ПЛАТНЫЙ ФОН
# ---------------------------------------------------------------------------

async def fetch_user_avatar_bytes(bot, user_id: int) -> Optional[bytes]:
    """Загружает аватарку игрока из Telegram (profile_photos -> get_chat) с дисковым кэшем."""
    cache_path = AVATARS_CACHE_DIR / f"av_{user_id}.jpg"
    try:
        photos = await bot.get_user_profile_photos(user_id, limit=1)
        if photos and photos.total_count > 0 and photos.photos:
            file_id = photos.photos[0][-1].file_id
            tg_file = await bot.get_file(file_id)
            bio = io.BytesIO()
            await tg_file.download_to_memory(bio)
            data = bio.getvalue()
            if data:
                try:
                    cache_path.write_bytes(data)
                except Exception:
                    pass
                return data
    except Exception as e:
        log.debug("get_user_profile_photos(%s): %s", user_id, e)

    try:
        chat = await bot.get_chat(user_id)
        if chat and chat.photo:
            fid = chat.photo.big_file_id or chat.photo.small_file_id
            if fid:
                tg_file = await bot.get_file(fid)
                bio = io.BytesIO()
                await tg_file.download_to_memory(bio)
                data = bio.getvalue()
                if data:
                    try:
                        cache_path.write_bytes(data)
                    except Exception:
                        pass
                    return data
    except Exception as e:
        log.debug("get_chat.photo(%s): %s", user_id, e)

    if cache_path.exists():
        try:
            cached = cache_path.read_bytes()
            if cached:
                return cached
        except Exception:
            pass
    return None

async def show_profile_handler(update_or_query, target_user_id: int, context: ContextTypes.DEFAULT_TYPE, back_to_top_page: Optional[int] = None) -> None:
    viewer_user = (
        update_or_query.effective_user
        if hasattr(update_or_query, "effective_user") and update_or_query.effective_user
        else update_or_query.from_user
    )
    current_viewer_id = viewer_user.id

    if current_viewer_id == target_user_id:
        db_user = get_or_create_user(target_user_id, viewer_user.username or "", viewer_user.first_name or "")
    else:
        db_user = get_or_create_user(target_user_id, "", "")
        if not (db_user["first_name"] or "").strip() and not (db_user["username"] or "").strip():
            try:
                chat_info = await context.bot.get_chat(target_user_id)
                if chat_info and (chat_info.first_name or chat_info.username):
                    db_user = get_or_create_user(
                        target_user_id,
                        chat_info.username or "",
                        chat_info.first_name or "",
                    )
            except Exception:
                pass

    clean_name = normalize_telegram_name(db_user["first_name"], db_user["username"], target_user_id)
    avatar_bytes = await fetch_user_avatar_bytes(context.bot, target_user_id)

    fav_rows = get_favorites(target_user_id)
    rank = get_user_rank(target_user_id)
    lvl, cur_xp, req_xp, _ = calculate_xp_level_info(db_user["xp"])

    clan = get_user_clan(target_user_id)
    clan_tag = clan["tag"] if clan else None

    card_img_io = None
    try:
        card_img_io = await generate_profile_card_image(
            db_user["first_name"] or clean_name,
            db_user["id_num"],
            db_user["balance_stars"],
            db_user["xp"],
            rank,
            fav_rows,
            avatar_bytes=avatar_bytes,
            clan_tag=clan_tag,
            custom_bg_path=db_user["bg_image_path"],
            fallback_username=db_user["username"],
            telegram_user_id=target_user_id,
        )
    except Exception as e:
        log.error("Ошибка при генерации карточки профиля: %s", e)

    clan_display = f"[{clean_html(clan_tag)}] {clean_html(clan['name'])}" if clan else "Отсутствует"
    display_title = f"[{clean_html(clan_tag)}] {clean_html(clean_name)}" if clan_tag else clean_html(clean_name)

    is_self = (current_viewer_id == target_user_id)
    bot_username = await get_bot_username(context.bot)
    profile_link = f"https://t.me/{bot_username}?start=profile_{target_user_id}"
    share_profile_url = (
        f"https://t.me/share/url?url={urllib.parse.quote(profile_link)}"
        f"&text={urllib.parse.quote(f'👤 Профиль игрока {clean_name} в New NFT Bot')}"
    )

    caption = (
        f"👤 <b>Профиль игрока:</b> {display_title}\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🎖 Уровень: <b>{lvl} ({cur_xp:,}/{req_xp:,} XP)</b>\n"
        f"🛡 Клан: <b>{clan_display}</b>\n"
        f"🏆 Место в глобальном ТОПе: <b>#{rank}</b>\n"
        f"💰 Баланс: <b>{fmt_stars_rub(db_user['balance_stars'])}</b>\n"
        f"📦 Вместимость инвентаря: <b>{db_user['max_inventory']} слотов</b>\n"
        f"🎲 Выбито подарков: <b>{db_user['total_drops']}</b> шт.\n"
        f"🛍 Продано предметов: <b>{db_user['total_sold']}</b> шт.\n"
        f"━━━━━━━━━━━━━━━━━━"
    )

    buttons = []
    if is_self:
        has_bg = bool(db_user["bg_image_path"])
        bg_btn_label = f"🖼 Сменить фон ({BG_CHANGE_COST:,}⭐)" if has_bg else f"🖼 Поставить фон ({BG_SET_COST:,}⭐)"
        buttons.append([
            InlineKeyboardButton(bg_btn_label, callback_data="bg_change_start"),
            InlineKeyboardButton("🗂 Коллекция", callback_data="nav_collection_page:1")
        ])
        buttons.append([
            make_btn("✨ Улучшение", style="primary", callback_data="nav_shop"),
            make_btn("🔗 Поделиться профилем", style="primary", url=share_profile_url),
        ])
        if has_bg:
            buttons.append([make_btn("🗑 Сбросить фон на стандартный", style="danger", callback_data="bg_reset")])
        buttons.append([
            InlineKeyboardButton("🎰 Кейсы", callback_data="nav_cases_hub"),
            InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
        ])
    else:
        buttons.append([make_btn("🔗 Поделиться профилем", style="primary", url=share_profile_url)])
        if back_to_top_page:
            buttons.append([InlineKeyboardButton("◀️ Назад в ТОП 100", callback_data=f"nav_top_page:{back_to_top_page}")])
        buttons.append([
            InlineKeyboardButton("🗂 Моя коллекция", callback_data="nav_collection_page:1"),
            InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
        ])

    kb = InlineKeyboardMarkup(buttons)

    if hasattr(update_or_query, "message") and update_or_query.message and update_or_query.message.photo:
        try: await update_or_query.message.delete()
        except Exception: pass

    target_chat_id = (
        update_or_query.effective_chat.id
        if hasattr(update_or_query, "effective_chat") and update_or_query.effective_chat
        else (update_or_query.message.chat.id if hasattr(update_or_query, "message") and update_or_query.message else current_viewer_id)
    )

    if card_img_io:
        try:
            await context.bot.send_photo(
                chat_id=target_chat_id,
                photo=InputFile(card_img_io, filename="profile.png"),
                caption=caption,
                parse_mode=ParseMode.HTML,
                reply_markup=kb
            )
            return
        except Exception as e:
            log.warning("Не удалось отправить фото профиля: %s", e)

    await context.bot.send_message(
        chat_id=target_chat_id,
        text=caption,
        parse_mode=ParseMode.HTML,
        reply_markup=kb
    )

async def bg_change_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END

    query = update.callback_query
    user = query.from_user
    db_user = get_or_create_user(user.id, user.username or "", user.first_name or "")

    has_bg = bool(db_user["bg_image_path"])
    cost = BG_CHANGE_COST if has_bg else BG_SET_COST
    action_label = "смены фона" if has_bg else "установки фона"

    if db_user["balance_stars"] < cost:
        await query.answer(
            f"❌ Недостаточно Stars для {action_label}! Требуется {cost:,} ⭐ (у вас {db_user['balance_stars']:,} ⭐).",
            show_alert=True,
        )
        return ConversationHandler.END

    await query.answer()
    context.user_data["bg_pending_cost"] = cost

    text = (
        f"🖼 <b>{'Смена' if has_bg else 'Установка'} кастомного фона профиля</b>\n\n"
        f"• Стоимость: <b>{cost:,} ⭐</b>\n"
        f"• Ваш баланс: <b>{db_user['balance_stars']:,} ⭐</b>\n\n"
        "Отправьте любое изображение в этот чат (как фото).\n"
        "Оно будет <b>слегка затемнено и размыто</b> на заднем плане вашей карточки, "
        "а звёзды спишутся автоматически после загрузки.\n\n"
        "<i>Для отмены отправьте /cancel или нажмите кнопку ниже.</i>"
    )
    kb = InlineKeyboardMarkup([[make_btn("❌ Отмена", style="danger", callback_data="bg_cancel")]])

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_PROFILE_BG

async def bg_photo_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END

    user = update.effective_user
    if not update.message.photo:
        await update.message.reply_text("❌ Пожалуйста, отправьте именно фото (картинку), либо напишите /cancel.")
        return WAIT_PROFILE_BG

    db_user = get_or_create_user(user.id, user.username or "", user.first_name or "")
    has_bg = bool(db_user["bg_image_path"])
    cost = BG_CHANGE_COST if has_bg else BG_SET_COST

    if not deduct_user_stars(user.id, cost):
        await update.message.reply_text(
            f"❌ Недостаточно Stars на балансе! Требуется <b>{cost:,} ⭐</b>.",
            parse_mode=ParseMode.HTML,
            reply_markup=quick_nav_keyboard(),
        )
        return ConversationHandler.END

    photo_file = await update.message.photo[-1].get_file()
    bg_file_path = BACKGROUNDS_DIR / f"bg_{user.id}.jpg"

    try:
        await photo_file.download_to_drive(custom_path=bg_file_path)
        set_user_background(user.id, str(bg_file_path))

        await update.message.reply_text(
            f"🎉 <b>Фон профиля успешно {'обновлён' if has_bg else 'установлен'}!</b>\n"
            f"С вашего баланса списано <b>{cost:,} ⭐</b>.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("👤 Посмотреть профиль", callback_data="nav_profile")],
                [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
            ])
        )
    except Exception as e:
        add_user_stars(user.id, cost)
        log.error("Ошибка загрузки фона: %s", e)
        await update.message.reply_text("❌ Ошибка при сохранении изображения. Звёзды возвращены на баланс.")

    return ConversationHandler.END

async def bg_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query:
        await query.answer("Отменено.")
        await show_profile_handler(query, query.from_user.id, context)
    else:
        await update.message.reply_text("Отменено.", reply_markup=back_to_main_keyboard())
    return ConversationHandler.END

async def bg_reset_handler(query, user_id: int, context: ContextTypes.DEFAULT_TYPE):
    set_user_background(user_id, None)
    bg_file_path = BACKGROUNDS_DIR / f"bg_{user_id}.jpg"
    if bg_file_path.exists():
        try: bg_file_path.unlink()
        except Exception: pass
    await query.answer("🗑 Фон сброшен на стандартный!", show_alert=True)
    await show_profile_handler(query, user_id, context)

# ---------------------------------------------------------------------------
# ПРОФИЛЬ КЛАНА, КАЗНА, ПОДАРКИ КЛАНА
# ---------------------------------------------------------------------------

async def show_clan_profile_handler(update_or_query, clan_id: int, context: ContextTypes.DEFAULT_TYPE) -> None:
    current_viewer_id = (
        update_or_query.effective_user.id
        if hasattr(update_or_query, "effective_user") and update_or_query.effective_user
        else update_or_query.from_user.id
    )

    clan = get_clan_by_id(clan_id)
    if not clan:
        if hasattr(update_or_query, "answer"):
            await update_or_query.answer("Клан не найден.", show_alert=True)
        return

    awarded_xp = check_and_award_clan_daily_xp(clan_id)
    if awarded_xp:
        clan = get_clan_by_id(clan_id)

    total_treasury, donated_bank, members = get_clan_treasury_and_members(clan_id)
    fav_gifts = get_clan_favorites(clan)
    clan_gifts = get_clan_gifts(clan_id)

    clan_sys_id = clan["id_num"] if clan["id_num"] else clan["id"]
    lvl, cur_xp, req_xp, ratio, drop_bonus = calculate_clan_level_info(clan["xp"])

    is_owner = (clan["owner_id"] == current_viewer_id)
    user_clan = get_user_clan(current_viewer_id)
    is_member = (user_clan and user_clan["id"] == clan["id"])

    owner_user = get_or_create_user(clan["owner_id"], "", "")
    owner_name = normalize_telegram_name(owner_user["first_name"], owner_user["username"], clan["owner_id"])

    clan_card_io = None
    try:
        clan_card_io = await generate_clan_card_image(
            clan["name"],
            clan["tag"],
            clan_sys_id,
            clan["xp"],
            total_treasury,
            len(members),
            clan["max_members"],
            fav_gifts,
            avatar_path=clan["avatar_path"]
        )
    except Exception as e:
        log.error("Ошибка при генерации карточки клана: %s", e)

    ctype_str = "Открытый (свободный вход)" if clan["type"] == "public" else ("Вход за звёзды" if clan["type"] == "stars" else "Закрытый (по заявкам)")
    fee_str = f"\n💰 Стоимость входа: <b>{clan['entry_fee']} ⭐</b>" if clan["type"] == "stars" else ""

    caption = (
        f"🛡 <b>Клан [{clan['tag']}] {clean_html(clan['name'])}</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🎖 Уровень клана: <b>{lvl} ({cur_xp:,}/{req_xp:,} XP)</b>\n"
        f"🎲 Клановый бонус к выигрышу: <b>+{drop_bonus}%</b>\n"
        f"👑 Создатель / Владелец: <b>{clean_html(owner_name)}</b>\n"
        f"👥 Состав: <b>{len(members)}/{clan['max_members']}</b> чел.\n"
        f"💰 <b>Общая казна клана:</b> <b>{fmt_stars_rub(total_treasury)}</b>\n"
        f"🏦 <b>Баланс казны (для покупок):</b> <b>{fmt_stars_compact(donated_bank)} ⭐</b>\n"
        f"🎁 Подарено подарков клану: <b>{len(clan_gifts)}</b> шт.\n"
        f"🔒 Тип входа: <b>{ctype_str}</b>{fee_str}\n"
        f"📝 Описание: <i>{clean_html(clan['description']) or 'Отсутствует'}</i>\n"
        f"━━━━━━━━━━━━━━━━━━"
    )

    buttons = [
        [
            InlineKeyboardButton("👥 Участники и казна", callback_data=f"clan_members_detail:{clan_id}"),
            InlineKeyboardButton(f"🎁 Подарки ({len(clan_gifts)})", callback_data=f"clan_gifts_menu:{clan_id}:1"),
        ],
    ]

    if is_member:
        buttons.append([
            InlineKeyboardButton("💰 Депозит в казну", callback_data=f"clan_donate_stars_start:{clan_id}"),
            InlineKeyboardButton("🎁 Подарить подарок", callback_data=f"clan_donate_gift_menu:{clan_id}:1")
        ])

    if is_owner:
        upgrade_cost = get_clan_upgrade_cost(clan["max_members"])
        buttons.append([
            InlineKeyboardButton("🖼 Сменить герб клана", callback_data=f"clan_avatar_start:{clan_id}"),
            InlineKeyboardButton("⭐ Избранное клана", callback_data=f"clan_gifts_menu:{clan_id}:1")
        ])
        buttons.append([
            InlineKeyboardButton(f"⬆️ +15 мест ({upgrade_cost:,}⭐)", callback_data=f"clan_upgrade:{clan_id}"),
            InlineKeyboardButton("📩 Заявки в клан", callback_data=f"clan_requests:{clan_id}")
        ])
        buttons.append([InlineKeyboardButton("🔥 Расформировать клан", callback_data=f"clan_delete_confirm:{clan_id}")])
    elif is_member:
        buttons.append([InlineKeyboardButton("🚪 Покинуть клан", callback_data="clan_leave:1")])
    elif not user_clan and len(members) < clan["max_members"]:
        if clan["type"] == "public":
            buttons.append([InlineKeyboardButton("🚪 Вступить в клан", callback_data=f"clan_join:{clan_id}")])
        elif clan["type"] == "stars":
            buttons.append([InlineKeyboardButton(f"⭐ Войти за {clan['entry_fee']} Stars", callback_data=f"clan_join_stars:{clan_id}")])
        elif clan["type"] == "private":
            buttons.append([InlineKeyboardButton("📩 Подать заявку в клан", callback_data=f"clan_apply:{clan_id}")])

    buttons.append([
        InlineKeyboardButton("📋 Список кланов", callback_data="clan_list:1"),
        InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
    ])

    kb = InlineKeyboardMarkup(buttons)

    if hasattr(update_or_query, "message") and update_or_query.message and update_or_query.message.photo:
        try: await update_or_query.message.delete()
        except Exception: pass

    if clan_card_io:
        try:
            await context.bot.send_photo(
                chat_id=current_viewer_id,
                photo=InputFile(clan_card_io, filename="clan.png"),
                caption=caption,
                parse_mode=ParseMode.HTML,
                reply_markup=kb
            )
            return
        except Exception as e:
            log.warning("Не удалось отправить фото карточки клана: %s", e)

    await context.bot.send_message(
        chat_id=current_viewer_id,
        text=caption,
        parse_mode=ParseMode.HTML,
        reply_markup=kb
    )

async def show_clan_members_detail(query, clan_id: int):
    clan = get_clan_by_id(clan_id)
    if not clan:
        await query.answer("Клан не найден.")
        return

    total_treasury, donated_bank, members = get_clan_treasury_and_members(clan_id)

    lines = [
        f"👥 <b>Участники и казна клана [{clan['tag']}] {clean_html(clan['name'])}</b>",
        "━━━━━━━━━━━━━━━━━━",
        f"💰 <b>Общая казна клана:</b> <b>{fmt_stars_compact(total_treasury)} ⭐</b>",
        f"🏦 <b>Баланс казны (доступно для покупок):</b> <b>{fmt_stars_compact(donated_bank)} ⭐</b>",
        f"👥 <b>Всего участников:</b> <b>{len(members)}/{clan['max_members']}</b>",
        "━━━━━━━━━━━━━━━━━━",
        "<b>Баланс каждого участника:</b>\n"
    ]

    for idx, m in enumerate(members, start=1):
        is_owner = (m["user_id"] == clan["owner_id"])
        role_badge = "👑 Создатель" if is_owner else "Участник"
        mname = normalize_telegram_name(m["first_name"], m["username"], m["user_id"])
        lines.append(f"{idx}. <b>{clean_html(mname)}</b> ({role_badge}) — <b>{fmt_stars_compact(m['balance_stars'])} ⭐</b>")

    lines.append("\n━━━━━━━━━━━━━━━━━━")
    text = "\n".join(lines)

    buttons = []
    if clan["owner_id"] == query.from_user.id:
        for m in members:
            if m["user_id"] != clan["owner_id"]:
                mname = normalize_telegram_name(m["first_name"], m["username"], m["user_id"])
                buttons.append([make_btn(f"❌ Исключить {mname[:10]}", style="danger", callback_data=f"clan_kick:{m['user_id']}")])

    buttons.append([InlineKeyboardButton("⬅️ Назад в профиль клана", callback_data=f"clan_info:{clan_id}")])
    buttons.append([InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")])

    kb = InlineKeyboardMarkup(buttons)
    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

# --- ПОДАРКИ КЛАНА И ИЗБРАННОЕ ---

async def show_clan_gifts_menu(query, clan_id: int, page: int = 1):
    clan = get_clan_by_id(clan_id)
    if not clan:
        await query.answer("Клан не найден.", show_alert=True)
        return

    gifts = get_clan_gifts(clan_id)
    is_owner = (clan["owner_id"] == query.from_user.id)
    user_clan = get_user_clan(query.from_user.id)
    is_member = bool(user_clan and user_clan["id"] == clan_id)

    fav_count = sum(1 for row in gifts if row["is_favorite"])

    if not gifts:
        text = (
            f"🎁 <b>Подарки клана [{clan['tag']}] {clean_html(clan['name'])}</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"В клане пока нет подаренных подарков.\n\n"
            f"<i>Участники клана могут нажать «🎁 Подарить подарок», выбрать предмет из своей коллекции и передать его клану! Покупать подарки здесь нельзя.</i>"
        )
        buttons = []
        if is_member:
            buttons.append([InlineKeyboardButton("🎁 Подарить подарок из коллекции", callback_data=f"clan_donate_gift_menu:{clan_id}:1")])
        buttons.append([InlineKeyboardButton("⬅️ В профиль клана", callback_data=f"clan_info:{clan_id}")])
        kb = InlineKeyboardMarkup(buttons)

        if query.message.photo:
            await query.message.delete()
            await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    page_size = 8
    total_pages = max(1, math.ceil(len(gifts) / page_size))
    page = max(1, min(page, total_pages))
    page_items = gifts[(page - 1) * page_size : page * page_size]

    lines = [
        f"🎁 <b>Подарки клана [{clan['tag']}] {clean_html(clan['name'])}</b>",
        f"━━━━━━━━━━━━━━━━━━",
        f"Всего подарков: <b>{len(gifts)}</b> | В избранном: <b>{fav_count}/7</b>\n",
    ]
    if is_owner:
        lines.append("<i>Нажмите на подарок ниже, чтобы закрепить его в Избранное клана (до 7 слотов) или убрать оттуда:</i>\n")
    else:
        lines.append("<i>Список подарков, подаренных участниками клана:</i>\n")

    buttons = []
    for cg in page_items:
        g = GIFTS_BY_KEY.get(cg["gift_key"])
        if not g:
            continue
        donor_name = normalize_telegram_name(cg["first_name"], cg["username"], cg["donor_user_id"])
        fav_icon = "⭐ " if cg["is_favorite"] else "🎁 "
        lines.append(f"{fav_icon}<b>{g.name}</b> — от <b>{clean_html(donor_name)}</b>")
        if is_owner:
            action_lbl = "Убрать из ⭐" if cg["is_favorite"] else "В избранное ⭐"
            buttons.append([
                InlineKeyboardButton(f"{fav_icon}{g.name[:22]} • {action_lbl}", callback_data=f"clan_toggle_gift_fav:{clan_id}:{cg['id']}:{page}")
            ])

    nav_row = []
    if page > 1:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"clan_gifts_menu:{clan_id}:{page-1}"))
    if total_pages > 1:
        nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"clan_gifts_menu:{clan_id}:{page+1}"))
    if nav_row:
        buttons.append(nav_row)

    if is_member:
        buttons.append([InlineKeyboardButton("🎁 Подарить подарок клану", callback_data=f"clan_donate_gift_menu:{clan_id}:1")])
    buttons.append([InlineKeyboardButton("⬅️ В профиль клана", callback_data=f"clan_info:{clan_id}")])
    buttons.append([InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")])

    text = "\n".join(lines)
    kb = InlineKeyboardMarkup(buttons)

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_clan_donate_gift_menu(query, clan_id: int, user_id: int, page: int = 1):
    user_clan = get_user_clan(user_id)
    if not user_clan or user_clan["id"] != clan_id:
        await query.answer("❌ Вы не состоите в этом клане!", show_alert=True)
        return

    items = [it for it in get_user_collection(user_id) if not it["is_listed"]]
    if not items:
        await query.answer("У вас нет доступных предметов в коллекции для подарка клану!", show_alert=True)
        return

    page_size = 8
    total_pages = max(1, math.ceil(len(items) / page_size))
    page = max(1, min(page, total_pages))
    page_items = items[(page - 1) * page_size : page * page_size]

    text = (
        f"🎁 <b>Подарить подарок клану (Стр. {page}/{total_pages})</b>\n\n"
        "Выберите подарок из вашей коллекции.\n"
        "После подтверждения он перейдёт в собственность клана и принесёт клану XP:"
    )

    buttons = []
    for item in page_items:
        g = GIFTS_BY_KEY.get(item["gift_key"])
        if not g:
            continue
        val_stars = get_item_display_value(item)
        lbl = f"✨ Pepe [{item['model_name']}]" if item["is_upgraded"] and item["model_name"] else g.name[:24]
        buttons.append([
            InlineKeyboardButton(
                f"🎁 {lbl} ({fmt_stars_compact(val_stars)}⭐)",
                callback_data=f"clan_donate_gift_confirm:{clan_id}:{item['id']}"
            )
        ])

    nav_row = []
    if page > 1:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"clan_donate_gift_menu:{clan_id}:{page-1}"))
    if total_pages > 1:
        nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"clan_donate_gift_menu:{clan_id}:{page+1}"))
    if nav_row:
        buttons.append(nav_row)

    buttons.append([InlineKeyboardButton("⬅️ В профиль клана", callback_data=f"clan_info:{clan_id}")])
    kb = InlineKeyboardMarkup(buttons)

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_clan_donate_gift_confirm(query, clan_id: int, item_id: int, user_id: int):
    clan = get_clan_by_id(clan_id)
    user_clan = get_user_clan(user_id)
    if not clan or not user_clan or user_clan["id"] != clan_id:
        await query.answer("❌ Вы не состоите в этом клане!", show_alert=True)
        return

    item = get_collection_item(item_id)
    if not item or item["user_id"] != user_id:
        await query.answer("❌ Предмет не найден в вашей коллекции!", show_alert=True)
        return
    if item["is_listed"]:
        await query.answer("❌ Сначала снимите подарок с маркета!", show_alert=True)
        return

    g = GIFTS_BY_KEY.get(item["gift_key"])
    if not g:
        await query.answer("❌ Ошибка предмета.", show_alert=True)
        return

    val_stars = get_item_display_value(item)
    xp_earned = max(1, int(val_stars * 0.0008))
    disp_name = f"Plush Pepe #{item['upgrade_num']} ({item['model_name']})" if item["is_upgraded"] else g.name
    text = (
        "🎁 <b>Подтверждение подарка клану</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"Клан: <b>[{clan['tag']}] {clean_html(clan['name'])}</b>\n"
        f"Подарок: <b>{clean_html(disp_name)}</b>\n"
        f"Ценность: <b>{fmt_stars_rub(val_stars)}</b>\n"
        f"Бонус опыта клану: <b>+{xp_earned:,} XP</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "⚠️ Предмет будет удалён из вашей коллекции и появится в разделе подарков клана.\n"
        "Подтвердить передачу?"
    )
    kb = InlineKeyboardMarkup([
        [make_btn("✅ Подтвердить подарок", style="success", callback_data=f"clan_donate_gift_do:{clan_id}:{item_id}")],
        [make_btn("❌ Отмена", style="danger", callback_data=f"clan_donate_gift_menu:{clan_id}:1")],
    ])
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def execute_clan_donate_gift(query, clan_id: int, item_id: int, user_id: int, context: ContextTypes.DEFAULT_TYPE):
    user_clan = get_user_clan(user_id)
    if not user_clan or user_clan["id"] != clan_id:
        await query.answer("❌ Вы не состоите в этом клане!", show_alert=True)
        return

    ok, gift_name, xp_earned = donate_gift_to_clan_db(user_id, clan_id, item_id)
    if not ok:
        await query.answer(f"❌ {gift_name}", show_alert=True)
        return

    await query.answer(f"🎉 Подарок {gift_name} подарен клану! (+{xp_earned} XP)", show_alert=True)
    await show_clan_gifts_menu(query, clan_id, 1)

# ---------------------------------------------------------------------------
# АВАТАРКА КЛАНА (FSM)
# ---------------------------------------------------------------------------

async def clan_avatar_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END

    query = update.callback_query
    clan_id = int(query.data.split(":")[1])
    clan = get_clan_by_id(clan_id)

    if not clan or clan["owner_id"] != query.from_user.id:
        await query.answer("❌ Только создатель клана может менять герб!", show_alert=True)
        return ConversationHandler.END

    await query.answer()
    context.user_data["clan_avatar_clan_id"] = clan_id

    text = (
        "🖼 <b>Установка герба (аватарки) клана</b>\n\n"
        "Выберите одну из готовых крутых аватарок кнопками ниже\n"
        "или <b>отправьте свою фотографию</b> прямо в этот чат!\n\n"
        "Отправьте /cancel для отмены."
    )
    preset_rows = []
    for idx in range(0, len(CLAN_PRESET_AVATARS), 2):
        row = []
        for p_key, p_title, _ in CLAN_PRESET_AVATARS[idx:idx + 2]:
            row.append(InlineKeyboardButton(p_title, callback_data=f"clan_avatar_preset:{clan_id}:{p_key}"))
        preset_rows.append(row)
    preset_rows.append([InlineKeyboardButton("❌ Отмена", callback_data="clan_avatar_cancel")])
    kb = InlineKeyboardMarkup(preset_rows)

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_CLAN_AVATAR


async def clan_avatar_preset_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END

    query = update.callback_query
    parts = query.data.split(":")
    if len(parts) < 3 or not parts[1].isdigit():
        await query.answer("❌ Некорректный выбор.", show_alert=True)
        return ConversationHandler.END

    clan_id = int(parts[1])
    preset_key = parts[2]
    clan = get_clan_by_id(clan_id)
    if not clan or clan["owner_id"] != query.from_user.id:
        await query.answer("❌ Только создатель клана может менять герб!", show_alert=True)
        return ConversationHandler.END

    rendered = render_clan_preset_avatar(preset_key, size=512)
    if rendered is None:
        await query.answer("❌ Пресет не найден.", show_alert=True)
        return WAIT_CLAN_AVATAR

    av_path = CLAN_AVATARS_DIR / f"clan_{clan_id}.jpg"
    try:
        rendered.convert("RGB").save(av_path, "JPEG", quality=94)
        set_clan_avatar(clan_id, str(av_path))
        await query.answer("✅ Новый герб клана установлен!")
        await show_clan_profile_handler(query, clan_id, context)
    except Exception as e:
        log.error("Ошибка установки пресета герба клана: %s", e)
        await query.answer("❌ Ошибка при сохранении герба.", show_alert=True)

    return ConversationHandler.END

async def clan_avatar_photo_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END

    if not update.message.photo:
        await update.message.reply_text("❌ Пожалуйста, отправьте именно фото или /cancel.")
        return WAIT_CLAN_AVATAR

    clan_id = context.user_data.get("clan_avatar_clan_id")
    if not clan_id:
        await update.message.reply_text("Ошибка сессии.")
        return ConversationHandler.END

    photo_file = await update.message.photo[-1].get_file()
    av_path = CLAN_AVATARS_DIR / f"clan_{clan_id}.jpg"

    try:
        await photo_file.download_to_drive(custom_path=av_path)
        set_clan_avatar(clan_id, str(av_path))

        await update.message.reply_text(
            "🎉 <b>Герб клана успешно установлен!</b>",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🛡 В профиль клана", callback_data=f"clan_info:{clan_id}")],
                [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
            ])
        )
    except Exception as e:
        log.error("Ошибка сохранения герба клана: %s", e)
        await update.message.reply_text("❌ Ошибка при сохранении герба. Попробуйте еще раз.")

    return ConversationHandler.END

async def clan_avatar_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query:
        await query.answer("Отменено.")
        clan_id = context.user_data.get("clan_avatar_clan_id")
        if clan_id:
            await show_clan_profile_handler(query, clan_id, context)
    else:
        await update.message.reply_text("Отменено.")
    return ConversationHandler.END

# ---------------------------------------------------------------------------
# ПОПОЛНЕНИЕ БАЛАНСА КАЗНЫ КЛАНА ЗВЁЗДАМИ (FSM)
# ---------------------------------------------------------------------------

async def clan_donate_stars_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END

    query = update.callback_query
    clan_id = int(query.data.split(":")[1])
    await query.answer()

    context.user_data["donate_clan_id"] = clan_id
    text = (
        "💰 <b>Депозит в баланс казны клана</b>\n\n"
        "Внесённые Stars попадают в <b>Баланс казны</b> (на них клан может покупать улучшения) "
        "и приносят клану опыт (~800 XP за 1,000,000 ⭐).\n"
        "<i>Общая казна клана при этом не уменьшается!</i>\n\n"
        "Введите количество Stars (⭐) для внесения в баланс казны:"
    )
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="clan_donate_cancel")]])

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_CLAN_DONATE_STARS

async def clan_donate_stars_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END

    text = update.message.text.strip()
    if not text.isdigit() or int(text) <= 0:
        await update.message.reply_text("❌ Введите положительное число звёзд:")
        return WAIT_CLAN_DONATE_STARS

    amount = int(text)
    clan_id = context.user_data.get("donate_clan_id")
    user = update.effective_user

    success, xp_awarded = donate_stars_to_clan(user.id, clan_id, amount)
    if not success:
        await update.message.reply_text("❌ У вас недостаточно Stars на балансе!")
        return ConversationHandler.END

    clan = get_clan_by_id(clan_id)
    total_treasury, donated_bank, _ = get_clan_treasury_and_members(clan_id)
    lvl, cur_xp, req_xp, _, bonus = calculate_clan_level_info(clan["xp"])

    await update.message.reply_text(
        f"🎉 <b>Вы внесли {amount:,} ⭐ в баланс казны клана!</b>\n\n"
        f"• Общая казна клана: <b>{total_treasury:,} ⭐</b>\n"
        f"• Баланс казны (для покупок): <b>{donated_bank:,} ⭐</b>\n"
        f"• Клан получил: <b>+{xp_awarded:,} XP</b>\n"
        f"• Уровень клана: <b>{lvl}</b> ({cur_xp:,}/{req_xp:,} XP, +{bonus}% к победе)",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🛡 В профиль клана", callback_data=f"clan_info:{clan_id}")],
            [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
        ])
    )
    return ConversationHandler.END

async def clan_donate_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query:
        await query.answer("Отменено.")
        clan_id = context.user_data.get("donate_clan_id")
        if clan_id:
            await show_clan_profile_handler(query, clan_id, context)
    else:
        await update.message.reply_text("Отменено.")
    return ConversationHandler.END

# ---------------------------------------------------------------------------
# РАЗДЕЛ "ИНФО"
# ---------------------------------------------------------------------------

async def show_info_page(query_or_update, context: ContextTypes.DEFAULT_TYPE) -> None:
    bot_info = await context.bot.get_me()
    bot_user = bot_info.username or "Bot"
    add_group_url = f"https://t.me/{bot_user}?startgroup=true"

    text = (
        "ℹ️ <b>Справочный центр New NFT Bot</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Добро пожаловать в официальную информационную панель бота!\n\n"
        "📌 <b>Основные возможности:</b>\n"
        "• Выбивание редких Telegram Gifts в любых чатах\n"
        "• Передача звёзд и подарков прямо в чате командой <code>Передать</code>\n"
        "• Торговый NFT Marketplace и Mystery Cases\n"
        "• Кланы с геральдическими гербами, уровнями, казной и подарками\n"
        "• Персонализация профилей с кастомными фонами\n"
        f"• Служба поддержки: {SUPPORT_HANDLE}\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Выберите интересующий подраздел:"
    )

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🤖 Подключение бота к группе и права", callback_data="info_group_guide")],
        [InlineKeyboardButton("📜 Политика конфиденциальности", callback_data="info_privacy")],
        [InlineKeyboardButton("📖 Правила игры и клановые бонусы", callback_data="info_rules")],
        [InlineKeyboardButton("💬 Написать в поддержку", url=SUPPORT_URL)],
        [InlineKeyboardButton("➕ Добавить бота в группу", url=add_group_url)],
        [InlineKeyboardButton("⬅️ Главное меню", callback_data="nav_main")],
    ])

    if isinstance(query_or_update, CallbackQuery):
        if query_or_update.message and query_or_update.message.photo:
            await query_or_update.message.delete()
            await query_or_update.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        elif query_or_update.message:
            await query_or_update.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        target_msg = query_or_update.effective_message if hasattr(query_or_update, "effective_message") else query_or_update
        if target_msg:
            await target_msg.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_group_guide(query, context: ContextTypes.DEFAULT_TYPE) -> None:
    bot_info = await context.bot.get_me()
    bot_user = bot_info.username or "Bot"
    add_group_url = f"https://t.me/{bot_user}?startgroup=true"

    text = (
        "🤖 <b>Подключение бота к вашей группе</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "1️⃣ Нажмите кнопку <b>«➕ Добавить в группу»</b> ниже.\n"
        "2️⃣ Выберите нужный чат и выдайте права на чтение и отправку сообщений/фото.\n"
        "3️⃣ В чате доступны команды: <code>NFT</code>, <code>Профиль</code>, <code>Передать</code>!"
    )

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Добавить бота в группу", url=add_group_url)],
        [InlineKeyboardButton("⬅️ Назад в Инфо", callback_data="nav_info")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
    ])
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_privacy_policy(query) -> None:
    text = build_privacy_terms_text()
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅️ Назад в Инфо", callback_data="nav_info")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
    ])
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_rules_page(query) -> None:
    text = (
        "📖 <b>Правила игры и команды</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "• <b>Дроп в чатах:</b> Напишите <code>NFT</code> (раз в 1 час). Шанс дропа — <b>90%</b>.\n"
        "• <b>Передача звёзд:</b> <code>Передать 1000</code> (ответом на сообщение) или <code>Передать 1000 @user</code>. Требуется <b>5+ уровень</b> и сумма от <b>1,000 ⭐</b>.\n"
        "• <b>Инлайн-чеки:</b> Введите в любом чате <code>@имя_бота 5000</code> или <code>@имя_бота 5000 @user</code> (от <b>1,000 ⭐</b>).\n"
        "• <b>Передача подарков:</b> <code>Передать подарок</code> (ответом на сообщение или с <code>@user</code>/ID). Требуется <b>5+ уровень</b>.\n"
        f"• <b>Поддержка:</b> {SUPPORT_HANDLE}"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅️ Назад в Инфо", callback_data="nav_info")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
    ])
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

# ---------------------------------------------------------------------------
# РАЗДЕЛ "NFT МАРКЕТ" (P2P ТОРГОВЛЯ УЛУЧШЕННЫМИ PLUSH PEPE, КОМИССИЯ 15%)
# ---------------------------------------------------------------------------

async def show_market_hub(update_or_query) -> None:
    banner_io = await generate_market_banner()
    _, _, active_total = get_market_listings("all", "all", page=1, page_size=1)

    caption = (
        "🛒 <b>NFT Marketplace (P2P Биржа)</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Официальная торговая площадка улучшенных NFT Plush Pepe между игроками.\n\n"
        f"• Активных лотов сейчас: <b>{active_total}</b>\n"
        f"• Комиссия маркета при продаже: <b>{int(MARKET_FEE_RATE * 100)}%</b>\n"
        f"• Диапазон цен: <b>{MARKET_MIN_PRICE:,} — {MARKET_MAX_PRICE:,} ⭐</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Выставляйте свои улучшенные подарки или ищите редкие модели и фоны:"
    )

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Продать улучшенный NFT", callback_data="market_create_offer")],
        [InlineKeyboardButton(f"📋 Все лоты ({active_total})", callback_data="market_view:all:all:1")],
        [
            InlineKeyboardButton("💰 По стоимости", callback_data="market_filter_price_menu"),
            InlineKeyboardButton("🎨 По редкости фона", callback_data="market_filter_rarity_menu"),
        ],
        [InlineKeyboardButton("🐸 Фильтр: Модели Plush Pepe (50)", callback_data="market_filter_model_menu:1")],
        [
            InlineKeyboardButton("🔍 Мои лоты", callback_data="market_my_offers"),
            InlineKeyboardButton("📊 История сделок", callback_data="market_history"),
        ],
        [
            InlineKeyboardButton("🗂 Моя коллекция", callback_data="nav_collection_page:1"),
            InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main"),
        ]
    ])

    if isinstance(update_or_query, CallbackQuery):
        if update_or_query.message and update_or_query.message.photo:
            try: await update_or_query.message.delete()
            except Exception: pass
        if update_or_query.message:
            await update_or_query.message.reply_photo(
                photo=InputFile(banner_io, filename="market.png"),
                caption=caption,
                parse_mode=ParseMode.HTML,
                reply_markup=kb
            )
    else:
        target_msg = update_or_query.effective_message if hasattr(update_or_query, "effective_message") else update_or_query
        if target_msg:
            if getattr(target_msg, "photo", None):
                try: await target_msg.delete()
                except Exception: pass
            await target_msg.reply_photo(
                photo=InputFile(banner_io, filename="market.png"),
                caption=caption,
                parse_mode=ParseMode.HTML,
                reply_markup=kb
            )

async def show_market_filter_price_menu(query):
    text = (
        "💰 <b>Фильтр маркета по стоимости:</b>\n"
        "Выберите интересующий ценовой диапазон:"
    )
    buttons = []
    for pkey, (ptitle, _, _) in MARKET_PRICE_TIERS.items():
        buttons.append([InlineKeyboardButton(ptitle, callback_data=f"market_view:price:{pkey}:1")])
    buttons.append([InlineKeyboardButton("⬅️ Назад в маркет", callback_data="nav_market")])
    kb = InlineKeyboardMarkup(buttons)

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_market_filter_rarity_menu(query):
    text = (
        "🎨 <b>Фильтр по редкости фона:</b>\n"
        "Самые редкие и дорогие — <b>Мифический Rainbow (0.05%, x100)</b> и <b>Ультра-редкие</b> (чёрные, серые, золото)."
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🌈 Мифический (Rainbow 0.05% • x100)", callback_data="market_view:rarity:Мифический:1")],
        [InlineKeyboardButton("👑 Ультра-редкий (0.15%–0.50%)", callback_data="market_view:rarity:Ультра-редкий:1")],
        [InlineKeyboardButton("💎 Редкий (0.60%–1.15%)", callback_data="market_view:rarity:Редкий:1")],
        [InlineKeyboardButton("🟣 Необычный (1.25%–1.85%)", callback_data="market_view:rarity:Необычный:1")],
        [InlineKeyboardButton("🟢 Обычный яркий (2.15%–2.80%)", callback_data="market_view:rarity:Обычный:1")],
        [InlineKeyboardButton("⬅️ Назад в маркет", callback_data="nav_market")],
    ])
    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_market_filter_model_menu(query, page: int = 1):
    """Список всех 50 моделей Plush Pepe для фильтрации лотов на маркете."""
    page_size = 10
    total_pages = max(1, math.ceil(len(PLUSHPEPE_MODELS) / page_size))
    page = max(1, min(page, total_pages))
    page_models = PLUSHPEPE_MODELS[(page - 1) * page_size : page * page_size]

    text = (
        f"🐸 <b>Модели Plush Pepe на маркете (Стр. {page}/{total_pages})</b>\n"
        "Выберите модель для поиска активных лотов:"
    )
    buttons = []
    for m in page_models:
        buttons.append([
            InlineKeyboardButton(f"🐸 {m.name} (шанс {m.chance_pct}%)", callback_data=f"market_view:model:{m.name}:1")
        ])

    nav_row = []
    if page > 1:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"market_filter_model_menu:{page-1}"))
    nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"market_filter_model_menu:{page+1}"))
    buttons.append(nav_row)

    buttons.append([InlineKeyboardButton("⬅️ Назад в маркет", callback_data="nav_market")])
    kb = InlineKeyboardMarkup(buttons)

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_market_view_page(query, ftype: str, fkey: str, page: int = 1):
    lots, total_pages, total_count = get_market_listings(ftype, fkey, page=page, page_size=8)
    if ftype == "price":
        filter_name = MARKET_PRICE_TIERS.get(fkey, ("По цене", 0, 0))[0]
    elif ftype == "model":
        filter_name = f"Модель: {fkey}"
    elif ftype == "rarity":
        filter_name = f"Редкость фона: {fkey}"
    else:
        filter_name = "Все активные лоты"

    buttons = []
    lines = [
        f"📋 <b>Маркет: {clean_html(filter_name)}</b> (Стр. {page}/{total_pages})",
        "━━━━━━━━━━━━━━━━━━",
        f"Найдено лотов: <b>{total_count}</b>\n",
    ]

    if not lots:
        lines.append("<i>Активных лотов по выбранному фильтру пока нет.</i>")
    else:
        lines.append("<i>Нажмите на лот ниже, чтобы посмотреть карточку NFT и купить:</i>")
        for lot in lots:
            bg_def = BACKDROPS_BY_KEY.get(lot["backdrop_key"])
            bg_name = bg_def.name if bg_def else lot["backdrop_key"]
            btn_lbl = f"🐸 #{lot['upgrade_num']} {lot['model_name']} • {bg_name} — {fmt_stars_compact(lot['price_stars'])}⭐"
            buttons.append([InlineKeyboardButton(btn_lbl[:60], callback_data=f"market_lot:{lot['id']}")])

    if total_pages > 1:
        nav_row = []
        if page > 1:
            nav_row.append(InlineKeyboardButton("◀️", callback_data=f"market_view:{ftype}:{fkey}:{page-1}"))
        nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
        if page < total_pages:
            nav_row.append(InlineKeyboardButton("▶️", callback_data=f"market_view:{ftype}:{fkey}:{page+1}"))
        buttons.append(nav_row)

    buttons.append([make_btn("➕ Продать улучшенный NFT", style="primary", callback_data="market_create_offer")])
    buttons.append([
        InlineKeyboardButton("💰 По цене", callback_data="market_filter_price_menu"),
        InlineKeyboardButton("🎨 По фону", callback_data="market_filter_rarity_menu"),
    ])
    buttons.append([InlineKeyboardButton("⬅️ В витрину маркета", callback_data="nav_market")])
    buttons.append([InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")])

    text = "\n".join(lines)
    kb = InlineKeyboardMarkup(buttons)

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_market_lot_detail(update_or_query, listing_id: int, viewer_id: int, context: Optional[ContextTypes.DEFAULT_TYPE] = None):
    lot = get_market_listing_by_id(listing_id)
    is_callback = hasattr(update_or_query, "answer") and hasattr(update_or_query, "from_user")
    msg_obj = update_or_query.message if is_callback else update_or_query.effective_message

    if not lot or lot["status"] != "active":
        if is_callback:
            await update_or_query.answer("❌ Этот лот уже продан или снят с продажи.", show_alert=True)
            await show_market_view_page(update_or_query, "all", "all", 1)
        elif msg_obj:
            await msg_obj.reply_text(
                "❌ Этот лот уже продан или снят с продажи.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🛒 В маркет", callback_data="nav_market")]]),
            )
        return

    model = PLUSHPEPE_MODELS_BY_NAME.get(lot["model_name"]) or PLUSHPEPE_MODELS[0]
    backdrop = BACKDROPS_BY_KEY.get(lot["backdrop_key"]) or PLUSHPEPE_BACKDROPS[0]
    seller_name = normalize_telegram_name(lot["seller_name"], lot["seller_username"], lot["seller_id"])
    is_mono, mono_fam = get_monochrome_combo_info(model.name, backdrop.key)

    card_io = await generate_upgraded_gift_image(
        model,
        backdrop,
        lot["upgrade_num"],
        lot["upgraded_stars"],
        list_price=lot["price_stars"],
    )

    bot_obj = context.bot if context else (update_or_query.get_bot() if hasattr(update_or_query, "get_bot") else None)
    bot_username = await get_bot_username(bot_obj) if bot_obj else (_BOT_USERNAME_CACHE or "bot")
    lot_link = f"https://t.me/{bot_username}?start=lot_{lot['id']}"
    lot_num_val = lot["upgrade_num"]
    lot_price_txt = fmt_stars_compact(lot["price_stars"])
    share_text = f"🐸 Plush Pepe #{lot_num_val} ({model.name} • {backdrop.name}) за {lot_price_txt} ⭐ на маркете!"
    share_url = (
        f"https://t.me/share/url?url={urllib.parse.quote(lot_link)}"
        f"&text={urllib.parse.quote(share_text)}"
    )

    is_owner = (lot["seller_id"] == viewer_id)
    mono_line = f"\n🌈 Комбо: <b>MONOCHROME x6</b> ({COLOR_FAMILY_RU.get(mono_fam, mono_fam)})" if is_mono else ""
    cap = (
        f"🛒 <b>Лот #{lot['id']} • Plush Pepe #{lot['upgrade_num']}</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🐸 Модель: <b>{clean_html(model.name)}</b> (шанс {model.chance_pct}%)\n"
        f"🎨 Фон: <b>{clean_html(backdrop.name)}</b> • <i>{backdrop.rarity_label}</i> ({backdrop.chance_pct}%){mono_line}\n"
        f"💎 Оценочная стоимость: <b>{fmt_stars_rub(lot['upgraded_stars'])}</b>\n"
        f"👤 Продавец: <b>{clean_html(seller_name)}</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"💳 Цена покупки: <b>{fmt_stars_rub(lot['price_stars'])}</b>"
    )

    buttons = []
    if is_owner:
        buttons.append([make_btn("❌ Снять лот с продажи", style="danger", callback_data=f"market_cancel_lot:{lot['id']}")])
    else:
        buttons.append([make_btn(f"💳 Купить за {fmt_stars_compact(lot['price_stars'])} ⭐", style="success", callback_data=f"market_buy:{lot['id']}")])
    buttons.append([make_btn("🔗 Поделиться подарком", style="primary", url=share_url)])
    buttons.append([
        InlineKeyboardButton("📋 Все лоты", callback_data="market_view:all:all:1"),
        InlineKeyboardButton("🛒 В маркет", callback_data="nav_market"),
    ])
    kb = InlineKeyboardMarkup(buttons)

    if is_callback and msg_obj:
        try: await msg_obj.delete()
        except Exception: pass

    await msg_obj.reply_photo(
        photo=InputFile(card_io, filename=f"lot_{lot['id']}.png"),
        caption=cap,
        parse_mode=ParseMode.HTML,
        reply_markup=kb,
    )

async def show_market_create_offer_list(query, user_id: int, page: int = 1):
    items = [it for it in get_user_collection(user_id) if it["is_upgraded"] and not it["is_listed"]]
    if not items:
        text = (
            "➕ <b>Выставить NFT на маркет</b>\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "У вас пока нет доступных <b>улучшенных</b> подарков для продажи.\n\n"
            "Сначала улучшите обычный <b>Plush Pepe</b> в разделе «🛍 Улучшения» за <b>150,000 ⭐</b>!"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("✨ Перейти к улучшениям", callback_data="nav_shop")],
            [InlineKeyboardButton("⬅️ Назад в маркет", callback_data="nav_market")],
        ])
        if query.message.photo:
            await query.message.delete()
            await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    page_size = 8
    total_pages = max(1, math.ceil(len(items) / page_size))
    page = max(1, min(page, total_pages))
    page_items = items[(page - 1) * page_size : page * page_size]

    buttons = []
    for it in page_items:
        bg = BACKDROPS_BY_KEY.get(it["backdrop_key"])
        bg_name = bg.name if bg else (it["backdrop_key"] or "")
        buttons.append([
            InlineKeyboardButton(
                f"✨ #{it['upgrade_num']} {it['model_name']} ({bg_name}) • ~{fmt_stars_compact(it['upgraded_stars'])}⭐",
                callback_data=f"market_sell_start:{it['id']}"
            )
        ])

    if total_pages > 1:
        nav_row = []
        if page > 1:
            nav_row.append(InlineKeyboardButton("◀️", callback_data=f"market_create_offer_pg:{page-1}"))
        nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
        if page < total_pages:
            nav_row.append(InlineKeyboardButton("▶️", callback_data=f"market_create_offer_pg:{page+1}"))
        buttons.append(nav_row)

    buttons.append([InlineKeyboardButton("⬅️ Назад в маркет", callback_data="nav_market")])
    kb = InlineKeyboardMarkup(buttons)
    text = (
        "➕ <b>Выберите улучшенный Plush Pepe для продажи:</b>\n"
        f"<i>Комиссия маркета при продаже: {int(MARKET_FEE_RATE * 100)}%.</i>"
    )
    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_market_my_offers(query, user_id: int):
    lots = get_user_market_listings(user_id)
    buttons = []
    if not lots:
        text = "🔍 <b>Мои активные лоты</b>\n\nУ вас сейчас нет активных лотов на маркете."
    else:
        lines = [f"🔍 <b>Мои активные лоты ({len(lots)}):</b>\n"]
        for lot in lots:
            bg = BACKDROPS_BY_KEY.get(lot["backdrop_key"])
            bg_name = bg.name if bg else lot["backdrop_key"]
            lines.append(f"• Лот #{lot['id']}: <b>#{lot['upgrade_num']} {clean_html(lot['model_name'])}</b> ({clean_html(bg_name)}) — <b>{fmt_stars_compact(lot['price_stars'])} ⭐</b>")
            buttons.append([
                InlineKeyboardButton(f"⚙️ Лот #{lot['id']} ({fmt_stars_compact(lot['price_stars'])}⭐)", callback_data=f"market_lot:{lot['id']}")
            ])
        text = "\n".join(lines)

    buttons.append([InlineKeyboardButton("➕ Продать улучшенный NFT", callback_data="market_create_offer")])
    buttons.append([InlineKeyboardButton("⬅️ Назад в маркет", callback_data="nav_market")])
    kb = InlineKeyboardMarkup(buttons)

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_market_history(query, user_id: int):
    rows = get_market_history(limit=12)
    if not rows:
        text = "📊 <b>История сделок маркета</b>\n\nСделок пока ещё не было."
    else:
        lines = ["📊 <b>Последние сделки на NFT Маркете:</b>\n━━━━━━━━━━━━━━━━━━"]
        for r in rows:
            bg = BACKDROPS_BY_KEY.get(r["backdrop_key"])
            bg_name = bg.name if bg else r["backdrop_key"]
            role_mark = "🟢 Продано вами" if r["seller_id"] == user_id else "🔵 Куплено вами" if r["buyer_id"] == user_id else "🔸 Сделка"
            lines.append(
                f"{role_mark}: <b>{clean_html(r['model_name'])}</b> ({clean_html(bg_name)}) — "
                f"<b>{fmt_stars_compact(r['price_stars'])} ⭐</b>"
            )
        text = "\n".join(lines)

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬅️ Назад в маркет", callback_data="nav_market")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")],
    ])
    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

# FSM: Выставление лота на маркет (market_offer_conv)
async def market_sell_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END
    query = update.callback_query
    user = query.from_user
    item_id = int(query.data.split(":")[1])

    item = get_collection_item(item_id)
    if not item or item["user_id"] != user.id:
        await query.answer("❌ Подарок не найден.", show_alert=True)
        return ConversationHandler.END
    if not item["is_upgraded"]:
        await query.answer("❌ На маркет можно выставлять только улучшенные подарки!", show_alert=True)
        return ConversationHandler.END
    if item["is_listed"]:
        await query.answer("⚠️ Подарок уже выставлен на маркете.", show_alert=True)
        return ConversationHandler.END

    await query.answer()
    context.user_data["market_sell_item_id"] = item_id
    bg = BACKDROPS_BY_KEY.get(item["backdrop_key"])
    bg_name = bg.name if bg else (item["backdrop_key"] or "")

    text = (
        f"🛒 <b>Выставление на NFT Маркет</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"Подарок: <b>Plush Pepe #{item['upgrade_num']}</b>\n"
        f"🐸 Модель: <b>{clean_html(item['model_name'])}</b>\n"
        f"🎨 Фон: <b>{clean_html(bg_name)}</b>\n"
        f"💎 Рекомендованная цена: <b>~{fmt_stars_compact(item['upgraded_stars'])} ⭐</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"Введите цену продажи в Stars (от <b>{MARKET_MIN_PRICE:,}</b> до <b>{fmt_stars_compact(MARKET_MAX_PRICE)} ⭐</b>):\n"
        f"<i>При покупке маркет удержит комиссию {int(MARKET_FEE_RATE * 100)}%.</i>"
    )
    kb = InlineKeyboardMarkup([[make_btn("❌ Отмена", style="danger", callback_data="market_sell_cancel")]])
    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_MARKET_OFFER_PRICE

async def market_sell_price_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END
    raw = re.sub(r"[\s,_.]", "", update.message.text.strip())
    if not raw.isdigit():
        await update.message.reply_text(
            f"❌ Введите целое число от {MARKET_MIN_PRICE:,} до {MARKET_MAX_PRICE:,} (или /cancel):"
        )
        return WAIT_MARKET_OFFER_PRICE

    price = int(raw)
    if price < MARKET_MIN_PRICE or price > MARKET_MAX_PRICE:
        await update.message.reply_text(
            f"❌ Цена должна быть от <b>{MARKET_MIN_PRICE:,} ⭐</b> до <b>{MARKET_MAX_PRICE:,} ⭐</b>!",
            parse_mode=ParseMode.HTML,
        )
        return WAIT_MARKET_OFFER_PRICE

    item_id = context.user_data.get("market_sell_item_id")
    if not item_id:
        await update.message.reply_text("❌ Сессия устарела. Попробуйте снова.", reply_markup=quick_nav_keyboard())
        return ConversationHandler.END

    ok, msg_res, listing_id = create_market_listing(update.effective_user.id, item_id, price)
    context.user_data.pop("market_sell_item_id", None)
    if not ok:
        await update.message.reply_text(f"❌ {msg_res}", reply_markup=quick_nav_keyboard())
        return ConversationHandler.END

    fee = int(price * MARKET_FEE_RATE)
    seller_gets = price - fee
    bot_username = await get_bot_username(context.bot)
    lot_link = f"https://t.me/{bot_username}?start=lot_{listing_id}"
    share_url = (
        f"https://t.me/share/url?url={urllib.parse.quote(lot_link)}"
        f"&text={urllib.parse.quote(f'🛒 Выставил Plush Pepe на NFT Маркет за {fmt_stars_compact(price)} ⭐! Лот #{listing_id}')}"
    )
    kb = InlineKeyboardMarkup([
        [make_btn("🔗 Поделиться подарком", style="primary", url=share_url)],
        [make_btn(f"🔎 Открыть лот #{listing_id}", style="success", callback_data=f"market_lot:{listing_id}")],
        [InlineKeyboardButton("🛒 В NFT Маркет", callback_data="nav_market")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")],
    ])
    await update.message.reply_text(
        f"✅ <b>Лот #{listing_id} выставлен на маркет!</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"• Цена для покупателей: <b>{fmt_stars_compact(price)} ⭐</b>\n"
        f"• Комиссия площадки (15%): <b>-{fmt_stars_compact(fee)} ⭐</b>\n"
        f"• Вы получите при продаже: <b>+{fmt_stars_compact(seller_gets)} ⭐</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=kb,
    )
    return ConversationHandler.END

async def market_sell_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("market_sell_item_id", None)
    if update.callback_query:
        await update.callback_query.answer("Отменено.")
        await show_market_hub(update.callback_query)
    elif update.message:
        await update.message.reply_text("❌ Выставление на маркет отменено.", reply_markup=quick_nav_keyboard())
    return ConversationHandler.END

# FSM: Бесплатная передача подарка по кнопке (gift_transfer_conv)
async def gift_transfer_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END
    query = update.callback_query
    user = query.from_user
    item_id = int(query.data.split(":")[1])

    item = get_collection_item(item_id)
    if not item or item["user_id"] != user.id:
        await query.answer("❌ Подарок не найден.", show_alert=True)
        return ConversationHandler.END
    if item["is_listed"]:
        await query.answer("❌ Сначала снимите подарок с маркета!", show_alert=True)
        return ConversationHandler.END

    if not item["is_upgraded"]:
        sender_db = get_or_create_user(user.id, user.username or "", user.first_name or "")
        lvl, _, _, _ = calculate_xp_level_info(sender_db["xp"])
        if lvl < TRANSFER_MIN_LEVEL:
            await query.answer(f"❌ Передача обычных подарков доступна с {TRANSFER_MIN_LEVEL}-го уровня!", show_alert=True)
            return ConversationHandler.END

    await query.answer()
    context.user_data["gift_transfer_item_id"] = item_id
    g = GIFTS_BY_KEY.get(item["gift_key"])
    title = f"Plush Pepe #{item['upgrade_num']} ({item['model_name']})" if item["is_upgraded"] else (g.name if g else "Подарок")

    text = (
        f"🎁 <b>Бесплатная передача подарка</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"Подарок: <b>{clean_html(title)}</b>\n\n"
        f"Отправьте <code>@username</code> или <code>Telegram ID</code> игрока, которому хотите подарить этот NFT бесплатно:"
    )
    kb = InlineKeyboardMarkup([[make_btn("❌ Отмена", style="danger", callback_data="gift_transfer_cancel")]])
    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_GIFT_TRANSFER_USER

async def gift_transfer_user_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END
    sender = update.effective_user
    target_str = update.message.text.strip()
    target_row = get_user_by_target(target_str)

    if not target_row:
        await update.message.reply_text("❌ Игрок не найден в базе бота. Введите @username или ID заново (или /cancel):")
        return WAIT_GIFT_TRANSFER_USER
    if target_row["user_id"] == sender.id:
        await update.message.reply_text("❌ Нельзя передать подарок самому себе! Укажите другого игрока (или /cancel):")
        return WAIT_GIFT_TRANSFER_USER

    item_id = context.user_data.get("gift_transfer_item_id")
    item = get_collection_item(item_id) if item_id else None
    if not item or item["user_id"] != sender.id:
        context.user_data.pop("gift_transfer_item_id", None)
        await update.message.reply_text("❌ Подарок не найден.", reply_markup=quick_nav_keyboard())
        return ConversationHandler.END

    ok, res = transfer_gift_between_users(sender.id, target_row["user_id"], item_id)
    context.user_data.pop("gift_transfer_item_id", None)
    if not ok:
        await update.message.reply_text(f"❌ {res}", reply_markup=quick_nav_keyboard())
        return ConversationHandler.END

    g = GIFTS_BY_KEY.get(res)
    if item["is_upgraded"]:
        g_label = f"Plush Pepe #{item['upgrade_num']} ({item['model_name']})"
    else:
        g_label = g.name if g else res

    receiver_name = normalize_telegram_name(target_row["first_name"], target_row["username"], target_row["user_id"])

    try:
        if item["is_upgraded"]:
            m = PLUSHPEPE_MODELS_BY_NAME.get(item["model_name"]) or PLUSHPEPE_MODELS[0]
            b = BACKDROPS_BY_KEY.get(item["backdrop_key"]) or PLUSHPEPE_BACKDROPS[0]
            card_io = await generate_upgraded_gift_image(m, b, item["upgrade_num"], item["upgraded_stars"])
            await context.bot.send_photo(
                chat_id=target_row["user_id"],
                photo=InputFile(card_io, filename=f"gift_{item['id']}.png"),
                caption=(
                    f"🎁 <b>Вам бесплатно подарили улучшенный NFT!</b>\n\n"
                    f"От: <b>{clean_html(sender.first_name)}</b>\n"
                    f"Предмет: <b>{clean_html(g_label)}</b>\n"
                    f"🎨 Фон: <b>{clean_html(b.name)}</b> ({b.chance_pct}%)\n"
                    f"Подарок уже добавлен в вашу коллекцию!"
                ),
                parse_mode=ParseMode.HTML,
                reply_markup=quick_nav_keyboard(),
            )
        else:
            await context.bot.send_message(
                chat_id=target_row["user_id"],
                text=(
                    f"🎁 <b>Вам бесплатно подарили подарок!</b>\n\n"
                    f"От: <b>{clean_html(sender.first_name)}</b>\n"
                    f"Предмет: <b>{clean_html(g_label)}</b>"
                ),
                parse_mode=ParseMode.HTML,
                reply_markup=quick_nav_keyboard(),
            )
    except Exception:
        pass

    await update.message.reply_text(
        f"✅ <b>Подарок бесплатно передан!</b>\n"
        f"Предмет <b>{clean_html(g_label)}</b> отправлен игроку <b>{clean_html(receiver_name)}</b>.",
        parse_mode=ParseMode.HTML,
        reply_markup=quick_nav_keyboard(),
    )
    return ConversationHandler.END

async def gift_transfer_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("gift_transfer_item_id", None)
    if update.callback_query:
        await update.callback_query.answer("Отменено.")
        await update.callback_query.edit_message_text("❌ Передача подарка отменена.", reply_markup=quick_nav_keyboard())
    elif update.message:
        await update.message.reply_text("❌ Передача отменена.", reply_markup=quick_nav_keyboard())
    return ConversationHandler.END

# ---------------------------------------------------------------------------
# АДМИН-ПАНЕЛЬ И ОТКЛЮЧЕНИЕ БОТА (ТЕХРАБОТЫ)
# ---------------------------------------------------------------------------

async def show_admin_panel(query) -> None:
    conn = db_connect()
    try:
        total_users = conn.execute("SELECT COUNT(*) as cnt FROM users").fetchone()["cnt"]
        total_banned = conn.execute("SELECT COUNT(*) as cnt FROM users WHERE is_banned=1").fetchone()["cnt"]
        total_collection_gifts = conn.execute("SELECT COUNT(*) as cnt FROM collection").fetchone()["cnt"]
        total_sold = conn.execute("SELECT SUM(total_sold) as s FROM users").fetchone()["s"] or 0
        total_drops = conn.execute("SELECT SUM(total_drops) as s FROM users").fetchone()["s"] or 0
        total_stars_capital = conn.execute("SELECT SUM(balance_stars) as s FROM users").fetchone()["s"] or 0
        total_clans = conn.execute("SELECT COUNT(*) as cnt FROM clans").fetchone()["cnt"]
    finally:
        conn.close()

    maint_on = is_maintenance_mode()
    maint_status = "🔴 ОТКЛЮЧЁН (Техработы)" if maint_on else "🟢 ВКЛЮЧЁН (Работает)"
    maint_btn_text = "🟢 Включить бота (Отключить техработы)" if maint_on else "🔴 Отключить бота (Техработы)"
    maint_style = "success" if maint_on else "danger"
    now_str = datetime.datetime.now().strftime("%H:%M:%S")

    text = (
        "👑 <b>Панель управления администратора</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"⚙️ Статус бота: <b>{maint_status}</b>\n"
        f"👥 Зарегистрировано игроков: <b>{total_users:,}</b>\n"
        f"⛔️ Заблокировано игроков: <b>{total_banned:,}</b>\n"
        f"🛡 Создано кланов: <b>{total_clans:,}</b>\n"
        f"💰 Совокупный баланс игроков: <b>{fmt_stars_compact(total_stars_capital)} ⭐</b>\n"
        f"🎁 Подарков в коллекциях: <b>{total_collection_gifts:,}</b>\n"
        f"🎰 Всего выбито подарков: <b>{total_drops:,}</b>\n"
        f"🛍 Продано предметов: <b>{total_sold:,}</b>\n"
        f"🕒 Обновлено: <code>{now_str}</code>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Выберите действие:"
    )

    kb = InlineKeyboardMarkup([
        [make_btn(maint_btn_text, style=maint_style, callback_data="admin_toggle_maintenance")],
        [make_btn("🔄 Обновить", style="primary", callback_data="admin_refresh")],
        [InlineKeyboardButton("⭐ Выдать Звёзды игроку", callback_data="admin_give_stars_start")],
        [InlineKeyboardButton("🎁 Выдать NFT-подарок (фильтры)", callback_data="admin_give_nft_start")],
        [
            make_btn("🔨 Забанить игрока", style="danger", callback_data="admin_ban_start"),
            make_btn("🔓 Разбанить игрока", style="success", callback_data="admin_unban_start"),
        ],
        [InlineKeyboardButton("☁️ Firebase Облако (base.db)", callback_data="admin_firebase_menu")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")],
    ])

    try:
        if query.message.photo:
            await query.message.delete()
            await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    except Exception as e:
        if "message is not modified" not in str(e).lower():
            log.warning("show_admin_panel error: %s", e)

async def show_admin_firebase_menu(query) -> None:
    status_icon = "🟢" if firebase_manager.initialized else "⚠️"
    status_msg = (
        "Подключено к Cloud Firestore (100% бесплатно)" if firebase_manager.initialized
        else "Инициализация..."
    )

    db_size = DB_PATH.stat().st_size if DB_PATH.exists() else 0
    if firebase_manager.last_sync_ts > 0:
        diff = int(time.time() - firebase_manager.last_sync_ts)
        ago_str = f"{diff} сек. назад"
    else:
        ago_str = "еще не производилась"

    safe_status_msg = clean_html(status_msg)
    safe_col = clean_html(firebase_manager.collection_name)
    safe_doc = clean_html(firebase_manager.doc_name)
    clean_sync_raw = re.sub(r"<[^>]+>", "", str(firebase_manager.last_sync_status))
    safe_sync_status = clean_html(clean_sync_raw)

    text = (
        "☁️ <b>Управление облачной базой Firebase Firestore</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "• Проект: <b>proar-5a642</b>\n"
        f"• Коллекция: <code>{safe_col}</code>\n"
        f"• Документ: <code>{safe_doc}</code>\n"
        f"• Статус: {status_icon} <b>{safe_status_msg}</b>\n"
        f"• Локальная база: <b>{db_size:,} байт</b>\n"
        f"• Синхронизация: <b>{safe_sync_status}</b> ({ago_str})\n"
        "━━━━━━━━━━━━━━━━━━\n"
    )

    kb = InlineKeyboardMarkup([
        [make_btn("🔄 Сохранить в Firestore сейчас", style="success", callback_data="admin_firebase_sync")],
        [make_btn("📥 Восстановить из Firestore", style="primary", callback_data="admin_firebase_restore")],
        [InlineKeyboardButton("🔑 Обновить JSON-ключ Firebase", callback_data="admin_firebase_upload_key")],
        [InlineKeyboardButton("👑 В админ-панель", callback_data="admin_panel")],
    ])

    try:
        if query.message.photo:
            await query.message.delete()
            await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    except Exception:
        plain_text = re.sub(r"<[^>]+>", "", text)
        if query.message.photo:
            await query.message.reply_text(plain_text, reply_markup=kb)
        else:
            await query.edit_message_text(plain_text, reply_markup=kb)

async def admin_firebase_upload_key_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query.from_user.id not in ADMIN_IDS:
        await query.answer("❌ Доступ запрещен!", show_alert=True)
        return ConversationHandler.END
    await query.answer()

    text = (
        "🔑 <b>Обновление сервисного JSON-ключа Firebase</b>\n\n"
        "Отправьте скачанный <code>.json</code> файл сервисного аккаунта в этот чат как документ (файл)."
    )
    kb = InlineKeyboardMarkup([[make_btn("❌ Отмена", style="danger", callback_data="admin_cancel")]])

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_ADMIN_FIREBASE_JSON

async def admin_firebase_json_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return ConversationHandler.END

    doc = update.message.document
    if not doc or not doc.file_name.lower().endswith(".json"):
        await update.message.reply_text("⚠️ Пожалуйста, отправьте файл ключа с расширением .json как документ.")
        return WAIT_ADMIN_FIREBASE_JSON

    try:
        tg_file = await doc.get_file()
        file_bytes = await tg_file.download_as_bytearray()
        data = json.loads(file_bytes.decode("utf-8"))

        if "private_key" not in data or "client_email" not in data:
            await update.message.reply_text("❌ В этом файле нет полей private_key или client_email.")
            return WAIT_ADMIN_FIREBASE_JSON

        target_path = BASE_DIR / "firebase-service-account.json"
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        firebase_manager.init_app(force_reload=True)
        sync_ok = firebase_manager.upload_db_to_cloud(force=True)

        if sync_ok:
            await update.message.reply_text(
                f"✅ <b>Новый ключ Firebase установлен и проверен!</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("👑 В админ-панель", callback_data="admin_panel")]])
            )
        else:
            clean_err = clean_html(re.sub(r"<[^>]+>", "", str(firebase_manager.last_sync_status)))
            await update.message.reply_text(
                f"⚠️ Ключ сохранен, но возникла ошибка:\n<code>{clean_err}</code>",
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("👑 В админ-панель", callback_data="admin_panel")]])
            )
        return ConversationHandler.END
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка обработки файла: {e}")
        return ConversationHandler.END

# --- БАН / РАЗБАН ---

async def admin_ban_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query.from_user.id not in ADMIN_IDS:
        await query.answer("❌ Доступ запрещен!", show_alert=True)
        return ConversationHandler.END
    await query.answer()

    text = "🔨 <b>Блокировка игрока</b>\n\nВведите Telegram ID или @username нарушителя:"
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="admin_cancel")]])

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_ADMIN_BAN_USER

async def admin_ban_user_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target = get_user_by_target(update.message.text.strip())
    if not target:
        await update.message.reply_text("❌ Пользователь не найден в базе данных. Попробуйте снова:")
        return WAIT_ADMIN_BAN_USER

    if target["user_id"] in ADMIN_IDS:
        await update.message.reply_text("❌ Нельзя заблокировать администратора!")
        return ConversationHandler.END

    context.user_data["ban_target_id"] = target["user_id"]
    tname = normalize_telegram_name(target["first_name"], target["username"], target["user_id"])
    await update.message.reply_text(
        f"✅ Игрок найден: <b>{clean_html(tname)}</b> (ID: <code>{target['user_id']}</code>).\n\n"
        "Введите срок блокировки в часах:",
        parse_mode=ParseMode.HTML
    )
    return WAIT_ADMIN_BAN_HOURS

async def admin_ban_hours_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    hours_str = update.message.text.strip()
    if not hours_str.isdigit() or int(hours_str) <= 0:
        await update.message.reply_text("❌ Введите корректное положительное число часов:")
        return WAIT_ADMIN_BAN_HOURS

    context.user_data["ban_hours"] = int(hours_str)
    await update.message.reply_text("📝 Введите причину блокировки (кратко):")
    return WAIT_ADMIN_BAN_REASON

async def admin_ban_reason_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reason = update.message.text.strip()
    target_id = context.user_data.get("ban_target_id")
    hours = context.user_data.get("ban_hours", 24)

    ban_user(target_id, hours, reason)

    try:
        until_ts = int(time.time()) + (hours * 3600)
        ban_text, ban_kb = format_ban_message(until_ts, reason, hours)
        await context.bot.send_message(chat_id=target_id, text=ban_text, parse_mode=ParseMode.HTML, reply_markup=ban_kb)
    except Exception:
        pass

    await update.message.reply_text(
        f"⛔️ <b>Игрок (ID: <code>{target_id}</code>) заблокирован!</b>\n"
        f"• Срок: <b>{hours} ч.</b>\n• Причина: <b>{clean_html(reason)}</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("👑 В админ-панель", callback_data="admin_panel")],
            [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
        ])
    )
    return ConversationHandler.END

async def admin_unban_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query.from_user.id not in ADMIN_IDS:
        await query.answer("❌ Доступ запрещен!", show_alert=True)
        return ConversationHandler.END
    await query.answer()

    text = "🔓 <b>Разблокировка игрока</b>\n\nВведите Telegram ID или @username игрока:"
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="admin_cancel")]])

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_ADMIN_UNBAN_USER

async def admin_unban_user_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target = get_user_by_target(update.message.text.strip())
    if not target:
        await update.message.reply_text("❌ Пользователь не найден. Попробуйте снова:")
        return WAIT_ADMIN_UNBAN_USER

    target_id = target["user_id"]
    unban_user(target_id)

    try:
        await context.bot.send_message(
            chat_id=target_id,
            text="🎉 <b>Ваш аккаунт разблокирован администрацией!</b>",
            parse_mode=ParseMode.HTML,
            reply_markup=quick_nav_keyboard()
        )
    except Exception:
        pass

    await update.message.reply_text(
        f"✅ <b>Игрок (ID: <code>{target_id}</code>) разблокирован!</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("👑 В админ-панель", callback_data="admin_panel")],
            [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
        ])
    )
    return ConversationHandler.END

# --- ВЫДАЧА STARS ---

async def admin_give_stars_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query.from_user.id not in ADMIN_IDS:
        await query.answer("❌ Доступ запрещен!", show_alert=True)
        return ConversationHandler.END
    await query.answer()

    text = "⭐ <b>Выдача Звёзд игроку</b>\n\nВведите Telegram ID или @username игрока:"
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="admin_cancel")]])

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_ADMIN_GIVE_STARS_USER

async def admin_give_stars_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target = get_user_by_target(update.message.text.strip())
    if not target:
        await update.message.reply_text("❌ Пользователь не найден. Попробуйте снова:")
        return WAIT_ADMIN_GIVE_STARS_USER

    context.user_data["admin_target_user_id"] = target["user_id"]
    target_name = normalize_telegram_name(target["first_name"], target["username"], target["user_id"])
    await update.message.reply_text(
        f"✅ Пользователь найден: <b>{clean_html(target_name)}</b> (ID: <code>{target['user_id']}</code>).\n\n"
        "Введите количество Stars (⭐) для начисления:",
        parse_mode=ParseMode.HTML
    )
    return WAIT_ADMIN_GIVE_STARS_AMOUNT

async def admin_give_stars_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    amt_str = update.message.text.strip()
    if not amt_str.isdigit() or int(amt_str) <= 0:
        await update.message.reply_text("❌ Введите положительное число звёзд:")
        return WAIT_ADMIN_GIVE_STARS_AMOUNT

    amount = int(amt_str)
    target_id = context.user_data.get("admin_target_user_id")
    add_user_stars(target_id, amount)

    try:
        await context.bot.send_message(
            chat_id=target_id,
            text=f"🎉 <b>Вам начислено +{amount:,} ⭐ от Администрации!</b>",
            parse_mode=ParseMode.HTML,
            reply_markup=quick_nav_keyboard()
        )
    except Exception:
        pass

    await update.message.reply_text(
        f"✅ Успешно начислено <b>{amount:,} ⭐</b> пользователю (ID: <code>{target_id}</code>)!",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("👑 В админ-панель", callback_data="admin_panel")],
            [InlineKeyboardButton("🏠 В главное меню", callback_data="nav_main")]
        ])
    )
    return ConversationHandler.END

# --- ВЫДАЧА NFT ПО ФИЛЬТРАМ ---

async def admin_give_nft_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query.from_user.id not in ADMIN_IDS:
        await query.answer("❌ Доступ запрещен!", show_alert=True)
        return ConversationHandler.END
    await query.answer()

    text = "🎁 <b>Выдача NFT-подарка игроку</b>\n\nВведите Telegram ID или @username игрока:"
    kb = InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="admin_cancel")]])

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    return WAIT_ADMIN_GIVE_NFT_USER

async def admin_give_nft_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target = get_user_by_target(update.message.text.strip())
    if not target:
        await update.message.reply_text("❌ Пользователь не найден. Попробуйте еще раз:")
        return WAIT_ADMIN_GIVE_NFT_USER

    target_id = target["user_id"]
    context.user_data["admin_nft_target_user_id"] = target_id
    target_name = normalize_telegram_name(target["first_name"], target["username"], target_id)

    await show_admin_nft_filter_selector(update.message, target_id, target_name)
    return ConversationHandler.END

async def show_admin_nft_filter_selector(msg_or_query, target_id: int, target_name: str):
    text = (
        f"🎁 <b>Выдача подарка для игрока {clean_html(target_name)} (ID: {target_id})</b>\n\n"
        "Выберите способ фильтрации подарков:"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("💰 Фильтр: По стоимости", callback_data=f"adm_filt_price:{target_id}")],
        [InlineKeyboardButton("🧸 Фильтр: По моделям", callback_data=f"adm_filt_model:{target_id}")],
        [InlineKeyboardButton("📋 Все подарки", callback_data=f"adm_items:all:all:{target_id}:1")],
        [InlineKeyboardButton("👑 В админ-панель", callback_data="admin_panel")]
    ])
    if hasattr(msg_or_query, "reply_text"):
        await msg_or_query.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await msg_or_query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_admin_nft_price_tiers(query, target_id: int):
    text = f"💰 <b>Выбор по стоимости (ID получателя: {target_id}):</b>"
    buttons = [[InlineKeyboardButton(ptitle, callback_data=f"adm_items:price:{pkey}:{target_id}:1")] for pkey, (ptitle, _, _) in PRICE_TIERS.items()]
    buttons.append([InlineKeyboardButton("⬅️ К выбору фильтра", callback_data=f"adm_back_filters:{target_id}")])
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(buttons))

async def show_admin_nft_model_groups(query, target_id: int):
    text = f"🧸 <b>Выбор по моделям Telegram (ID получателя: {target_id}):</b>"
    buttons = [[InlineKeyboardButton(mtitle, callback_data=f"adm_items:model:{mkey}:{target_id}:1")] for mkey, mtitle in MODEL_GROUPS.items()]
    buttons.append([InlineKeyboardButton("⬅️ К выбору фильтра", callback_data=f"adm_back_filters:{target_id}")])
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(buttons))

async def show_admin_nft_items_page(query, ftype: str, fkey: str, target_id: int, page: int = 1):
    gifts_pool = get_gifts_filtered(ftype, fkey)
    page_size = 6
    total_pages = max(1, math.ceil(len(gifts_pool) / page_size))
    page = max(1, min(page, total_pages))

    items = gifts_pool[(page - 1) * page_size : page * page_size]

    text = (
        f"🎁 <b>Выберите подарок для выдачи (Стр. {page}/{total_pages})</b>\n"
        f"Получатель ID: <code>{target_id}</code>"
    )

    buttons = [[InlineKeyboardButton(f"🎁 {g.name[:25]} ({g.stars:,}⭐)", callback_data=f"adm_give_do:{g.key}:{target_id}")] for g in items]

    nav_row = []
    if page > 1:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"adm_items:{ftype}:{fkey}:{target_id}:{page-1}"))
    nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"adm_items:{ftype}:{fkey}:{target_id}:{page+1}"))
    if nav_row:
        buttons.append(nav_row)

    buttons.append([InlineKeyboardButton("📂 Сменить фильтр", callback_data=f"adm_back_filters:{target_id}")])
    buttons.append([InlineKeyboardButton("👑 Админ-Панель", callback_data="admin_panel")])

    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(buttons))

async def execute_admin_give_nft(query, gift_key: str, target_id: int, context: ContextTypes.DEFAULT_TYPE):
    gift = GIFTS_BY_KEY.get(gift_key)
    if not gift:
        await query.answer("❌ Подарок не найден!", show_alert=True)
        return

    add_to_collection(target_id, gift_key)

    try:
        await context.bot.send_message(
            chat_id=target_id,
            text=(
                f"🎁 <b>Вам выдан NFT-подарок от Администрации!</b>\n"
                f"<b>{gift.name}</b> ({fmt_stars_rub(gift.stars)})"
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=quick_nav_keyboard()
        )
    except Exception:
        pass

    await query.answer(f"✅ Выдан: {gift.name}!", show_alert=True)
    text = f"✅ <b>Подарок {gift.name} выдан игроку ID <code>{target_id}</code>!</b>"
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🎁 Выдать еще", callback_data=f"adm_back_filters:{target_id}")],
        [InlineKeyboardButton("👑 В админ-панель", callback_data="admin_panel")],
    ])
    await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def admin_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query:
        await query.answer("Отменено.")
        await show_admin_panel(query)
    else:
        await update.message.reply_text("Отменено.")
    return ConversationHandler.END

# ---------------------------------------------------------------------------
# КЛАНЫ — СОЗДАНИЕ И СПИСОК
# ---------------------------------------------------------------------------

CLAN_CREATE_LEVEL_REQ = 10
CLAN_CREATE_COST = 100_000

async def show_clans_hub(query_or_update, user_id: int, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_clan = get_user_clan(user_id)
    if user_clan:
        await show_clan_profile_handler(query_or_update, user_clan["id"], context)
        return

    db_user = get_or_create_user(user_id, "", "")
    lvl, _, _, _ = calculate_xp_level_info(db_user["xp"])

    text = (
        "🛡 <b>Система Кланов New NFT</b>\n\n"
        f"• Ваш уровень: <b>{lvl}</b> (требуется 10+)\n"
        f"• Стоимость основания: <b>100,000 ⭐</b>\n\n"
        "Клан даёт клановый тег, собственный герб, общую казну и мощный <b>бонус к шансу выигрыша подарков (+1%..+45%)</b>!\n\n"
        "Вы можете основать свой клан или вступить в существующий:"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🏷 Основать клан", callback_data="clan_create_start")],
        [InlineKeyboardButton("📋 Просмотреть список кланов", callback_data="clan_list:1")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")],
    ])

    banner_io = None
    try:
        banner_io = await generate_clans_hub_banner()
    except Exception as e:
        log.warning("Не удалось сгенерировать баннер раздела Кланы: %s", e)

    if isinstance(query_or_update, CallbackQuery):
        msg = query_or_update.message
        if msg:
            try:
                await msg.delete()
            except Exception:
                pass
            if banner_io:
                await msg.reply_photo(
                    photo=InputFile(banner_io, filename="clans_hub.png"),
                    caption=text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=kb,
                )
            else:
                await msg.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        target_msg = query_or_update.effective_message if hasattr(query_or_update, "effective_message") else query_or_update
        if target_msg:
            if banner_io:
                await target_msg.reply_photo(
                    photo=InputFile(banner_io, filename="clans_hub.png"),
                    caption=text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=kb,
                )
            else:
                await target_msg.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_clans_list(query, page: int = 1) -> None:
    clans, total_pages = get_all_clans(page, page_size=5)
    text = f"📋 <b>Список кланов (Стр. {page}/{total_pages}):</b>\n\n"
    buttons = []

    for c in clans:
        total_treasury, _, members = get_clan_treasury_and_members(c["id"])
        lvl, _, _, _, bonus = calculate_clan_level_info(c["xp"])
        ctype = "Публичный" if c["type"] == "public" else ("За звёзды" if c["type"] == "stars" else "Закрытый")

        text += (
            f"🛡 <b>[{c['tag']}] {clean_html(c['name'])}</b>\n"
            f"• Ур. {lvl} (+{bonus}% бонус) | {len(members)}/{c['max_members']} чел.\n"
            f"• Общая казна: {total_treasury:,} ⭐ ({ctype})\n\n"
        )
        buttons.append([InlineKeyboardButton(f"[{c['tag']}] {c['name']} (Ур. {lvl})", callback_data=f"clan_info:{c['id']}")])

    nav_row = []
    if page > 1:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"clan_list:{page-1}"))
    nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"clan_list:{page+1}"))
    if nav_row:
        buttons.append(nav_row)

    buttons.append([InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")])
    kb = InlineKeyboardMarkup(buttons)

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def start_clan_creation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access_allowed(update):
        return ConversationHandler.END
    if not await ensure_privacy_accepted_private(update, context):
        return ConversationHandler.END

    query = update.callback_query
    if query:
        user = query.from_user
        msg_obj = query.message
    else:
        user = update.effective_user
        msg_obj = update.message

    db_user = get_or_create_user(user.id, user.username or "", user.first_name or "")
    lvl, _, _, _ = calculate_xp_level_info(db_user["xp"])

    if lvl < CLAN_CREATE_LEVEL_REQ:
        text = f"❌ Для создания клана нужен {CLAN_CREATE_LEVEL_REQ} уровень!"
        if query: await query.answer(text, show_alert=True)
        else: await msg_obj.reply_text(text)
        return ConversationHandler.END

    if db_user["balance_stars"] < CLAN_CREATE_COST:
        text = f"❌ Создание клана стоит {CLAN_CREATE_COST:,} ⭐!"
        if query: await query.answer(text, show_alert=True)
        else: await msg_obj.reply_text(text)
        return ConversationHandler.END

    if query:
        await query.answer()

    msg_text = (
        "🏷 <b>Шаг 1 из 4: Клантег</b>\n\n"
        "Введите заглавный английский клантег (от 3 до 6 символов, только A-Z и 0-9).\n"
        "<i>Пример: TOP1, GODS, ALPHA</i>"
    )
    if query and query.message.photo:
        await query.message.delete()
        await query.message.reply_text(msg_text, parse_mode=ParseMode.HTML)
    elif query:
        await query.edit_message_text(msg_text, parse_mode=ParseMode.HTML)
    else:
        await msg_obj.reply_text(msg_text, parse_mode=ParseMode.HTML)
    return WAIT_CLAN_TAG

async def clan_tag_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tag = update.message.text.strip().upper()
    if not re.match(r"^[A-Z0-9]{3,6}$", tag):
        await update.message.reply_text("❌ Некорректный клантег! Введите 3-6 заглавных английских букв или цифр:")
        return WAIT_CLAN_TAG

    context.user_data["clan_tag"] = tag
    await update.message.reply_text(
        "📝 <b>Шаг 2 из 4: Название клана</b>\n\n"
        "Введите название вашего клана (от 2 до 15 символов):",
        parse_mode=ParseMode.HTML
    )
    return WAIT_CLAN_NAME

async def clan_name_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    name = update.message.text.strip()
    if len(name) > 15 or len(name) < 2:
        await update.message.reply_text("❌ Название должно содержать от 2 до 15 символов! Попробуйте снова:")
        return WAIT_CLAN_NAME

    context.user_data["clan_name"] = name
    await update.message.reply_text(
        "ℹ️ <b>Шаг 3 из 4: Описание клана</b>\n\n"
        "Напишите краткое описание вашего клана (или точку):",
        parse_mode=ParseMode.HTML
    )
    return WAIT_CLAN_DESC

async def clan_desc_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["clan_desc"] = update.message.text.strip()

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🌐 Публичный (Свободный вход)", callback_data="ctype:public")],
        [InlineKeyboardButton("🔒 Закрытый (По заявкам)", callback_data="ctype:private")],
        [InlineKeyboardButton("⭐ Вход за звёзды", callback_data="ctype:stars")],
    ])
    await update.message.reply_text(
        "🔒 <b>Шаг 4 из 4: Тип клана</b>\n\nВыберите способ вступления в клан:",
        parse_mode=ParseMode.HTML,
        reply_markup=kb
    )
    return WAIT_CLAN_TYPE

async def clan_type_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    ctype = query.data.split(":")[1]
    context.user_data["clan_type"] = ctype

    if ctype == "stars":
        await query.edit_message_text("💰 Укажите стоимость входа в клан в ⭐ (Stars):")
        return WAIT_CLAN_FEE
    else:
        return await finalize_clan_creation(query.from_user.id, context, query.message)

async def clan_fee_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit() or int(text) < 1:
        await update.message.reply_text("❌ Введите корректное число звёзд:")
        return WAIT_CLAN_FEE

    context.user_data["clan_fee"] = int(text)
    return await finalize_clan_creation(update.effective_user.id, context, update.message)

async def finalize_clan_creation(user_id: int, context: ContextTypes.DEFAULT_TYPE, msg_obj):
    tag = context.user_data.get("clan_tag")
    name = context.user_data.get("clan_name")
    desc = context.user_data.get("clan_desc", "")
    ctype = context.user_data.get("clan_type", "public")
    fee = context.user_data.get("clan_fee", 0)

    if not deduct_user_stars(user_id, CLAN_CREATE_COST):
        await msg_obj.reply_text("❌ Недостаточно Stars на балансе!")
        return ConversationHandler.END

    clan_id = create_clan(user_id, tag, name, desc, ctype, fee)
    if clan_id:
        clan = get_clan_by_id(clan_id)
        clan_sys_id = clan["id_num"] if clan["id_num"] else clan["id"]
        text = (
            f"🎉 <b>Клан [{tag}] {clean_html(name)} успешно создан!</b>\n"
            f"Единый глобальный номер клана: <b>ID #{clan_sys_id}</b>\n\n"
            f"С вашего баланса списано {CLAN_CREATE_COST:,} ⭐."
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🛡 В профиль клана", callback_data=f"clan_info:{clan_id}")],
            [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
        ])
        if hasattr(msg_obj, "edit_text"):
            await msg_obj.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await msg_obj.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        add_user_stars(user_id, CLAN_CREATE_COST)
        await msg_obj.reply_text("❌ Ошибка при создании клана. Возможно, клантег уже занят.")

    return ConversationHandler.END

async def cancel_clan_creation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Создание клана отменено.", reply_markup=back_to_main_keyboard())
    return ConversationHandler.END

# ---------------------------------------------------------------------------
# МАГАЗИН, НАСТРОЙКИ, КОЛЛЕКЦИЯ И ТОП-100
# ---------------------------------------------------------------------------

async def show_shop_page(query_or_msg, user_id: int) -> None:
    db_user = get_or_create_user(user_id, "", "")
    all_items = get_user_collection(user_id)
    upgradable = [
        it for it in all_items
        if it["gift_key"] == "pepe_heart" and not it["is_upgraded"] and not it["is_listed"]
    ]

    lines = [
        "✨ <b>Улучшения NFT (Plush Pepe Upgrades)</b>",
        "━━━━━━━━━━━━━━━━━━",
        f"Ваш баланс: <b>{fmt_stars_rub(db_user['balance_stars'])}</b>",
        f"Стоимость улучшения: <b>{UPGRADE_COST_STARS:,} ⭐</b>\n",
        "При улучшении <b>Plush Pepe</b> случайным образом выпадают:",
        "• <b>1 из 50 уникальных моделей</b> Plush Pepe",
        "• <b>1 из 61 фонов</b> (мифический <b>Rainbow x100 • 0.05%</b>, чёрные, серые, золото)",
        "• <b>MONOCHROME x6:</b> если цвет модели совпадает с фоном — стоимость умножается в <b>6 раз</b>!",
        "• Улучшенный NFT можно <b>продать на Маркете</b> или <b>передать бесплатно</b>!",
        "━━━━━━━━━━━━━━━━━━",
    ]

    buttons = []
    if not upgradable:
        lines.append(
            "<i>У вас пока нет обычных Plush Pepe для улучшения.</i>\n"
            "Выбейте <b>Plush Pepe</b> в группе по слову <code>NFT</code> или в <b>Mystery Cases</b>!"
        )
    else:
        lines.append(f"Доступно Plush Pepe для улучшения: <b>{len(upgradable)}</b> шт.\nВыберите подарок ниже:")
        for it in upgradable[:8]:
            buttons.append([
                make_btn(
                    f"✨ Улучшить Plush Pepe (#ID {it['id']}) — {UPGRADE_COST_STARS:,}⭐",
                    style="primary",
                    callback_data=f"upgrade_item:{it['id']}"
                )
            ])

    buttons.append([InlineKeyboardButton(f"📦 Слоты инвентаря ({db_user['max_inventory']} мест)", callback_data="shop_slots_menu")])
    buttons.append([
        InlineKeyboardButton("🗂 В коллекцию", callback_data="nav_collection_page:1"),
        InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
    ])

    text = "\n".join(lines)
    kb = InlineKeyboardMarkup(buttons)

    if isinstance(query_or_msg, CallbackQuery):
        if query_or_msg.message and query_or_msg.message.photo:
            await query_or_msg.message.delete()
            await query_or_msg.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        elif query_or_msg.message:
            await query_or_msg.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        target_msg = query_or_msg.effective_message if hasattr(query_or_msg, "effective_message") else query_or_msg
        if target_msg:
            await target_msg.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_shop_slots_menu(query, user_id: int) -> None:
    db_user = get_or_create_user(user_id, "", "")
    text = (
        "📦 <b>Расширение слотов коллекции</b>\n\n"
        f"Текущие слоты коллекции: <b>{db_user['max_inventory']}</b>\n"
        f"Ваш баланс: <b>{fmt_stars_rub(db_user['balance_stars'])}</b>\n\n"
        "Доступные расширения слотов:\n"
        "• <b>+10 Слотов</b> — <b>300 ⭐</b>\n"
        "• <b>+25 Слотов</b> — <b>650 ⭐</b>\n"
        "• <b>+50 Слотов</b> — <b>1,200 ⭐</b>"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📦 +10 Слотов (300⭐)", callback_data="buy_slots:10:300")],
        [InlineKeyboardButton("📦 +25 Слотов (650⭐)", callback_data="buy_slots:25:650")],
        [InlineKeyboardButton("📦 +50 Слотов (1200⭐)", callback_data="buy_slots:50:1200")],
        [InlineKeyboardButton("⬅️ Назад к улучшениям", callback_data="nav_shop")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")],
    ])
    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_gift_upgrade_confirm(query, user_id: int, item_id: int) -> None:
    item = get_collection_item(item_id)
    if not item or item["user_id"] != user_id:
        await query.answer("❌ Подарок не найден.", show_alert=True)
        return
    if item["gift_key"] != "pepe_heart":
        await query.answer("❌ Улучшение пока доступно только для Plush Pepe!", show_alert=True)
        return
    if item["is_upgraded"]:
        await query.answer("⚠️ Этот подарок уже улучшен!", show_alert=True)
        return
    if item["is_listed"]:
        await query.answer("⚠️ Сначала снимите подарок с маркета!", show_alert=True)
        return

    db_user = get_or_create_user(user_id, "", "")
    text = (
        f"✨ <b>Подтверждение улучшения Plush Pepe (#ID {item_id})</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"• Ваш баланс: <b>{fmt_stars_rub(db_user['balance_stars'])}</b>\n"
        f"• Стоимость улучшения: <b>{UPGRADE_COST_STARS:,} ⭐</b>\n\n"
        f"После нажатия начнётся 5-секундная распаковка: сначала откроется случайная модель из 50 вариантов, затем — один из 61 фонов (включая мифический Rainbow x100 и комбо MONOCHROME x6)!\n"
        f"━━━━━━━━━━━━━━━━━━"
    )
    kb = InlineKeyboardMarkup([
        [make_btn(f"✨ Улучшить за {UPGRADE_COST_STARS:,} ⭐", style="success", callback_data=f"upgrade_confirm:{item_id}")],
        [make_btn("❌ Отмена", style="danger", callback_data="nav_shop")],
    ])
    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def execute_gift_upgrade(query, user_id: int, item_id: int, context: ContextTypes.DEFAULT_TYPE) -> None:
    item = get_collection_item(item_id)
    if not item or item["user_id"] != user_id:
        await query.answer("❌ Подарок не найден.", show_alert=True)
        return
    if item["gift_key"] != "pepe_heart" or item["is_upgraded"] or item["is_listed"]:
        await query.answer("❌ Невозможно улучшить этот предмет.", show_alert=True)
        return

    db_user = get_or_create_user(user_id, "", "")
    if db_user["balance_stars"] < UPGRADE_COST_STARS:
        await query.answer(f"❌ Недостаточно Stars! Нужно {UPGRADE_COST_STARS:,} ⭐.", show_alert=True)
        return

    chosen_model = roll_plush_model()
    chosen_backdrop = roll_backdrop()
    g = GIFTS_BY_KEY["pepe_heart"]
    est_stars = calculate_upgraded_stars(g.stars, chosen_model, chosen_backdrop)
    is_mono, mono_fam = get_monochrome_combo_info(chosen_model.name, chosen_backdrop.key)

    ok, msg_res, upgrade_num = upgrade_collection_item(
        user_id=user_id,
        item_id=item_id,
        model_name=chosen_model.name,
        backdrop_key=chosen_backdrop.key,
        upgraded_stars=est_stars,
        cost=UPGRADE_COST_STARS,
    )
    if not ok:
        await query.answer(f"❌ {msg_res}", show_alert=True)
        return

    await query.answer("✨ Запускаем улучшение!")
    if query.message.photo:
        try: await query.message.delete()
        except Exception: pass
        anim_msg = await query.message.reply_text(
            "✨ <b>Улучшение Plush Pepe...</b>\n\n"
            "⏳ Шаг 1/2: Генерируем модель из 50 вариантов...",
            parse_mode=ParseMode.HTML,
        )
    else:
        anim_msg = await query.edit_message_text(
            "✨ <b>Улучшение Plush Pepe...</b>\n\n"
            "⏳ Шаг 1/2: Генерируем модель из 50 вариантов...",
            parse_mode=ParseMode.HTML,
        )

    await asyncio.sleep(1.5)
    try:
        await anim_msg.edit_text(
            "✨ <b>Улучшение Plush Pepe...</b>\n\n"
            f"🐸 Открыта модель: <b>{clean_html(chosen_model.name)}</b> (шанс {chosen_model.chance_pct}%)!\n"
            "🎨 Шаг 2/2: Подбираем редкий фон из 61 палитры...",
            parse_mode=ParseMode.HTML,
        )
    except Exception:
        pass

    await asyncio.sleep(1.5)
    try:
        await anim_msg.edit_text(
            "✨ <b>Улучшение Plush Pepe...</b>\n\n"
            f"🐸 Модель: <b>{clean_html(chosen_model.name)}</b> ({chosen_model.chance_pct}%)\n"
            f"🔮 Проявляем фон: <b>{clean_html(chosen_backdrop.name)}</b> ({chosen_backdrop.rarity_label})...",
            parse_mode=ParseMode.HTML,
        )
    except Exception:
        pass

    await asyncio.sleep(2.0)

    card_io = await generate_upgraded_gift_image(chosen_model, chosen_backdrop, upgrade_num, est_stars)
    try:
        await anim_msg.delete()
    except Exception:
        pass

    mono_line = f"\n🌈 <b>МОНОХРОМНОЕ КОМБО x6!</b> ({COLOR_FAMILY_RU.get(mono_fam, mono_fam)})" if is_mono else ""
    cap = (
        f"🎉 <b>Улучшение завершено! Plush Pepe #{upgrade_num}</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🐸 Модель: <b>{clean_html(chosen_model.name)}</b> (шанс {chosen_model.chance_pct}%)\n"
        f"🎨 Фон: <b>{clean_html(chosen_backdrop.name)}</b> • <i>{chosen_backdrop.rarity_label}</i> ({chosen_backdrop.chance_pct}%){mono_line}\n"
        f"💎 Оценочная ценность: <b>{fmt_stars_rub(est_stars)}</b>\n"
        f"⚡️ Бонус опыта: <b>+5,000 XP</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"Теперь этот NFT можно продать на Маркете, бесплатно передать другому игроку или закрепить в Избранное профиля!"
    )
    kb = InlineKeyboardMarkup([
        [make_btn("🛒 Выставить на маркет", style="primary", callback_data=f"market_sell_start:{item_id}")],
        [InlineKeyboardButton("🎁 Передать бесплатно", callback_data=f"gift_transfer_start:{item_id}")],
        [InlineKeyboardButton("⭐ В избранное", callback_data=f"toggle_fav:{item_id}:1")],
        [
            InlineKeyboardButton("🗂 В коллекцию", callback_data="nav_collection_page:1"),
            InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main"),
        ],
    ])
    await context.bot.send_photo(
        chat_id=user_id,
        photo=InputFile(card_io, filename=f"plushpepe_{upgrade_num}.png"),
        caption=cap,
        parse_mode=ParseMode.HTML,
        reply_markup=kb,
    )

async def show_settings_page(query, user_id: int) -> None:
    db_user = get_or_create_user(user_id, "", "")
    hide_top = "✅ Да" if db_user["hide_top"] else "❌ Нет"
    hide_coll = "✅ Да" if db_user["hide_collection"] else "❌ Нет"
    auto_sell = "✅ Включена" if db_user["auto_sell"] else "❌ Выключена"
    has_bg = "✅ Установлен" if db_user["bg_image_path"] else "❌ Стандартный"

    text = (
        "⚙️ <b>Настройки аккаунта</b>\n\n"
        f"• Скрывать из ТОП-100: <b>{hide_top}</b>\n"
        f"• Скрывать коллекцию: <b>{hide_coll}</b>\n"
        f"• Авто-продажа кейсов: <b>{auto_sell}</b>\n"
        f"• Кастомный фон профиля: <b>{has_bg}</b>"
    )

    bg_cost = BG_CHANGE_COST if db_user["bg_image_path"] else BG_SET_COST
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"Скрытие из ТОПа: {hide_top}", callback_data="toggle_set:hide_top")],
        [InlineKeyboardButton(f"Скрытие коллекции: {hide_coll}", callback_data="toggle_set:hide_collection")],
        [InlineKeyboardButton(f"Авто-продажа: {auto_sell}", callback_data="toggle_set:auto_sell")],
        [InlineKeyboardButton(f"🖼 Фон профиля ({bg_cost:,}⭐)", callback_data="bg_change_start")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")],
    ])

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_collection_page(query, user_id: int, page: int = 1) -> None:
    items = get_user_collection(user_id)
    db_user = get_or_create_user(user_id, "", "")
    max_inv = db_user["max_inventory"]

    if not items:
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🎰 Открыть кейсы", callback_data="nav_cases_hub")],
            [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")],
        ])
        msg_text = f"🗂 <b>Твоя коллекция пока пуста (0/{max_inv}).</b>\nВыбивай подарки по слову <code>NFT</code> в группах или открывай кейсы!"
        if query.message.photo:
            await query.message.delete()
            await query.message.reply_text(msg_text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text(msg_text, parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    items_per_page = 10
    total_pages = max(1, math.ceil(len(items) / items_per_page))
    page = max(1, min(page, total_pages))

    start_idx = (page - 1) * items_per_page
    page_items = items[start_idx : start_idx + items_per_page]

    buttons = []
    for item in page_items:
        g = GIFTS_BY_KEY.get(item["gift_key"])
        if not g: continue
        fav_star = "⭐ " if item["is_favorite"] else ""
        val_stars = get_item_display_value(item)
        if item["is_upgraded"]:
            listed_mark = " 🛒" if item["is_listed"] else ""
            btn_text = f"{fav_star}✨ #{item['upgrade_num']} {item['model_name']}{listed_mark} ({fmt_stars_compact(val_stars)}⭐)"
        else:
            btn_text = f"{fav_star}{g.name} ({fmt_stars_compact(val_stars)}⭐)"
        buttons.append([InlineKeyboardButton(btn_text[:60], callback_data=f"view_item:{item['id']}:{page}")])

    nav_row = []
    if page > 1:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"nav_collection_page:{page-1}"))
    nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"nav_collection_page:{page+1}"))
    buttons.append(nav_row)

    buttons.append([make_btn("🔥 Продать всё (кроме избранных и улучшенных)", style="danger", callback_data="sell_all_confirm")])
    buttons.append([
        InlineKeyboardButton("👤 Профиль", callback_data="nav_profile"),
        InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
    ])

    kb = InlineKeyboardMarkup(buttons)
    text = f"🗂 <b>Твоя NFT-Коллекция ({len(items)}/{max_inv}):</b>"

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def show_top_page(query, page: int = 1) -> None:
    page_size = 10
    rows, total_pages = get_top_users_page(page, page_size)

    lines = [f"🏆 <b>Глобальный ТОП-100 Игроков (Стр. {page}/{total_pages})</b>\n━━━━━━━━━━━━━━━━━━"]
    buttons = []

    start_rank = (page - 1) * page_size + 1
    for idx, u in enumerate(rows, start=start_rank):
        medal = "🥇" if idx == 1 else "🥈" if idx == 2 else "🥉" if idx == 3 else f"#{idx}"
        clan = get_user_clan(u['user_id'])
        tag_str = f"[{clan['tag']}] " if clan else ""
        name = normalize_telegram_name(u['first_name'], u['username'], u['user_id'])
        lvl, _, _, _ = calculate_xp_level_info(u['xp'])
        stars_disp = fmt_stars_compact(u['balance_stars'])
        lines.append(f"{medal} <b>{tag_str}{clean_html(name)}</b> — <b>{stars_disp} ⭐</b> (Ур. {lvl})")

        btn_text = f"👤 {medal} {tag_str}{name[:12]} ({stars_disp}⭐)"
        buttons.append([InlineKeyboardButton(btn_text, callback_data=f"view_top_user:{u['user_id']}:{page}")])

    lines.append("━━━━━━━━━━━━━━━━━━\n<i>Нажмите на игрока выше, чтобы открыть его профиль!</i>")

    nav_row = []
    if page > 1:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"nav_top_page:{page-1}"))
    nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"nav_top_page:{page+1}"))

    buttons.append(nav_row)
    buttons.append([
        InlineKeyboardButton("👤 Мой профиль", callback_data="nav_profile"),
        InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
    ])

    kb = InlineKeyboardMarkup(buttons)
    full_text = "\n".join(lines)

    if query.message.photo:
        await query.message.delete()
        await query.message.reply_text(full_text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await query.edit_message_text(full_text, parse_mode=ParseMode.HTML, reply_markup=kb)

# ---------------------------------------------------------------------------
# ЧАТ-КОМАНДА "ПЕРЕДАТЬ" (ЗВЁЗДЫ И ПОДАРКИ НА РУССКОМ И АНГЛИЙСКОМ)
# ---------------------------------------------------------------------------

TRANSFER_KEYWORDS = ("передать", "transfer", "send", "give")
GIFT_WORDS = {"подарок", "подарка", "gift", "nft", "нфт"}

def _extract_reply_or_target(msg, tokens: list[str]) -> Tuple[Optional[sqlite3.Row], list[str]]:
    """
    Определяет получателя либо через reply_to_message, либо через @username / ID / text_mention в токенах.
    Возвращает (target_db_row, оставшиеся_токены).
    """
    # 1. Проверяем текстовое упоминание (text_mention) без username
    if msg.entities:
        for ent in msg.entities:
            if ent.type == "text_mention" and ent.user and not ent.user.is_bot:
                row = get_or_create_user(ent.user.id, ent.user.username or "", ent.user.first_name or "")
                mention_txt = msg.text[ent.offset : ent.offset + ent.length].lower()
                rem = [t for t in tokens if t.lower() not in mention_txt.split()]
                return row, rem

    # 2. Проверяем токены на @username или числовой ID (если есть reply — сначала проверим явный @username, иначе reply)
    remaining = []
    explicit_target = None
    for tok in tokens:
        if tok.startswith("@") and len(tok) > 1 and explicit_target is None:
            found = get_user_by_target(tok)
            if found:
                explicit_target = found
                continue
        remaining.append(tok)

    if explicit_target:
        return explicit_target, remaining

    # 3. Проверяем ответ на сообщение (swipe / reply)
    if msg.reply_to_message and msg.reply_to_message.from_user:
        ruser = msg.reply_to_message.from_user
        if ruser.is_bot:
            return None, tokens
        row = get_or_create_user(ruser.id, ruser.username or "", ruser.first_name or "")
        return row, tokens

    # 4. Если нет reply, ищем числовой ID среди токенов (например, `Передать 1000 684535319` или `Передать подарок 684535319`)
    for idx in range(len(remaining) - 1, -1, -1):
        tok = remaining[idx]
        if tok.isdigit():
            found = get_user_by_target(tok)
            if found:
                new_rem = remaining[:idx] + remaining[idx + 1:]
                return found, new_rem

    return None, tokens

async def show_chat_gift_picker(msg, sender_id: int, target_row: sqlite3.Row, page: int = 1, edit_query=None):
    items = [it for it in get_user_collection(sender_id) if not it["is_listed"]]
    target_name = normalize_telegram_name(target_row["first_name"], target_row["username"], target_row["user_id"])

    if not items:
        text = "❌ У вас нет доступных подарков в коллекции для передачи."
        if edit_query:
            await edit_query.edit_message_text(text)
        else:
            await msg.reply_text(text)
        return

    page_size = 8
    total_pages = max(1, math.ceil(len(items) / page_size))
    page = max(1, min(page, total_pages))
    page_items = items[(page - 1) * page_size : page * page_size]

    text = (
        f"🎁 <b>Передача подарка игроку {clean_html(target_name)}</b> (Стр. {page}/{total_pages})\n"
        f"Выберите подарок из вашей коллекции:"
    )

    buttons = []
    for item in page_items:
        g = GIFTS_BY_KEY.get(item["gift_key"])
        if not g:
            continue
        val_stars = get_item_display_value(item)
        lbl = f"✨ #{item['upgrade_num']} {item['model_name']}" if item["is_upgraded"] else g.name[:24]
        buttons.append([
            InlineKeyboardButton(
                f"🎁 {lbl} ({fmt_stars_compact(val_stars)}⭐)",
                callback_data=f"chat_gx_do:{sender_id}:{target_row['user_id']}:{item['id']}"
            )
        ])

    nav_row = []
    if page > 1:
        nav_row.append(InlineKeyboardButton("◀️", callback_data=f"chat_gx_pg:{sender_id}:{target_row['user_id']}:{page-1}"))
    if total_pages > 1:
        nav_row.append(InlineKeyboardButton(f"{page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton("▶️", callback_data=f"chat_gx_pg:{sender_id}:{target_row['user_id']}:{page+1}"))
    if nav_row:
        buttons.append(nav_row)

    buttons.append([make_btn("❌ Отмена", style="danger", callback_data=f"chat_gx_cancel:{sender_id}")])
    kb = InlineKeyboardMarkup(buttons)

    if edit_query:
        await edit_query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    else:
        await msg.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def handle_chat_transfer(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """
    Обрабатывает чат-команды вида:
      - Передать 1000 (в ответ на сообщение) / Transfer 1000
      - Передать 1000 @username / Передать 1000 123456789
      - Передать подарок (в ответ на сообщение или с @username / ID)
      - Передать подарок <название> [@username / ID]
    Возвращает True, если сообщение было распознано как команда передачи.
    """
    msg = update.effective_message
    if not msg or not msg.text:
        return False

    raw = msg.text.strip()
    parts = raw.split()
    if not parts:
        return False

    first_word = parts[0].lower()
    if first_word not in TRANSFER_KEYWORDS:
        return False

    if not await check_access_allowed(update):
        return True

    sender = update.effective_user
    sender_db = get_or_create_user(sender.id, sender.username or "", sender.first_name or "")
    sender_lvl, _, _, _ = calculate_xp_level_info(sender_db["xp"])

    rest_tokens = parts[1:]
    is_gift_mode = any(t.lower() in GIFT_WORDS for t in rest_tokens)

    # Проверка уровня (5+ уровень требуется и для звёзд, и для подарков)
    if sender_lvl < TRANSFER_MIN_LEVEL:
        await msg.reply_text(
            f"❌ Передавать {'подарки' if is_gift_mode else 'звёзды'} можно только с <b>{TRANSFER_MIN_LEVEL}-го уровня</b>!\n"
            f"Ваш текущий уровень: <b>{sender_lvl}</b>.",
            parse_mode=ParseMode.HTML,
        )
        return True

    # Если режим подарка
    if is_gift_mode:
        # Убираем служебное слово "подарок" / "gift" и т.п.
        clean_tokens = [t for t in rest_tokens if t.lower() not in GIFT_WORDS]
        target_row, leftover = _extract_reply_or_target(msg, clean_tokens)

        if not target_row:
            await msg.reply_text(
                "❌ Получатель не найден!\n"
                "Ответьте на сообщение игрока текстом <code>Передать подарок</code> "
                "или укажите <code>Передать подарок @username</code> / <code>ID</code>.",
                parse_mode=ParseMode.HTML,
            )
            return True

        if target_row["user_id"] == sender.id:
            await msg.reply_text("❌ Нельзя передать подарок самому себе.")
            return True

        # Если указано название или ID предмета коллекции — ищем совпадение
        if leftover:
            query_str = " ".join(leftover).strip().lower()
            items = get_user_collection(sender.id)
            matched_item = None
            for it in items:
                if query_str.isdigit() and it["id"] == int(query_str):
                    matched_item = it
                    break
                g = GIFTS_BY_KEY.get(it["gift_key"])
                if g and (query_str in g.name.lower() or query_str == g.key.lower()):
                    matched_item = it
                    break

            if matched_item:
                ok, res = transfer_gift_between_users(sender.id, target_row["user_id"], matched_item["id"])
                if not ok:
                    await msg.reply_text(f"❌ {res}")
                    return True
                g = GIFTS_BY_KEY.get(res)
                g_name = g.name if g else res
                receiver_name = normalize_telegram_name(target_row["first_name"], target_row["username"], target_row["user_id"])
                await msg.reply_text(
                    f"🎁 <b>Подарок передан!</b>\n"
                    f"Игрок <b>{clean_html(sender.first_name)}</b> передал <b>{clean_html(g_name)}</b> "
                    f"игроку <b>{clean_html(receiver_name)}</b>!",
                    parse_mode=ParseMode.HTML,
                )
                try:
                    await context.bot.send_message(
                        chat_id=target_row["user_id"],
                        text=f"🎁 <b>Вам передали подарок!</b>\nОт: <b>{clean_html(sender.first_name)}</b>\nПодарок: <b>{clean_html(g_name)}</b>",
                        parse_mode=ParseMode.HTML,
                        reply_markup=quick_nav_keyboard(),
                    )
                except Exception:
                    pass
                return True

        # Если конкретный подарок не указан или не совпал — открываем выбор из коллекции
        await show_chat_gift_picker(msg, sender.id, target_row, page=1)
        return True

    # Режим передачи звёзд
    # Убираем слова вроде "звёзд", "звезд", "stars"
    star_noise = {"звёзд", "звезд", "звезды", "звёзды", "stars", "star", "⭐"}
    clean_tokens = [t for t in rest_tokens if t.lower() not in star_noise]

    if not clean_tokens:
        await msg.reply_text(
            "ℹ️ <b>Использование команды передачи:</b>\n"
            "• Ответом на сообщение: <code>Передать 1000</code>\n"
            "• По юзернейму/ID: <code>Передать 1000 @username</code>\n"
            "• Подарок: <code>Передать подарок</code> (в ответ или с <code>@username</code>)\n"
            f"<i>Требуется {TRANSFER_MIN_LEVEL}+ уровень. Звёзды передаются от {TRANSFER_MIN_STARS:,} ⭐.</i>",
            parse_mode=ParseMode.HTML,
        )
        return True

    # Выделяем сумму: первое число (если reply, или первое из двух чисел)
    amount = None
    tokens_without_amount = []
    for idx, tok in enumerate(clean_tokens):
        clean_num = tok.replace(",", "").replace(".", "")
        if amount is None and clean_num.isdigit():
            # Проверяем: если нет reply и всего один числовой токен без других не-числовых — это сумма, получателя нет
            amount = int(clean_num)
            continue
        tokens_without_amount.append(tok)

    if amount is None:
        await msg.reply_text("❌ Укажите сумму звёзд! Пример: <code>Передать 1000</code> или <code>Передать 1000 @username</code>.", parse_mode=ParseMode.HTML)
        return True

    target_row, _ = _extract_reply_or_target(msg, tokens_without_amount)
    if not target_row:
        await msg.reply_text(
            "❌ Получатель не найден!\n"
            "Ответьте (свайпните) на сообщение пользователя и напишите <code>Передать 1000</code>, "
            "либо укажите <code>Передать 1000 @username</code> или <code>ID</code>.",
            parse_mode=ParseMode.HTML,
        )
        return True

    if target_row["user_id"] == sender.id:
        await msg.reply_text("❌ Нельзя переводить звёзды самому себе.")
        return True

    if amount < TRANSFER_MIN_STARS:
        await msg.reply_text(
            f"❌ Минимальная сумма перевода — <b>{TRANSFER_MIN_STARS:,} ⭐</b>!",
            parse_mode=ParseMode.HTML,
        )
        return True

    if not deduct_user_stars(sender.id, amount):
        await msg.reply_text(
            f"❌ Недостаточно Stars на балансе! Ваш баланс: <b>{sender_db['balance_stars']:,} ⭐</b>.",
            parse_mode=ParseMode.HTML,
        )
        return True

    add_user_stars(target_row["user_id"], amount)
    receiver_name = normalize_telegram_name(target_row["first_name"], target_row["username"], target_row["user_id"])

    await msg.reply_text(
        f"💸 <b>Перевод выполнен!</b>\n"
        f"<b>{clean_html(sender.first_name)}</b> передал <b>{amount:,} ⭐</b> игроку <b>{clean_html(receiver_name)}</b>!",
        parse_mode=ParseMode.HTML,
    )

    try:
        await context.bot.send_message(
            chat_id=target_row["user_id"],
            text=(
                f"💸 <b>Вам поступил перевод!</b>\n\n"
                f"От игрока: <b>{clean_html(sender.first_name)}</b>\n"
                f"Сумма: <b>+{amount:,} ⭐</b>"
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=quick_nav_keyboard()
        )
    except Exception:
        pass

    return True

# ---------------------------------------------------------------------------
# ОБРАБОТКА В ЧАТАХ (ДРОПЫ NFT И КОМАНДЫ БЕЗ СЛЭША)
# ---------------------------------------------------------------------------

async def on_group_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.effective_message
    if msg is None:
        return

    # Если это инлайн-чек, отправленный в группу (подстраховка, если inlinefeedback отключён)
    if msg.via_bot and msg.reply_markup and msg.reply_markup.inline_keyboard:
        bot_id = getattr(context.bot, "id", None)
        if not bot_id or msg.via_bot.id == bot_id:
            for row in msg.reply_markup.inline_keyboard:
                for btn in row:
                    cb = getattr(btn, "callback_data", "") or ""
                    if cb.startswith("claim_check:"):
                        code = cb.split(":", 1)[1]
                        chk = get_star_check(code)
                        if chk and not chk["rendered"] and chk["status"] in ("draft", "active"):
                            ok, _, chk_active = activate_star_check_draft(code, chk["creator_id"])
                            if ok and chk_active:
                                creator_row = get_or_create_user(chk_active["creator_id"], "", "")
                                creator_name = normalize_telegram_name(
                                    creator_row["first_name"], creator_row["username"], chk_active["creator_id"]
                                )
                                target_lbl = (
                                    f"@{chk_active['target_username']}"
                                    if chk_active["target_username"]
                                    else "Все игроки"
                                )
                                cap = (
                                    f"💳 <b>Чек на {fmt_stars_compact(chk_active['amount_stars'])} ⭐</b>\n"
                                    f"━━━━━━━━━━━━━━━━━━\n"
                                    f"👤 От: <b>{clean_html(creator_name)}</b>\n"
                                    f"🎯 Получатель: <b>{clean_html(target_lbl)}</b>\n"
                                    f"💰 Сумма: <b>{fmt_stars_rub(chk_active['amount_stars'])}</b>"
                                )
                                kb = InlineKeyboardMarkup([[
                                    make_btn(
                                        f"💳 Активировать чек ({fmt_stars_compact(chk_active['amount_stars'])} ⭐)",
                                        style="success",
                                        callback_data=f"claim_check:{code}",
                                    )
                                ]])
                                try:
                                    if msg.photo:
                                        card_io = await generate_check_card_image(
                                            chk_active["amount_stars"], creator_name, target_lbl
                                        )
                                        await msg.edit_media(
                                            media=InputMediaPhoto(
                                                media=InputFile(card_io, filename=f"check_{code}.png"),
                                                caption=cap,
                                                parse_mode=ParseMode.HTML,
                                            ),
                                            reply_markup=kb,
                                        )
                                    else:
                                        await msg.edit_text(cap, parse_mode=ParseMode.HTML, reply_markup=kb)
                                    mark_star_check_rendered(code)
                                except Exception:
                                    pass
                        break

    if msg.text is None:
        return

    # 1. Сначала проверяем чат-команду "Передать ..."
    if await handle_chat_transfer(update, context):
        return

    text_raw = msg.text.strip()
    text_lower = text_raw.lower()

    if text_lower in ("кто я", "я", "профиль", "profile"):
        if not await check_access_allowed(update):
            return
        u = update.effective_user
        get_or_create_user(u.id, u.username or "", u.first_name or "")
        await show_profile_handler(update, u.id, context)
        return

    allowed_words = {"nft", "нфт", "подарок"}
    if text_lower not in allowed_words:
        return

    if not await check_access_allowed(update):
        return

    user = update.effective_user
    row = get_or_create_user(user.id, user.username or "", user.first_name or "")

    now = int(time.time())
    if COOLDOWN_ENABLED:
        remaining = row["last_drop_ts"] + COOLDOWN_SECONDS - now
        if remaining > 0:
            await msg.reply_text(f"⏳ Рано! Команду NFT можно использовать 1 раз в час.\nПопробуйте через {seconds_to_hms(remaining)}.")
            return

    set_last_drop(user.id, now)

    if random.random() > CHAT_DROP_CHANCE:
        await msg.reply_text("💨 В этот раз ничего не выпало! Попробуйте снова через 1 час.")
        return

    clan = get_user_clan(user.id)
    clan_bonus_pct = 0.0
    clan_note = ""
    if clan:
        _, _, _, _, clan_bonus_pct = calculate_clan_level_info(clan["xp"])
        clan_note = f"\n🛡 Бонус клана [{clan['tag']}]: <b>+{clan_bonus_pct}%</b> к выигрышу!"

    gift = roll_gift_from_pool(GIFTS, bonus_pct=clan_bonus_pct)
    drop_id = create_pending_drop(user.id, update.effective_chat.id, gift.key)

    keyboard = InlineKeyboardMarkup([
        [
            make_btn("💾 Сохранить в коллекцию", style="success", callback_data=f"keep:{drop_id}"),
            make_btn("💰 Продать за Stars", style="primary", callback_data=f"sell:{drop_id}"),
        ]
    ])

    caption = (
        f"🎉 <b>{clean_html(user.first_name)}</b>, вам выпал подарок!\n\n"
        f"<b>{gift.name}</b>\n"
        f"• Модель: <b>{gift.model_name}</b>\n"
        f"• Опыт: <b>+{gift.xp} XP</b>\n"
        f"• Ценность: {fmt_stars_rub(gift.stars)} / {fmt_ton(gift.ton)}"
        f"{clan_note}\n\n"
        f"Выберите действие ниже:"
    )

    try:
        card_io = await generate_gift_card_image(gift)
        if card_io:
            await msg.reply_photo(photo=InputFile(card_io, filename=f"gift_{gift.key}.png"), caption=caption, parse_mode=ParseMode.HTML, reply_markup=keyboard)
            return
    except Exception:
        pass

    img_path = gift_image_path(gift.key)
    if img_path:
        try:
            with open(img_path, "rb") as f:
                await msg.reply_photo(photo=InputFile(f, filename=img_path.name), caption=caption, parse_mode=ParseMode.HTML, reply_markup=keyboard)
            return
        except Exception:
            pass

    await msg.reply_text(caption, parse_mode=ParseMode.HTML, reply_markup=keyboard)

# ---------------------------------------------------------------------------
# ОБРАБОТЧИКИ CALLBACK QUERY
# ---------------------------------------------------------------------------

async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    data = query.data or ""
    user = query.from_user

    if data == "noop":
        await query.answer()
        return

    if not await check_access_allowed(update):
        return

    # Инлайн-чеки (работают в любом чате, query.message может быть None)
    if data.startswith("check_done:"):
        code = data.split(":", 1)[1]
        chk = get_star_check(code)
        if chk and chk["claimed_by"]:
            cl = get_or_create_user(chk["claimed_by"], "", "")
            cname = normalize_telegram_name(cl["first_name"], cl["username"], chk["claimed_by"])
            await query.answer(f"✅ Этот чек на {fmt_stars_compact(chk['amount_stars'])} ⭐ уже активировал {cname}.", show_alert=True)
        else:
            await query.answer("✅ Этот чек уже активирован.", show_alert=True)
        return

    if data.startswith("claim_check:"):
        code = data.split(":", 1)[1]
        get_or_create_user(user.id, user.username or "", user.first_name or "")
        ok, msg_txt, chk = claim_star_check_db(code, user.id, user.username or "")
        if not ok:
            await query.answer(f"❌ {msg_txt}", show_alert=True)
            return

        amount = chk["amount_stars"]
        claimer_name = normalize_telegram_name(user.first_name, user.username, user.id)
        creator_row = get_or_create_user(chk["creator_id"], "", "")
        creator_name = normalize_telegram_name(creator_row["first_name"], creator_row["username"], chk["creator_id"])
        target_lbl = f"@{chk['target_username']}" if chk["target_username"] else "Все игроки"

        await query.answer(f"🎉 Вы получили +{fmt_stars_compact(amount)} ⭐ по чеку!", show_alert=True)

        done_btn_text = f"✅ Активирован ({claimer_name[:18]})"
        done_kb = InlineKeyboardMarkup([[InlineKeyboardButton(done_btn_text, callback_data=f"check_done:{code}")]])
        new_cap = (
            f"✅ <b>Чек на {fmt_stars_compact(amount)} ⭐ активирован!</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"👤 От: <b>{clean_html(creator_name)}</b>\n"
            f"🎉 Получил: <b>{clean_html(claimer_name)}</b>\n"
            f"💰 Сумма: <b>{fmt_stars_rub(amount)}</b>"
        )
        claimed_io = await generate_check_card_image(
            amount_stars=amount,
            creator_name=creator_name,
            target_label=target_lbl,
            claimed_by=claimer_name,
        )

        if query.inline_message_id:
            try:
                await context.bot.edit_message_media(
                    inline_message_id=query.inline_message_id,
                    media=InputMediaPhoto(
                        media=InputFile(claimed_io, filename=f"check_{code}_claimed.png"),
                        caption=new_cap,
                        parse_mode=ParseMode.HTML,
                    ),
                    reply_markup=done_kb,
                )
            except Exception:
                try:
                    await context.bot.edit_message_caption(
                        inline_message_id=query.inline_message_id,
                        caption=new_cap,
                        parse_mode=ParseMode.HTML,
                        reply_markup=done_kb,
                    )
                except Exception:
                    try:
                        await context.bot.edit_message_text(
                            inline_message_id=query.inline_message_id,
                            text=new_cap,
                            parse_mode=ParseMode.HTML,
                            reply_markup=done_kb,
                        )
                    except Exception:
                        pass
        elif query.message:
            if query.message.photo:
                try:
                    await query.edit_message_media(
                        media=InputMediaPhoto(
                            media=InputFile(claimed_io, filename=f"check_{code}_claimed.png"),
                            caption=new_cap,
                            parse_mode=ParseMode.HTML,
                        ),
                        reply_markup=done_kb,
                    )
                except Exception:
                    try:
                        await query.edit_message_caption(caption=new_cap, parse_mode=ParseMode.HTML, reply_markup=done_kb)
                    except Exception:
                        pass
            else:
                try:
                    await query.edit_message_text(new_cap, parse_mode=ParseMode.HTML, reply_markup=done_kb)
                except Exception:
                    pass

        if chk["creator_id"] != user.id:
            try:
                await context.bot.send_message(
                    chat_id=chk["creator_id"],
                    text=(
                        f"💳 <b>Ваш чек на {fmt_stars_compact(amount)} ⭐ активирован!</b>\n"
                        f"Получатель: <b>{clean_html(claimer_name)}</b>"
                    ),
                    parse_mode=ParseMode.HTML,
                    reply_markup=quick_nav_keyboard(),
                )
            except Exception:
                pass
        return

    if data == "accept_privacy" or data.startswith("accept_privacy:"):
        get_or_create_user(user.id, user.username or "", user.first_name or "")
        accept_privacy_policy_db(user.id)
        await query.answer("✅ Политика конфиденциальности и условия приняты!")
        pending_arg = data.split(":", 1)[1].strip() if ":" in data else context.user_data.pop("pending_start_arg", "")
        context.user_data.pop("pending_start_arg", None)

        if pending_arg.startswith("lot_") and pending_arg[4:].isdigit():
            await show_market_lot_detail(query, int(pending_arg[4:]), user.id, context)
            if query.message:
                try: await query.message.delete()
                except Exception: pass
            return

        if pending_arg.startswith("profile_") and pending_arg[8:].isdigit():
            target_id = int(pending_arg[8:])
            target_row = get_user_by_target(str(target_id))
            if not target_row:
                try:
                    chat_info = await context.bot.get_chat(target_id)
                    if chat_info:
                        target_row = get_or_create_user(target_id, chat_info.username or "", chat_info.first_name or "")
                except Exception:
                    target_row = None
            if target_row:
                await show_profile_handler(query, target_id, context)
                if query.message:
                    try: await query.message.delete()
                    except Exception: pass
                return

        banner_img = await generate_main_menu_banner()
        chat_id = query.message.chat_id if query.message else user.id
        if query.message:
            try: await query.message.delete()
            except Exception: pass
        await context.bot.send_photo(
            chat_id=chat_id,
            photo=InputFile(banner_img, filename="menu.png"),
            caption=(
                f"👋 <b>Привет, {clean_html(user.first_name)}! Добро пожаловать в New NFT Bot!</b>\n\n"
                "Пишите слово <code>NFT</code> в группах, чтобы выбивать редчайшие Telegram Gifts! 🎁\n\n"
                "• Вступайте в кланы, качайте уровень клана и гербы\n"
                "• Отправляйте чеки на Stars прямо в любом чате (<code>@бот 5000</code>)\n"
                "• Передавайте звёзды и подарки командой <code>Передать</code> в чате\n"
                "• Кастомизируйте профиль уникальными фонами\n"
                "• Исследуйте NFT Маркет и соревнуйтесь в ТОП-100\n"
                f"• Поддержка: {SUPPORT_HANDLE}\n\n"
                "Используйте кнопки меню для комфортного управления:"
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_keyboard(user.id),
        )
        return

    # Защита приватных разделов в группах
    if query.message and query.message.chat.type != "private" and data in (
        "nav_cases_hub", "nav_top_page:1", "nav_settings", "nav_shop", "shop_slots_menu",
        "nav_clans_hub", "admin_panel", "admin_refresh", "nav_market", "market_create_offer", "market_my_offers",
        "market_history", "profile_upgrade_wip",
    ):
        await query.answer("⚠️ Откройте личные сообщения с ботом для этого меню!", show_alert=True)
        return

    if query.message and query.message.chat.type == "private":
        if not await ensure_privacy_accepted_private(update, context):
            return

    if data == "profile_upgrade_wip":
        await query.answer()
        await show_shop_page(query, user.id)
        return

    if data in ("admin_panel", "admin_refresh"):
        if user.id not in ADMIN_IDS:
            await query.answer("❌ Доступ запрещен!", show_alert=True)
            return
        await query.answer("🔄 Статистика обновлена!" if data == "admin_refresh" else None)
        await show_admin_panel(query)
        return

    if data == "admin_toggle_maintenance":
        if user.id not in ADMIN_IDS:
            await query.answer("❌ Доступ запрещен!", show_alert=True)
            return
        new_state = not is_maintenance_mode()
        set_maintenance_mode(new_state)
        status_alert = "🔴 Бот отключён (включены техработы)!" if new_state else "🟢 Бот снова включён и работает!"
        await query.answer(status_alert, show_alert=True)
        await show_admin_panel(query)
        return

    if data == "admin_firebase_menu":
        if user.id not in ADMIN_IDS:
            await query.answer("❌ Доступ запрещен!", show_alert=True)
            return
        await query.answer()
        await show_admin_firebase_menu(query)
        return

    if data == "admin_firebase_sync":
        if user.id not in ADMIN_IDS:
            await query.answer("❌ Доступ запрещен!", show_alert=True)
            return
        ok = firebase_manager.upload_db_to_cloud(force=True)
        if ok:
            await query.answer("✅ База base.db успешно сохранена в Cloud Firestore!", show_alert=True)
        else:
            await query.answer("❌ Ошибка синхронизации. Проверьте статус в меню или логи.", show_alert=True)
        await show_admin_firebase_menu(query)
        return

    if data == "admin_firebase_restore":
        if user.id not in ADMIN_IDS:
            await query.answer("❌ Доступ запрещен!", show_alert=True)
            return
        ok = firebase_manager.download_db_on_startup()
        if ok:
            await query.answer("📥 База base.db успешно восстановлена из Firestore!", show_alert=True)
        else:
            await query.answer("❌ Не удалось восстановить базу.", show_alert=True)
        await show_admin_firebase_menu(query)
        return

    # Чат-передача подарка через инлайн-кнопки
    if data.startswith("chat_gx_cancel:"):
        sender_id = int(data.split(":")[1])
        if user.id != sender_id:
            await query.answer("❌ Это не ваше меню передачи!", show_alert=True)
            return
        await query.answer("Отменено.")
        await query.edit_message_text("❌ Передача подарка отменена.")
        return

    if data.startswith("chat_gx_pg:"):
        _, sender_s, target_s, page_s = data.split(":")
        sender_id, target_id, page = int(sender_s), int(target_s), int(page_s)
        if user.id != sender_id:
            await query.answer("❌ Это не ваше меню передачи!", show_alert=True)
            return
        await query.answer()
        target_row = get_or_create_user(target_id, "", "")
        await show_chat_gift_picker(query.message, sender_id, target_row, page=page, edit_query=query)
        return

    if data.startswith("chat_gx_do:"):
        _, sender_s, target_s, item_s = data.split(":")
        sender_id, target_id, item_id = int(sender_s), int(target_s), int(item_s)
        if user.id != sender_id:
            await query.answer("❌ Это не ваше меню передачи!", show_alert=True)
            return
        ok, res = transfer_gift_between_users(sender_id, target_id, item_id)
        if not ok:
            await query.answer(f"❌ {res}", show_alert=True)
            return
        await query.answer("🎁 Подарок передан!")
        g = GIFTS_BY_KEY.get(res)
        g_name = g.name if g else res
        target_row = get_or_create_user(target_id, "", "")
        receiver_name = normalize_telegram_name(target_row["first_name"], target_row["username"], target_id)
        await query.edit_message_text(
            f"🎁 <b>Подарок передан!</b>\n"
            f"Игрок <b>{clean_html(user.first_name)}</b> передал <b>{clean_html(g_name)}</b> "
            f"игроку <b>{clean_html(receiver_name)}</b>!",
            parse_mode=ParseMode.HTML,
        )
        try:
            await context.bot.send_message(
                chat_id=target_id,
                text=f"🎁 <b>Вам передали подарок!</b>\nОт: <b>{clean_html(user.first_name)}</b>\nПодарок: <b>{clean_html(g_name)}</b>",
                parse_mode=ParseMode.HTML,
                reply_markup=quick_nav_keyboard(),
            )
        except Exception:
            pass
        return

    # Кланы
    if data == "nav_clans_hub":
        await query.answer()
        await show_clans_hub(query, user.id, context)
        return

    if data.startswith("clan_info:"):
        await query.answer()
        clan_id = int(data.split(":")[1])
        await show_clan_profile_handler(query, clan_id, context)
        return

    if data.startswith("clan_avatar_preset:"):
        await clan_avatar_preset_selected(update, context)
        return

    if data.startswith("clan_members_detail:"):
        await query.answer()
        clan_id = int(data.split(":")[1])
        await show_clan_members_detail(query, clan_id)
        return

    if data.startswith("clan_gifts_menu:"):
        await query.answer()
        parts = data.split(":")
        clan_id = int(parts[1])
        page = int(parts[2]) if len(parts) > 2 else 1
        await show_clan_gifts_menu(query, clan_id, page)
        return

    if data.startswith("clan_toggle_gift_fav:"):
        _, clan_s, cg_s, page_s = data.split(":")
        clan_id, cg_id, page = int(clan_s), int(cg_s), int(page_s)
        clan = get_clan_by_id(clan_id)
        if not clan or clan["owner_id"] != user.id:
            await query.answer("❌ Только создатель клана может управлять избранным!", show_alert=True)
            return
        ok, msg_txt = toggle_clan_gift_favorite(clan_id, cg_id)
        await query.answer(msg_txt, show_alert=not ok)
        await show_clan_gifts_menu(query, clan_id, page)
        return

    if data.startswith("clan_donate_gift_menu:"):
        await query.answer()
        parts = data.split(":")
        clan_id = int(parts[1])
        page = int(parts[2]) if len(parts) > 2 else 1
        await show_clan_donate_gift_menu(query, clan_id, user.id, page)
        return

    if data.startswith("clan_donate_gift_confirm:"):
        await query.answer()
        _, clan_s, item_s = data.split(":")
        await show_clan_donate_gift_confirm(query, int(clan_s), int(item_s), user.id)
        return

    if data.startswith("clan_donate_gift_do:"):
        _, clan_id_str, item_id_str = data.split(":")
        await execute_clan_donate_gift(query, int(clan_id_str), int(item_id_str), user.id, context)
        return

    # Админ-выдача подарков по фильтрам
    if data.startswith("adm_filt_price:"):
        await query.answer()
        await show_admin_nft_price_tiers(query, int(data.split(":")[1]))
        return

    if data.startswith("adm_filt_model:"):
        await query.answer()
        await show_admin_nft_model_groups(query, int(data.split(":")[1]))
        return

    if data.startswith("adm_back_filters:"):
        await query.answer()
        target_id = int(data.split(":")[1])
        target = get_user_by_target(str(target_id))
        tname = normalize_telegram_name(
            target["first_name"] if target else None,
            target["username"] if target else None,
            target_id,
        )
        await show_admin_nft_filter_selector(query, target_id, tname)
        return

    if data.startswith("adm_items:"):
        await query.answer()
        _, ftype, fkey, target_id, page = data.split(":")
        await show_admin_nft_items_page(query, ftype, fkey, int(target_id), int(page))
        return

    if data.startswith("adm_give_do:"):
        _, gift_key, target_id = data.split(":")
        await execute_admin_give_nft(query, gift_key, int(target_id), context)
        return

    # Улучшения Plush Pepe
    if data == "shop_slots_menu":
        await query.answer()
        await show_shop_slots_menu(query, user.id)
        return

    if data.startswith("upgrade_item:"):
        await query.answer()
        item_id = int(data.split(":")[1])
        await show_gift_upgrade_confirm(query, user.id, item_id)
        return

    if data.startswith("upgrade_confirm:"):
        item_id = int(data.split(":")[1])
        await execute_gift_upgrade(query, user.id, item_id, context)
        return

    # Маркет
    if data == "market_filter_price_menu":
        await query.answer()
        await show_market_filter_price_menu(query)
        return

    if data == "market_filter_rarity_menu":
        await query.answer()
        await show_market_filter_rarity_menu(query)
        return

    if data.startswith("market_filter_model_menu"):
        await query.answer()
        page = int(data.split(":")[1]) if ":" in data else 1
        await show_market_filter_model_menu(query, page)
        return

    if data.startswith("market_view:"):
        await query.answer()
        _, ftype, fkey, page = data.split(":")
        await show_market_view_page(query, ftype, fkey, int(page))
        return

    if data == "market_create_offer":
        await query.answer()
        await show_market_create_offer_list(query, user.id, 1)
        return

    if data.startswith("market_create_offer_pg:"):
        await query.answer()
        page = int(data.split(":")[1])
        await show_market_create_offer_list(query, user.id, page)
        return

    if data == "market_my_offers":
        await query.answer()
        await show_market_my_offers(query, user.id)
        return

    if data == "market_history":
        await query.answer()
        await show_market_history(query, user.id)
        return

    if data.startswith("market_lot:"):
        await query.answer()
        listing_id = int(data.split(":")[1])
        await show_market_lot_detail(query, listing_id, user.id, context)
        return

    if data.startswith("market_cancel_lot:"):
        listing_id = int(data.split(":")[1])
        ok, msg_txt = cancel_market_listing(user.id, listing_id)
        await query.answer(msg_txt, show_alert=True)
        await show_market_my_offers(query, user.id)
        return

    if data.startswith("market_buy:"):
        listing_id = int(data.split(":")[1])
        ok, msg_txt, info = buy_market_listing(user.id, listing_id)
        if not ok or not info:
            await query.answer(f"❌ {msg_txt}", show_alert=True)
            return

        await query.answer("🎉 Покупка совершена!")
        m = PLUSHPEPE_MODELS_BY_NAME.get(info["model_name"]) or PLUSHPEPE_MODELS[0]
        b = BACKDROPS_BY_KEY.get(info["backdrop_key"]) or PLUSHPEPE_BACKDROPS[0]
        buyer_name = normalize_telegram_name(user.first_name, user.username, user.id)

        try:
            await context.bot.send_message(
                chat_id=info["seller_id"],
                text=(
                    f"💰 <b>Ваш лот #{info['listing_id']} продан на NFT Маркете!</b>\n"
                    f"━━━━━━━━━━━━━━━━━━\n"
                    f"🐸 Модель: <b>{clean_html(m.name)}</b>\n"
                    f"🎨 Фон: <b>{clean_html(b.name)}</b>\n"
                    f"👤 Покупатель: <b>{clean_html(buyer_name)}</b>\n"
                    f"💳 Цена лота: <b>{info['price_stars']:,} ⭐</b>\n"
                    f"📉 Комиссия 15%: <b>-{info['fee_stars']:,} ⭐</b>\n"
                    f"✅ Зачислено на баланс: <b>+{info['seller_gets']:,} ⭐</b>"
                ),
                parse_mode=ParseMode.HTML,
                reply_markup=quick_nav_keyboard(),
            )
        except Exception:
            pass

        cap = (
            f"🎉 <b>Поздравляем с покупкой на NFT Маркете!</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"🐸 Plush Pepe #{info['upgrade_num']} • <b>{clean_html(m.name)}</b>\n"
            f"🎨 Фон: <b>{clean_html(b.name)}</b> ({b.rarity_label})\n"
            f"💳 Оплачено: <b>{info['price_stars']:,} ⭐</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"Подарок уже добавлен в вашу коллекцию!"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🗂 В коллекцию", callback_data="nav_collection_page:1")],
            [InlineKeyboardButton("🛒 Вернуться в маркет", callback_data="nav_market")],
        ])
        if query.message.photo:
            await query.edit_message_caption(caption=cap, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text(cap, parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    if data == "nav_main":
        await query.answer()
        banner_img = await generate_main_menu_banner()
        if query.message.photo:
            try: await query.message.delete()
            except Exception: pass
        await query.message.reply_photo(
            photo=InputFile(banner_img, filename="menu.png"),
            caption="🏠 <b>Главное меню New NFT Bot:</b>\nВыберите нужный раздел кнопками ниже:",
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_keyboard(user.id)
        )
        return

    if data == "nav_profile":
        await query.answer()
        get_or_create_user(user.id, user.username or "", user.first_name or "")
        await show_profile_handler(query, user.id, context)
        return

    if data == "nav_info":
        await query.answer()
        await show_info_page(query, context)
        return

    if data == "info_group_guide":
        await query.answer()
        await show_group_guide(query, context)
        return

    if data == "info_privacy":
        await query.answer()
        await show_privacy_policy(query)
        return

    if data == "info_rules":
        await query.answer()
        await show_rules_page(query)
        return

    if data == "nav_market":
        await query.answer()
        await show_market_hub(query)
        return

    if data == "bg_reset":
        await bg_reset_handler(query, user.id, context)
        return

    if data == "nav_settings":
        await query.answer()
        await show_settings_page(query, user.id)
        return

    if data == "nav_shop":
        await query.answer()
        await show_shop_page(query, user.id)
        return

    if data.startswith("nav_collection_page:"):
        await query.answer()
        page = int(data.split(":")[1])
        await show_collection_page(query, user.id, page)
        return

    if data.startswith("nav_top_page:"):
        await query.answer()
        page = int(data.split(":")[1])
        await show_top_page(query, page)
        return

    if data.startswith("clan_list:"):
        await query.answer()
        page = int(data.split(":")[1])
        await show_clans_list(query, page)
        return

    if data.startswith("clan_join:"):
        clan_id = int(data.split(":")[1])
        if get_user_clan(user.id):
            await query.answer("Вы уже состоите в клане!", show_alert=True)
            return
        if add_user_to_clan(user.id, clan_id):
            await query.answer("🎉 Вы успешно вступили в клан!", show_alert=True)
            await show_clan_profile_handler(query, clan_id, context)
        else:
            await query.answer("❌ В клане нет свободных мест!", show_alert=True)
        return

    if data.startswith("clan_join_stars:"):
        clan_id = int(data.split(":")[1])
        clan = get_clan_by_id(clan_id)
        if get_user_clan(user.id):
            await query.answer("Вы уже состоите в клане!", show_alert=True)
            return

        if not deduct_user_stars(user.id, clan["entry_fee"]):
            await query.answer(f"❌ Недостаточно Stars! Нужно {clan['entry_fee']} ⭐", show_alert=True)
            return

        add_user_stars(clan["owner_id"], clan["entry_fee"])
        add_user_to_clan(user.id, clan_id)
        await query.answer("🎉 Вы вступили в клан за Stars!", show_alert=True)
        await show_clan_profile_handler(query, clan_id, context)
        return

    if data.startswith("clan_apply:"):
        clan_id = int(data.split(":")[1])
        if add_clan_request(clan_id, user.id):
            await query.answer("📩 Заявка отправлена лидеру клана!", show_alert=True)
        else:
            await query.answer("⚠️ Вы уже подавали заявку!", show_alert=True)
        return

    if data.startswith("clan_kick:"):
        target_id = int(data.split(":")[1])
        clan = get_user_clan(user.id)
        if clan and clan["owner_id"] == user.id:
            remove_user_from_clan(target_id)
            await query.answer("Игрок исключён из клана.")
            await show_clan_members_detail(query, clan["id"])
        return

    if data.startswith("clan_leave:"):
        remove_user_from_clan(user.id)
        await query.answer("Вы покинули клан.")
        await show_clans_hub(query, user.id, context)
        return

    if data.startswith("clan_delete_confirm:"):
        await query.answer()
        clan_id = int(data.split(":")[1])
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔥 Да, расформировать", callback_data=f"clan_delete_do:{clan_id}")],
            [InlineKeyboardButton("❌ Отмена", callback_data=f"clan_info:{clan_id}")]
        ])
        if query.message.photo:
            await query.message.delete()
            await query.message.reply_text("⚠️ Вы действительно хотите <b>РАСФОРМИРОВАТЬ</b> клан?", parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text("⚠️ Вы действительно хотите <b>РАСФОРМИРОВАТЬ</b> клан?", parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    if data.startswith("clan_delete_do:"):
        clan_id = int(data.split(":")[1])
        delete_clan(clan_id)
        await query.answer("Клан расформирован.")
        await show_clans_hub(query, user.id, context)
        return

    if data.startswith("clan_upgrade:"):
        clan_id = int(data.split(":")[1])
        clan = get_clan_by_id(clan_id)
        cost = get_clan_upgrade_cost(clan["max_members"])

        ok, msg_info = upgrade_clan_slots(clan_id, cost)
        if ok:
            await query.answer(f"🎉 Места расширены до {clan['max_members']+15} ({msg_info})!", show_alert=True)
            await show_clan_profile_handler(query, clan_id, context)
        else:
            await query.answer(f"❌ {msg_info}", show_alert=True)
        return

    if data.startswith("clan_requests:"):
        await query.answer()
        clan_id = int(data.split(":")[1])
        reqs = get_clan_requests(clan_id)
        text = f"📩 <b>Заявки в клан ({len(reqs)}):</b>\n\n"
        buttons = []

        for r in reqs:
            name = normalize_telegram_name(r["first_name"], r["username"], r["user_id"])
            buttons.append([
                make_btn(f"✅ Принять {name[:10]}", style="success", callback_data=f"clan_req_accept:{clan_id}:{r['user_id']}"),
                make_btn("❌ Отклонить", style="danger", callback_data=f"clan_req_decline:{clan_id}:{r['user_id']}")
            ])

        buttons.append([InlineKeyboardButton("⬅️ В профиль клана", callback_data=f"clan_info:{clan_id}")])
        kb = InlineKeyboardMarkup(buttons)
        if query.message.photo:
            await query.message.delete()
            await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    if data.startswith("clan_req_accept:"):
        _, clan_id, req_user_id = data.split(":")
        if add_user_to_clan(int(req_user_id), int(clan_id)):
            await query.answer("Игрок принят в клан!")
        else:
            await query.answer("Нет свободных мест!", show_alert=True)
        await show_clan_profile_handler(query, int(clan_id), context)
        return

    if data.startswith("clan_req_decline:"):
        _, clan_id, req_user_id = data.split(":")
        remove_clan_request(int(clan_id), int(req_user_id))
        await query.answer("Заявка отклонена.")
        await show_clan_profile_handler(query, int(clan_id), context)
        return

    if data.startswith("toggle_set:"):
        await query.answer()
        field = data.split(":", 1)[1]
        toggle_user_setting(user.id, field)
        await show_settings_page(query, user.id)
        return

    if data.startswith("buy_slots:"):
        _, slots_str, cost_str = data.split(":")
        slots, cost = int(slots_str), int(cost_str)
        if upgrade_inventory_capacity(user.id, cost, slots):
            await query.answer(f"✅ Куплено +{slots} слотов!", show_alert=True)
            await show_shop_page(query, user.id)
        else:
            await query.answer("❌ Недостаточно Stars!", show_alert=True)
        return

    if data == "sell_all_confirm":
        await query.answer()
        kb = InlineKeyboardMarkup([
            [
                make_btn("✅ Продать все", style="success", callback_data="sell_all_do"),
                make_btn("❌ Отмена", style="danger", callback_data="nav_collection_page:1"),
            ]
        ])
        await query.edit_message_text("⚠️ <b>Продать все обычные предметы из коллекции?</b>\nИзбранные (⭐) затронуты не будут.", parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    if data == "sell_all_do":
        count, stars = sell_all_non_favorites(user.id)
        await query.answer(f"💰 Продано {count} предметов за {stars:,} Stars!", show_alert=True)
        await show_collection_page(query, user.id, 1)
        return

    if data == "nav_bonus":
        await query.answer()
        remaining = claim_daily_bonus(user.id)
        if remaining is None:
            text = "🎁 <b>Ежедневный бонус получен:</b> <b>+50 Stars ⭐</b> и <b>+250 XP ⚡️</b>!"
        else:
            text = f"⏳ Бонус уже был получен сегодня.\nПопробуйте снова через {seconds_to_hms(remaining)}."

        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("🗂 В коллекцию", callback_data="nav_collection_page:1")],
            [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")]
        ])
        if query.message.photo:
            await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    if data == "nav_cases_hub":
        await query.answer()
        db_user = get_or_create_user(user.id, "", "")
        text = (
            f"🎰 <b>Mystery Cases Hub</b>\n\n"
            f"Ваш баланс: <b>{fmt_stars_rub(db_user['balance_stars'])}</b>\n\n"
            f"1. 📦 <b>Кейс 1</b> — 100 ⭐\n"
            f"2. 🔷 <b>Кейс 2</b> — 500 ⭐\n"
            f"3. 🟣 <b>Кейс 3</b> — 2,500 ⭐\n"
            f"4. 👑 <b>Кейс 4</b> — 10,000 ⭐\n"
        )
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📦 Кейс 1 (100⭐)", callback_data="open_case:tier1")],
            [InlineKeyboardButton("🔷 Кейс 2 (500⭐)", callback_data="open_case:tier2")],
            [InlineKeyboardButton("🟣 Кейс 3 (2500⭐)", callback_data="open_case:tier3")],
            [InlineKeyboardButton("👑 Кейс 4 (10000⭐)", callback_data="open_case:tier4")],
            [
                InlineKeyboardButton("🗂 Коллекция", callback_data="nav_collection_page:1"),
                InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
            ],
        ])
        if query.message.photo:
            await query.message.delete()
            await query.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await query.edit_message_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    if data.startswith("open_case:"):
        tier_key = data.split(":")[1]
        tier = CASE_TIERS.get(tier_key)
        if not tier:
            await query.answer()
            return

        db_user = get_or_create_user(user.id, "", "")
        if not deduct_user_stars(user.id, tier["price"]):
            await query.answer(f"❌ Недостаточно Stars! Цена: {tier['price']}⭐", show_alert=True)
            return

        await query.answer()
        clan = get_user_clan(user.id)
        clan_bonus_pct = 0.0
        if clan:
            _, _, _, _, clan_bonus_pct = calculate_clan_level_info(clan["xp"])

        won_gift = roll_gift_from_pool(tier["pool"], bonus_pct=clan_bonus_pct)

        if db_user["auto_sell"]:
            add_user_stars(user.id, won_gift.stars)
            res_note = f"💰 <b>Авто-продажа:</b> +{fmt_stars_rub(won_gift.stars)}!"
        else:
            success = add_to_collection(user.id, won_gift.key)
            if not success:
                add_user_stars(user.id, won_gift.stars)
                res_note = f"⚠️ Инвентарь переполнен! Авто-продажа за {fmt_stars_rub(won_gift.stars)}."
            else:
                res_note = f"✅ Сохранено в коллекцию! (+{won_gift.xp} XP)"

        cap = (
            f"🎰 <b>Открытие {tier['name']}!</b>\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"🎉 Выпал: <b>{won_gift.name}</b>!\n"
            f"• Модель: <b>{won_gift.model_name}</b>\n"
            f"• Ценность: <b>{fmt_stars_rub(won_gift.stars)}</b>\n\n"
            f"{res_note}"
        )

        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton(f"🎰 Еще раз ({tier['price']}⭐)", callback_data=f"open_case:{tier_key}")],
            [InlineKeyboardButton("🎰 К кейсам", callback_data="nav_cases_hub")],
            [InlineKeyboardButton("🗂 В коллекцию", callback_data="nav_collection_page:1")],
            [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")],
        ])

        try:
            card_io = await generate_gift_card_image(won_gift)
            if card_io:
                await query.message.reply_photo(photo=InputFile(card_io, filename=f"gift_{won_gift.key}.png"), caption=cap, parse_mode=ParseMode.HTML, reply_markup=kb)
                if query.message: await query.message.delete()
                return
        except Exception: pass

        img_p = gift_image_path(won_gift.key)
        if img_p:
            try:
                with open(img_p, "rb") as f:
                    await query.message.reply_photo(photo=InputFile(f, filename=img_p.name), caption=cap, parse_mode=ParseMode.HTML, reply_markup=kb)
                if query.message: await query.message.delete()
                return
            except Exception: pass

        await query.message.reply_text(cap, parse_mode=ParseMode.HTML, reply_markup=kb)
        return

    if ":" in data:
        action, *rest = data.split(":")

        if action in ("keep", "sell"):
            drop_id = int(rest[0])
            drop = get_pending_drop(drop_id)
            if not drop or drop["user_id"] != user.id:
                await query.answer("❌ Это не ваш подарок!", show_alert=True)
                return
            if drop["resolved"]:
                await query.answer("⚠️ Уже обработано!", show_alert=True)
                return

            await query.answer()
            gift = GIFTS_BY_KEY.get(drop["gift_key"])
            resolve_pending_drop(drop_id)

            if action == "keep":
                added = add_to_collection(user.id, gift.key)
                if added:
                    res = f"✅ <b>{gift.name}</b> сохранён в коллекцию! (+{gift.xp} XP)"
                else:
                    sell_from_pending(user.id, gift.key, gift.stars)
                    res = f"⚠️ Инвентарь переполнен! <b>{gift.name}</b> продан за {fmt_stars_rub(gift.stars)}!"
            else:
                sell_from_pending(user.id, gift.key, gift.stars)
                res = f"💰 Продано <b>{gift.name}</b> за {fmt_stars_rub(gift.stars)}! (+{gift.xp // 2} XP)"

            kb = quick_nav_keyboard()
            if query.message.photo:
                await query.edit_message_caption(caption=res, parse_mode=ParseMode.HTML, reply_markup=kb)
            else:
                await query.edit_message_text(res, parse_mode=ParseMode.HTML, reply_markup=kb)
            return

        if action == "view_top_user":
            target_id = int(rest[0])
            back_page = int(rest[1])
            target = get_or_create_user(target_id, "", "")

            if target["hide_top"] and user.id not in ADMIN_IDS:
                await query.answer("🔒 Профиль скрыт настройками приватности игрока.", show_alert=True)
                return

            await query.answer()
            await show_profile_handler(query, target_id, context, back_to_top_page=back_page)
            return

        if action == "view_item":
            item_id = int(rest[0])
            page = int(rest[1]) if len(rest) > 1 else 1
            item = get_collection_item(item_id)
            if not item or item["user_id"] != user.id:
                await query.answer("Предмет не найден.", show_alert=True)
                return

            await query.answer()
            g = GIFTS_BY_KEY.get(item["gift_key"])
            fav_text = "❌ Убрать из Избранного" if item["is_favorite"] else "⭐ В избранное"
            val_stars = get_item_display_value(item)

            if item["is_upgraded"]:
                m = PLUSHPEPE_MODELS_BY_NAME.get(item["model_name"]) or PLUSHPEPE_MODELS[0]
                b = BACKDROPS_BY_KEY.get(item["backdrop_key"]) or PLUSHPEPE_BACKDROPS[0]
                is_mono, mono_fam = get_monochrome_combo_info(m.name, b.key)
                card_io = await generate_upgraded_gift_image(m, b, item["upgrade_num"], val_stars)

                buttons = []
                if item["is_listed"]:
                    active_lot = get_active_listing_by_collection_id(item_id)
                    if active_lot:
                        bot_username = await get_bot_username(context.bot)
                        lot_link = f"https://t.me/{bot_username}?start=lot_{active_lot['id']}"
                        up_num_val = item["upgrade_num"]
                        lot_price_txt = fmt_stars_compact(active_lot["price_stars"])
                        share_text = f"🐸 Plush Pepe #{up_num_val} на NFT Маркете за {lot_price_txt} ⭐!"
                        share_url = (
                            f"https://t.me/share/url?url={urllib.parse.quote(lot_link)}"
                            f"&text={urllib.parse.quote(share_text)}"
                        )
                        buttons.append([make_btn(f"🔎 Открыть лот #{active_lot['id']}", style="primary", callback_data=f"market_lot:{active_lot['id']}")])
                        buttons.append([make_btn("🔗 Поделиться подарком", style="primary", url=share_url)])
                    buttons.append([InlineKeyboardButton("🔍 В мои лоты маркета", callback_data="market_my_offers")])
                else:
                    buttons.append([make_btn("🛒 Выставить на маркет", style="primary", callback_data=f"market_sell_start:{item_id}")])
                    buttons.append([InlineKeyboardButton("🎁 Передать бесплатно", callback_data=f"gift_transfer_start:{item_id}")])
                    buttons.append([InlineKeyboardButton(fav_text, callback_data=f"toggle_fav:{item_id}:{page}")])
                buttons.append([
                    InlineKeyboardButton("🗂 Назад в коллекцию", callback_data=f"nav_collection_page:{page}"),
                    InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
                ])
                kb = InlineKeyboardMarkup(buttons)

                status_str = "🛒 Выставлен на маркете" if item["is_listed"] else "📦 В коллекции"
                mono_line = f"\n🌈 Комбо: <b>MONOCHROME x6</b> ({COLOR_FAMILY_RU.get(mono_fam, mono_fam)})" if is_mono else ""
                cap = (
                    f"✨ <b>Plush Pepe #{item['upgrade_num']}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━\n"
                    f"🐸 Модель: <b>{clean_html(m.name)}</b> (шанс {m.chance_pct}%)\n"
                    f"🎨 Фон: <b>{clean_html(b.name)}</b> • <i>{b.rarity_label}</i> ({b.chance_pct}%){mono_line}\n"
                    f"💎 Оценочная ценность: {fmt_stars_rub(val_stars)}\n"
                    f"📌 Статус: <b>{status_str}</b>\n"
                    f"⭐️ В Избранном: <b>{'Да ⭐' if item['is_favorite'] else 'Нет'}</b>\n"
                    f"━━━━━━━━━━━━━━━━━━"
                )
                try:
                    await query.message.reply_photo(
                        photo=InputFile(card_io, filename=f"plushpepe_{item['upgrade_num']}.png"),
                        caption=cap,
                        parse_mode=ParseMode.HTML,
                        reply_markup=kb,
                    )
                    await query.message.delete()
                    return
                except Exception:
                    pass
                await query.edit_message_text(cap, parse_mode=ParseMode.HTML, reply_markup=kb)
                return

            buttons = []
            if g and g.key == "pepe_heart":
                buttons.append([make_btn(f"✨ Улучшить ({UPGRADE_COST_STARS:,} ⭐)", style="primary", callback_data=f"upgrade_item:{item_id}")])
            buttons.append([InlineKeyboardButton("🎁 Передать бесплатно", callback_data=f"gift_transfer_start:{item_id}")])
            buttons.append([InlineKeyboardButton(fav_text, callback_data=f"toggle_fav:{item_id}:{page}")])
            buttons.append([InlineKeyboardButton(f"💰 Продать за {fmt_stars_compact(g.stars)} Stars", callback_data=f"sell_item:{item_id}:{page}")])
            buttons.append([
                InlineKeyboardButton("🗂 Назад в коллекцию", callback_data=f"nav_collection_page:{page}"),
                InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")
            ])
            kb = InlineKeyboardMarkup(buttons)

            cap = (
                f"<b>{g.name}</b>\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"• Модель: <b>{g.model_name}</b>\n"
                f"• Бонус опыта: <b>+{g.xp} XP</b>\n"
                f"• Стоимость: {fmt_stars_rub(g.stars)}\n"
                f"• В Избранном: <b>{'Да ⭐' if item['is_favorite'] else 'Нет'}</b>\n"
                f"━━━━━━━━━━━━━━━━━━"
            )

            try:
                card_io = await generate_gift_card_image(g)
                if card_io:
                    await query.message.reply_photo(photo=InputFile(card_io, filename=f"gift_{g.key}.png"), caption=cap, parse_mode=ParseMode.HTML, reply_markup=kb)
                    await query.message.delete()
                    return
            except Exception: pass

            img_p = gift_image_path(g.key)
            if img_p:
                try:
                    with open(img_p, "rb") as f:
                        await query.message.reply_photo(photo=InputFile(f, filename=img_p.name), caption=cap, parse_mode=ParseMode.HTML, reply_markup=kb)
                    await query.message.delete()
                    return
                except Exception: pass

            await query.edit_message_text(cap, parse_mode=ParseMode.HTML, reply_markup=kb)
            return

        if action == "toggle_fav":
            item_id = int(rest[0])
            page = int(rest[1]) if len(rest) > 1 else 1
            if toggle_favorite(item_id, user.id):
                await query.answer("Избранное обновлено!")
                await show_collection_page(query, user.id, page)
            else:
                await query.answer("Максимум 7 предметов в Избранном!", show_alert=True)
            return

        if action == "sell_item":
            item_id = int(rest[0])
            page = int(rest[1]) if len(rest) > 1 else 1
            item = get_collection_item(item_id)
            if not item or item["user_id"] != user.id:
                await query.answer("Ошибка продажи.", show_alert=True)
                return
            if item["is_listed"]:
                await query.answer("❌ Сначала снимите подарок с маркета!", show_alert=True)
                return
            if item["is_upgraded"]:
                await query.answer("❌ Улучшенные NFT нельзя продавать боту — их можно продать только на NFT Маркете!", show_alert=True)
                return

            val_stars = get_item_display_value(item)
            remove_from_collection(item_id, user.id)
            add_user_stars(user.id, val_stars)

            await query.answer(f"💰 Продано за {fmt_stars_compact(val_stars)} Stars!", show_alert=True)
            await show_collection_page(query, user.id, page)
            return

    await query.answer()

# ---------------------------------------------------------------------------
# КОМАНДЫ БОТА
# ---------------------------------------------------------------------------

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await check_access_allowed(update):
        return
    user = update.effective_user
    get_or_create_user(user.id, user.username or "", user.first_name or "")

    pending_arg = context.args[0].strip() if context.args else ""
    if not await ensure_privacy_accepted_private(update, context, pending_arg=pending_arg):
        return

    # Обработка диплинков (?start=lot_123 и ?start=profile_456)
    if context.args:
        arg = context.args[0].strip()
        if arg.startswith("lot_") and arg[4:].isdigit():
            await show_market_lot_detail(update, int(arg[4:]), user.id, context)
            return
        if arg.startswith("profile_") and arg[8:].isdigit():
            target_id = int(arg[8:])
            target_row = get_user_by_target(str(target_id))
            if not target_row:
                try:
                    chat_info = await context.bot.get_chat(target_id)
                    if chat_info:
                        target_row = get_or_create_user(target_id, chat_info.username or "", chat_info.first_name or "")
                except Exception:
                    target_row = None
            if target_row:
                await show_profile_handler(update, target_id, context)
            else:
                await update.message.reply_text("❌ Профиль игрока не найден.", reply_markup=quick_nav_keyboard())
            return

    banner_img = await generate_main_menu_banner()
    await update.message.reply_photo(
        photo=InputFile(banner_img, filename="menu.png"),
        caption=(
            f"👋 <b>Привет, {clean_html(user.first_name)}! Добро пожаловать в New NFT Bot!</b>\n\n"
            "Пишите слово <code>NFT</code> в группах, чтобы выбивать редчайшие Telegram Gifts! 🎁\n\n"
            "• Вступайте в кланы, качайте уровень клана и гербы\n"
            "• Отправляйте чеки на Stars прямо в любом чате (<code>@бот 5000</code>)\n"
            "• Передавайте звёзды и подарки командой <code>Передать</code> в чате\n"
            "• Кастомизируйте профиль уникальными фонами\n"
            "• Исследуйте NFT Маркет и соревнуйтесь в ТОП-100\n"
            f"• Поддержка: {SUPPORT_HANDLE}\n\n"
            "Используйте кнопки меню для комфортного управления:"
        ),
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu_keyboard(user.id)
    )

async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await check_access_allowed(update):
        return
    if not await ensure_privacy_accepted_private(update, context):
        return
    await show_info_page(update, context)

async def cmd_profile_alias(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await check_access_allowed(update):
        return
    if not await ensure_privacy_accepted_private(update, context):
        return
    u = update.effective_user
    get_or_create_user(u.id, u.username or "", u.first_name or "")
    await show_profile_handler(update, u.id, context)

async def cmd_clans(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await check_access_allowed(update):
        return
    if not await ensure_privacy_accepted_private(update, context):
        return
    await show_clans_hub(update, update.effective_user.id, context)

async def cmd_market(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await check_access_allowed(update):
        return
    if not await ensure_privacy_accepted_private(update, context):
        return
    await show_market_hub(update)

async def cmd_info(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await check_access_allowed(update):
        return
    if not await ensure_privacy_accepted_private(update, context):
        return
    await show_info_page(update, context)

async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.effective_user.id not in ADMIN_IDS:
        if is_maintenance_mode():
            await update.message.reply_text(MAINTENANCE_MESSAGE, parse_mode=ParseMode.HTML)
            return
        await update.message.reply_text("❌ У вас нет прав администратора.")
        return

    conn = db_connect()
    try:
        total_users = conn.execute("SELECT COUNT(*) as cnt FROM users").fetchone()["cnt"]
        total_banned = conn.execute("SELECT COUNT(*) as cnt FROM users WHERE is_banned=1").fetchone()["cnt"]
        total_collection_gifts = conn.execute("SELECT COUNT(*) as cnt FROM collection").fetchone()["cnt"]
        total_sold = conn.execute("SELECT SUM(total_sold) as s FROM users").fetchone()["s"] or 0
        total_drops = conn.execute("SELECT SUM(total_drops) as s FROM users").fetchone()["s"] or 0
        total_stars_capital = conn.execute("SELECT SUM(balance_stars) as s FROM users").fetchone()["s"] or 0
        total_clans = conn.execute("SELECT COUNT(*) as cnt FROM clans").fetchone()["cnt"]
    finally:
        conn.close()

    maint_on = is_maintenance_mode()
    maint_status = "🔴 ОТКЛЮЧЁН (Техработы)" if maint_on else "🟢 ВКЛЮЧЁН (Работает)"
    maint_btn_text = "🟢 Включить бота (Отключить техработы)" if maint_on else "🔴 Отключить бота (Техработы)"
    maint_style = "success" if maint_on else "danger"
    now_str = datetime.datetime.now().strftime("%H:%M:%S")

    text = (
        "👑 <b>Панель управления администратора</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"⚙️ Статус бота: <b>{maint_status}</b>\n"
        f"👥 Зарегистрировано игроков: <b>{total_users:,}</b>\n"
        f"⛔️ Заблокировано игроков: <b>{total_banned:,}</b>\n"
        f"🛡 Создано кланов: <b>{total_clans:,}</b>\n"
        f"💰 Совокупный баланс игроков: <b>{fmt_stars_compact(total_stars_capital)} ⭐</b>\n"
        f"🎁 Подарков в коллекциях: <b>{total_collection_gifts:,}</b>\n"
        f"🎰 Всего выбито подарков: <b>{total_drops:,}</b>\n"
        f"🛍 Продано предметов: <b>{total_sold:,}</b>\n"
        f"🕒 Обновлено: <code>{now_str}</code>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "Выберите действие:"
    )
    kb = InlineKeyboardMarkup([
        [make_btn(maint_btn_text, style=maint_style, callback_data="admin_toggle_maintenance")],
        [make_btn("🔄 Обновить", style="primary", callback_data="admin_refresh")],
        [InlineKeyboardButton("⭐ Выдать Звёзды игроку", callback_data="admin_give_stars_start")],
        [InlineKeyboardButton("🎁 Выдать NFT-подарок (фильтры)", callback_data="admin_give_nft_start")],
        [
            make_btn("🔨 Забанить игрока", style="danger", callback_data="admin_ban_start"),
            make_btn("🔓 Разбанить игрока", style="success", callback_data="admin_unban_start"),
        ],
        [InlineKeyboardButton("☁️ Firebase Облако (base.db)", callback_data="admin_firebase_menu")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="nav_main")],
    ])
    await update.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)

async def cmd_pay(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await check_access_allowed(update):
        return
    if not await ensure_privacy_accepted_private(update, context):
        return
    sender = update.effective_user
    sender_db = get_or_create_user(sender.id, sender.username or "", sender.first_name or "")
    lvl, _, _, _ = calculate_xp_level_info(sender_db["xp"])
    if lvl < TRANSFER_MIN_LEVEL:
        await update.message.reply_text(f"❌ Переводить звёзды можно только с {TRANSFER_MIN_LEVEL}-го уровня! (Ваш уровень: {lvl})")
        return

    args = context.args
    if len(args) < 2:
        await update.message.reply_text("⚠️ <b>Использование:</b> <code>/pay &lt;ID или @username&gt; &lt;сумма&gt;</code>", parse_mode=ParseMode.HTML)
        return

    target_str, amount_str = args[0], args[1]
    if not amount_str.isdigit() or int(amount_str) <= 0:
        await update.message.reply_text("❌ Введите корректное число.")
        return

    amount = int(amount_str)
    if amount < TRANSFER_MIN_STARS:
        await update.message.reply_text(f"❌ Минимальная сумма перевода — {TRANSFER_MIN_STARS:,} ⭐!")
        return

    target_user = get_user_by_target(target_str)

    if not target_user:
        await update.message.reply_text("❌ Игрок не найден.")
        return

    if target_user["user_id"] == sender.id:
        await update.message.reply_text("❌ Перевод самому себе невозможен.")
        return

    if not deduct_user_stars(sender.id, amount):
        await update.message.reply_text("❌ Недостаточно Stars на балансе.")
        return

    add_user_stars(target_user["user_id"], amount)
    receiver_name = normalize_telegram_name(target_user["first_name"], target_user["username"], target_user["user_id"])

    try:
        await context.bot.send_message(
            chat_id=target_user["user_id"],
            text=(
                f"💸 <b>Вам поступил перевод!</b>\n\n"
                f"От игрока: <b>{clean_html(sender.first_name)}</b>\n"
                f"Сумма: <b>+{amount:,} ⭐</b>"
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=quick_nav_keyboard()
        )
    except Exception:
        pass

    await update.message.reply_text(
        f"💸 <b>Перевод выполнен!</b>\nПереведено <b>{amount:,} ⭐</b> игроку <b>{clean_html(receiver_name)}</b>.",
        parse_mode=ParseMode.HTML,
        reply_markup=quick_nav_keyboard()
    )

async def cmd_send_gift(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await check_access_allowed(update):
        return
    if not await ensure_privacy_accepted_private(update, context):
        return
    sender = update.effective_user
    sender_db = get_or_create_user(sender.id, sender.username or "", sender.first_name or "")

    args = context.args
    if len(args) < 2:
        await update.message.reply_text("⚠️ <b>Использование:</b> <code>/send_gift &lt;ID_предмета&gt; &lt;ID или @username&gt;</code>", parse_mode=ParseMode.HTML)
        return

    item_id_str, target_str = args[0], args[1]
    if not item_id_str.isdigit():
        await update.message.reply_text("❌ Укажите ID предмета.")
        return

    item_id = int(item_id_str)
    item = get_collection_item(item_id)
    if not item or item["user_id"] != sender.id:
        await update.message.reply_text("❌ Предмет не найден в вашей коллекции.")
        return

    if not item["is_upgraded"]:
        lvl, _, _, _ = calculate_xp_level_info(sender_db["xp"])
        if lvl < TRANSFER_MIN_LEVEL:
            await update.message.reply_text(f"❌ Передавать обычные подарки можно только с {TRANSFER_MIN_LEVEL}-го уровня! (Улучшенные подарки можно передавать на любом уровне)")
            return

    target_user = get_user_by_target(target_str)
    if not target_user or target_user["user_id"] == sender.id:
        await update.message.reply_text("❌ Некорректный получатель.")
        return

    ok, res = transfer_gift_between_users(sender.id, target_user["user_id"], item_id)
    if not ok:
        await update.message.reply_text(f"❌ {res}")
        return

    g = GIFTS_BY_KEY.get(res)
    g_name = f"Plush Pepe #{item['upgrade_num']} ({item['model_name']})" if item["is_upgraded"] else (g.name if g else res)
    receiver_name = normalize_telegram_name(target_user["first_name"], target_user["username"], target_user["user_id"])

    try:
        await context.bot.send_message(
            chat_id=target_user["user_id"],
            text=(
                f"🎁 <b>Вам подарен NFT!</b>\n\n"
                f"От игрока: <b>{clean_html(sender.first_name)}</b>\n"
                f"Предмет: <b>{clean_html(g_name)}</b>!\n"
                f"Предмет уже в вашей коллекции."
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=quick_nav_keyboard()
        )
    except Exception:
        pass

    await update.message.reply_text(
        f"🎁 <b>Подарок передан!</b>\nПредмет <b>{clean_html(g_name)}</b> отправлен игроку <b>{clean_html(receiver_name)}</b>!",
        parse_mode=ParseMode.HTML,
        reply_markup=quick_nav_keyboard()
    )

async def cmd_maintenance_fallback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Перехватывает любые неизвестные /команды во время техработ."""
    if not await check_access_allowed(update):
        return

# ---------------------------------------------------------------------------
# ИНЛАЙН-ЧЕКИ НА STARS (@bot <сумма> / @bot <сумма> @username)
# ---------------------------------------------------------------------------

_CHECK_CARD_FILE_ID_CACHE: Dict[Tuple[int, int, str, str], str] = {}

async def _upload_temp_check_photo(bot, chat_id: int, img_io: io.BytesIO) -> Optional[str]:
    try:
        img_io.seek(0)
        sent = await bot.send_photo(
            chat_id=chat_id,
            photo=InputFile(img_io, filename="star_check.png"),
            disable_notification=True,
        )
        if sent and sent.photo:
            fid = sent.photo[-1].file_id
            try:
                await sent.delete()
            except Exception:
                pass
            return fid
    except Exception:
        pass
    return None

async def _get_check_photo_file_id(
    bot,
    user_id: int,
    amount_stars: int,
    creator_name: str,
    target_label: str,
) -> Optional[str]:
    """Генерирует и загружает карточку чека с ТОЧНОЙ суммой, чтобы сразу вложить её в инлайн-результат."""
    cache_key = (int(user_id), int(amount_stars), creator_name, target_label)
    cached_fid = _CHECK_CARD_FILE_ID_CACHE.get(cache_key)
    if cached_fid:
        return cached_fid

    card_io = await generate_check_card_image(
        amount_stars=amount_stars,
        creator_name=creator_name,
        target_label=target_label,
    )
    fid = await _upload_temp_check_photo(bot, user_id, card_io)
    if not fid:
        for adm_id in ADMIN_IDS:
            if adm_id != user_id:
                fid = await _upload_temp_check_photo(bot, adm_id, card_io)
                if fid:
                    break
    if fid:
        if len(_CHECK_CARD_FILE_ID_CACHE) >= 300:
            _CHECK_CARD_FILE_ID_CACHE.clear()
        _CHECK_CARD_FILE_ID_CACHE[cache_key] = fid
        return fid
    return None

async def _ensure_neutral_check_photo_file_id(bot, user_id: int) -> Optional[str]:
    """Резервный нейтральный шаблон БЕЗ суммы (если не удалось загрузить персональную карточку)."""
    cached = get_bot_setting("check_base_file_id_v2", "")
    if cached:
        return cached
    sample_io = await generate_check_card_image(
        amount_stars=None,
        creator_name="New NFT Bot",
        target_label="Telegram Stars Check",
    )
    fid = await _upload_temp_check_photo(bot, user_id, sample_io)
    if not fid:
        for adm_id in ADMIN_IDS:
            if adm_id != user_id:
                fid = await _upload_temp_check_photo(bot, adm_id, sample_io)
                if fid:
                    break
    if fid:
        set_bot_setting("check_base_file_id_v2", fid)
        return fid
    return None

def _parse_inline_check_query(raw_query: str) -> Tuple[Optional[int], str, Optional[str]]:
    """Разбирает инлайн-запрос вида '<сумма>' или '<сумма> @username'. Возвращает (amount, target_username, error_text)."""
    q = (raw_query or "").strip()
    if not q:
        return None, "", "Введите сумму от 1,000 ⭐ (пример: 5000 или 5000 @username)"

    tokens = q.split()
    target_uname = ""
    num_tokens = []
    for tok in tokens:
        if tok.startswith("@"):
            if target_uname:
                return None, "", "Укажите только одного получателя @username"
            uname_clean = tok.lstrip("@").strip()
            if len(uname_clean) < 2:
                return None, "", "Введите корректный @username получателя"
            target_uname = uname_clean
        else:
            num_tokens.append(tok)

    if not num_tokens:
        return None, target_uname, "Укажите сумму звёзд (от 1,000 ⭐)"

    raw_num = re.sub(r"[\s,_.]", "", "".join(num_tokens))
    if not raw_num.isdigit():
        return None, target_uname, "Сумма должна быть целым числом (например: 5000)"

    amount = int(raw_num)
    if amount < CHECK_MIN_STARS:
        return None, target_uname, f"Минимальная сумма чека — {CHECK_MIN_STARS:,} ⭐"
    if amount > 10_000_000_000:
        return None, target_uname, "Слишком большая сумма для одного чека"

    return amount, target_uname, None

async def on_inline_query(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    iq = update.inline_query
    if not iq:
        return
    user = iq.from_user

    if is_maintenance_mode() and user.id not in ADMIN_IDS:
        await iq.answer([
            InlineQueryResultArticle(
                id="maint",
                title="🛠 Бот на техработах",
                description="Создание чеков временно недоступно.",
                input_message_content=InputTextMessageContent("🛠 Бот сейчас на техработах."),
            )
        ], cache_time=1, is_personal=True)
        return

    is_banned, _, _, _ = is_user_banned(user.id)
    if is_banned and user.id not in ADMIN_IDS:
        await iq.answer([
            InlineQueryResultArticle(
                id="banned",
                title="⛔️ Аккаунт заблокирован",
                description="Вы не можете создавать чеки.",
                input_message_content=InputTextMessageContent("⛔️ Ваш аккаунт заблокирован."),
            )
        ], cache_time=1, is_personal=True)
        return

    db_user = get_or_create_user(user.id, user.username or "", user.first_name or "")
    amount, target_uname, err = _parse_inline_check_query(iq.query or "")

    if err or amount is None:
        await iq.answer([
            InlineQueryResultArticle(
                id="help",
                title="💳 Создать чек на Stars (от 1,000 ⭐)",
                description=err or f"Баланс: {fmt_stars_compact(db_user['balance_stars'])} ⭐ • Пример: 5000 или 5000 @username",
                input_message_content=InputTextMessageContent(
                    f"💳 Для отправки чека введите <code>@{await get_bot_username(context.bot)} 5000</code> или <code>5000 @username</code> (от {CHECK_MIN_STARS:,} ⭐).",
                    parse_mode=ParseMode.HTML,
                ),
            )
        ], cache_time=1, is_personal=True)
        return

    if db_user["balance_stars"] < amount:
        await iq.answer([
            InlineQueryResultArticle(
                id="low_bal",
                title=f"❌ Недостаточно Stars ({fmt_stars_compact(db_user['balance_stars'])} ⭐)",
                description=f"Требуется {fmt_stars_compact(amount)} ⭐ на балансе.",
                input_message_content=InputTextMessageContent(
                    f"❌ Недостаточно Stars для создания чека на {fmt_stars_compact(amount)} ⭐."
                ),
            )
        ], cache_time=1, is_personal=True)
        return

    code = create_star_check_draft(user.id, amount, target_uname)
    creator_name = normalize_telegram_name(user.first_name, user.username, user.id)
    target_lbl = f"@{target_uname}" if target_uname else "Все игроки"

    cap = (
        f"💳 <b>Чек на {fmt_stars_compact(amount)} ⭐</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"👤 От: <b>{clean_html(creator_name)}</b>\n"
        f"🎯 Получатель: <b>{clean_html(target_lbl)}</b>\n"
        f"💰 Сумма: <b>{fmt_stars_rub(amount)}</b>"
    )
    kb = InlineKeyboardMarkup([[
        make_btn(
            f"💳 Активировать чек ({fmt_stars_compact(amount)} ⭐)",
            style="success",
            callback_data=f"claim_check:{code}",
        )
    ]])

    exact_file_id = await _get_check_photo_file_id(context.bot, user.id, amount, creator_name, target_lbl)
    if exact_file_id:
        mark_star_check_rendered(code)
        photo_fid = exact_file_id
    else:
        photo_fid = await _ensure_neutral_check_photo_file_id(context.bot, user.id)

    if photo_fid:
        res_item = InlineQueryResultCachedPhoto(
            id=f"chk:{code}",
            photo_file_id=photo_fid,
            title=f"💳 Чек на {fmt_stars_compact(amount)} ⭐ ({target_lbl})",
            description=f"Нажмите, чтобы отправить чек • Баланс: {fmt_stars_compact(db_user['balance_stars'])} ⭐",
            caption=cap,
            parse_mode=ParseMode.HTML,
            reply_markup=kb,
        )
    else:
        res_item = InlineQueryResultArticle(
            id=f"chk:{code}",
            title=f"💳 Чек на {fmt_stars_compact(amount)} ⭐ ({target_lbl})",
            description=f"Нажмите, чтобы отправить чек • Баланс: {fmt_stars_compact(db_user['balance_stars'])} ⭐",
            input_message_content=InputTextMessageContent(cap, parse_mode=ParseMode.HTML),
            reply_markup=kb,
        )

    await iq.answer([res_item], cache_time=1, is_personal=True)

async def on_chosen_inline_result(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    cir = update.chosen_inline_result
    if not cir or not cir.result_id or not cir.result_id.startswith("chk:"):
        return

    code = cir.result_id.split(":", 1)[1]
    user = cir.from_user
    get_or_create_user(user.id, user.username or "", user.first_name or "")
    ok, err_msg, chk = activate_star_check_draft(code, user.id)

    if not ok:
        if cir.inline_message_id:
            fail_text = f"❌ <b>Чек недействителен:</b> {clean_html(err_msg)}"
            try:
                await context.bot.edit_message_caption(
                    inline_message_id=cir.inline_message_id,
                    caption=fail_text,
                    parse_mode=ParseMode.HTML,
                    reply_markup=None,
                )
            except Exception:
                try:
                    await context.bot.edit_message_text(
                        inline_message_id=cir.inline_message_id,
                        text=fail_text,
                        parse_mode=ParseMode.HTML,
                        reply_markup=None,
                    )
                except Exception:
                    pass
        return

    if not cir.inline_message_id or not chk or chk["rendered"]:
        return

    creator_name = normalize_telegram_name(user.first_name, user.username, user.id)
    target_lbl = f"@{chk['target_username']}" if chk["target_username"] else "Все игроки"
    amount = chk["amount_stars"]

    cap = (
        f"💳 <b>Чек на {fmt_stars_compact(amount)} ⭐</b>\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"👤 От: <b>{clean_html(creator_name)}</b>\n"
        f"🎯 Получатель: <b>{clean_html(target_lbl)}</b>\n"
        f"💰 Сумма: <b>{fmt_stars_rub(amount)}</b>"
    )
    kb = InlineKeyboardMarkup([[
        make_btn(
            f"💳 Активировать чек ({fmt_stars_compact(amount)} ⭐)",
            style="success",
            callback_data=f"claim_check:{code}",
        )
    ]])

    try:
        card_io = await generate_check_card_image(amount, creator_name, target_lbl)
        await context.bot.edit_message_media(
            inline_message_id=cir.inline_message_id,
            media=InputMediaPhoto(
                media=InputFile(card_io, filename=f"check_{code}.png"),
                caption=cap,
                parse_mode=ParseMode.HTML,
            ),
            reply_markup=kb,
        )
        mark_star_check_rendered(code)
    except Exception as e:
        log.debug("on_chosen_inline_result edit_message_media skipped: %s", e)

# ---------------------------------------------------------------------------
# ТОЧКА ВХОДА (MAIN)
# ---------------------------------------------------------------------------

def main() -> None:
    db_restored = False
    try:
        db_restored = firebase_manager.download_db_on_startup()
    except Exception as e:
        log.error(f"[Firebase] Ошибка скачивания базы при старте: {e}")

    db_init()

    if not db_restored and firebase_manager._cloud_doc_missing and not firebase_manager._startup_download_error:
        try:
            firebase_manager.upload_db_to_cloud(force=True)
        except Exception as e:
            log.error(f"[Firebase] Ошибка первой выгрузки базы в облако: {e}")
    elif not db_restored and firebase_manager._startup_download_error:
        log.warning("🛡️ [Anti-Wipe] Стартовое скачивание завершилось с ошибкой — пустая база НЕ будет затирать облачный документ.")

    firebase_manager.start_periodic_sync(interval_seconds=60)

    request = HTTPXRequest(
        connect_timeout=30.0,
        read_timeout=30.0,
        write_timeout=30.0,
        pool_timeout=30.0,
    )

    app = Application.builder().token(BOT_TOKEN).request(request).build()

    clan_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_clan_creation, pattern="^clan_create_start$"),
            CommandHandler("create_clan", start_clan_creation),
        ],
        states={
            WAIT_CLAN_TAG: [MessageHandler(filters.TEXT & ~filters.COMMAND, clan_tag_received)],
            WAIT_CLAN_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, clan_name_received)],
            WAIT_CLAN_DESC: [MessageHandler(filters.TEXT & ~filters.COMMAND, clan_desc_received)],
            WAIT_CLAN_TYPE: [CallbackQueryHandler(clan_type_selected, pattern="^ctype:")],
            WAIT_CLAN_FEE: [MessageHandler(filters.TEXT & ~filters.COMMAND, clan_fee_received)],
        },
        fallbacks=[CommandHandler("cancel", cancel_clan_creation)],
        per_message=False,
        allow_reentry=True
    )

    admin_give_stars_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_give_stars_start, pattern="^admin_give_stars_start$")],
        states={
            WAIT_ADMIN_GIVE_STARS_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_give_stars_user)],
            WAIT_ADMIN_GIVE_STARS_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_give_stars_amount)],
        },
        fallbacks=[
            CommandHandler("cancel", admin_cancel),
            CallbackQueryHandler(admin_cancel, pattern="^admin_cancel$")
        ],
        per_message=False,
        allow_reentry=True
    )

    admin_give_nft_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_give_nft_start, pattern="^admin_give_nft_start$")],
        states={
            WAIT_ADMIN_GIVE_NFT_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_give_nft_user)],
        },
        fallbacks=[
            CommandHandler("cancel", admin_cancel),
            CallbackQueryHandler(admin_cancel, pattern="^admin_cancel$")
        ],
        per_message=False,
        allow_reentry=True
    )

    bg_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(bg_change_start, pattern="^bg_change_start$")],
        states={
            WAIT_PROFILE_BG: [
                MessageHandler(filters.PHOTO, bg_photo_received),
                CallbackQueryHandler(bg_cancel, pattern="^bg_cancel$")
            ],
        },
        fallbacks=[CommandHandler("cancel", bg_cancel)],
        per_message=False,
        allow_reentry=True
    )

    admin_ban_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_ban_start, pattern="^admin_ban_start$")],
        states={
            WAIT_ADMIN_BAN_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_ban_user_received)],
            WAIT_ADMIN_BAN_HOURS: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_ban_hours_received)],
            WAIT_ADMIN_BAN_REASON: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_ban_reason_received)],
        },
        fallbacks=[
            CommandHandler("cancel", admin_cancel),
            CallbackQueryHandler(admin_cancel, pattern="^admin_cancel$")
        ],
        per_message=False,
        allow_reentry=True
    )

    admin_unban_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_unban_start, pattern="^admin_unban_start$")],
        states={
            WAIT_ADMIN_UNBAN_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_unban_user_received)],
        },
        fallbacks=[
            CommandHandler("cancel", admin_cancel),
            CallbackQueryHandler(admin_cancel, pattern="^admin_cancel$")
        ],
        per_message=False,
        allow_reentry=True
    )

    clan_avatar_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(clan_avatar_start, pattern="^clan_avatar_start:")],
        states={
            WAIT_CLAN_AVATAR: [
                MessageHandler(filters.PHOTO, clan_avatar_photo_received),
                CallbackQueryHandler(clan_avatar_preset_selected, pattern="^clan_avatar_preset:"),
                CallbackQueryHandler(clan_avatar_cancel, pattern="^clan_avatar_cancel$")
            ]
        },
        fallbacks=[CommandHandler("cancel", clan_avatar_cancel)],
        per_message=False,
        allow_reentry=True
    )

    clan_donate_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(clan_donate_stars_start, pattern="^clan_donate_stars_start:")],
        states={
            WAIT_CLAN_DONATE_STARS: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, clan_donate_stars_amount),
                CallbackQueryHandler(clan_donate_cancel, pattern="^clan_donate_cancel$")
            ]
        },
        fallbacks=[CommandHandler("cancel", clan_donate_cancel)],
        per_message=False,
        allow_reentry=True
    )

    admin_firebase_key_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_firebase_upload_key_start, pattern="^admin_firebase_upload_key$")],
        states={
            WAIT_ADMIN_FIREBASE_JSON: [
                MessageHandler(filters.Document.ALL, admin_firebase_json_received),
                CallbackQueryHandler(admin_cancel, pattern="^admin_cancel$")
            ]
        },
        fallbacks=[
            CommandHandler("cancel", admin_cancel),
            CallbackQueryHandler(admin_cancel, pattern="^admin_cancel$")
        ],
        per_message=False,
        allow_reentry=True
    )

    market_offer_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(market_sell_start, pattern="^market_sell_start:")],
        states={
            WAIT_MARKET_OFFER_PRICE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, market_sell_price_received),
                CallbackQueryHandler(market_sell_cancel, pattern="^market_sell_cancel$"),
            ]
        },
        fallbacks=[
            CommandHandler("cancel", market_sell_cancel),
            CallbackQueryHandler(market_sell_cancel, pattern="^market_sell_cancel$"),
        ],
        per_message=False,
        allow_reentry=True,
    )

    gift_transfer_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(gift_transfer_start, pattern="^gift_transfer_start:")],
        states={
            WAIT_GIFT_TRANSFER_USER: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, gift_transfer_user_received),
                CallbackQueryHandler(gift_transfer_cancel, pattern="^gift_transfer_cancel$"),
            ]
        },
        fallbacks=[
            CommandHandler("cancel", gift_transfer_cancel),
            CallbackQueryHandler(gift_transfer_cancel, pattern="^gift_transfer_cancel$"),
        ],
        per_message=False,
        allow_reentry=True,
    )

    app.add_handler(clan_conv)
    app.add_handler(admin_give_stars_conv)
    app.add_handler(admin_give_nft_conv)
    app.add_handler(admin_ban_conv)
    app.add_handler(admin_unban_conv)
    app.add_handler(clan_avatar_conv)
    app.add_handler(clan_donate_conv)
    app.add_handler(admin_firebase_key_conv)
    app.add_handler(bg_conv)
    app.add_handler(market_offer_conv)
    app.add_handler(gift_transfer_conv)

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("profile", cmd_profile_alias))
    app.add_handler(CommandHandler("pay", cmd_pay))
    app.add_handler(CommandHandler("send_gift", cmd_send_gift))
    app.add_handler(CommandHandler("clans", cmd_clans))
    app.add_handler(CommandHandler("market", cmd_market))
    app.add_handler(CommandHandler("admin", cmd_admin))
    app.add_handler(CommandHandler("info", cmd_info))
    app.add_handler(MessageHandler(filters.COMMAND, cmd_maintenance_fallback))

    app.add_handler(InlineQueryHandler(on_inline_query))
    app.add_handler(ChosenInlineResultHandler(on_chosen_inline_result))
    app.add_handler(CallbackQueryHandler(on_callback))
    app.add_handler(MessageHandler((filters.TEXT | filters.PHOTO) & ~filters.COMMAND, on_group_message))

    log.info("New NFT Gift Telegram Bot v12.1 запущен!")
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)

if __name__ == "__main__":
    main()
